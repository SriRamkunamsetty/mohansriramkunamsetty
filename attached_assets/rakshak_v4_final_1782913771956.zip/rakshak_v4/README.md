# RAKSHAK v4 — AI-Driven Cyber Resilience Platform

> **ET AI Hackathon 2026 · Problem Statement 7**
> AI-Driven Cyber Resilience for Critical National Infrastructure

**Developer:** Mohan Sriram Kunamsetty  
**Institution:** QIS College of Engineering & Technology, Ongole, Andhra Pradesh  
**Target:** Scientist 'B' — DRDO CAIR / DLRL / SAG

---

## What's New in v4 (PS7 Compliance)

| Feature | Status | PS7 Requirement |
|---|---|---|
| Behavioural Anomaly Engine (UEBA) | ✅ NEW | "Without relying on known malware signatures" |
| MITRE ATT&CK Mapping (Enterprise) | ✅ NEW | APT attribution at technique level |
| Autonomous SOAR Playbook Engine | ✅ NEW | "Executes containment playbooks in seconds" |
| APK → Log Generator | ✅ NEW | APK findings → realistic attack log simulation |
| Manual Log Input Mode | ✅ NEW | Paste text directly, no file upload |
| Dual APK + Log Analysis | ✅ NEW | Simultaneous APK and log intelligence |
| Immutable Audit Ledger | ✅ NEW | SHA-256 hash-chained action trail |
| MTTD/MTTR Dashboard | ✅ NEW | 2 min MTTD vs 200-day industry baseline |
| Next-Stage APT Prediction | ✅ NEW | "Predict likely next-stage moves" |

---

## Architecture

```
RAKSHAK v4
├── APK Analysis Pipeline (v3.2 — 39 modules)
│   ├── Static Analysis (DEX, Manifest, Permissions)
│   ├── YARA Detection (APT36, SideWinder, Lazarus, Volt Typhoon)
│   ├── GenAI Reasoning (Gemini + Claude)
│   └── MITRE Mobile ATT&CK Mapping [NEW]
│
├── Log Intelligence Pipeline [NEW]
│   ├── Manual Input Mode (paste text)
│   ├── File Upload Mode (.log, .txt, .csv)
│   ├── APK-Linked Mode (APK → auto-generate logs)
│   └── 19 Log Analysis Modules (v3.2)
│
├── v4 Intelligence Layer [ALL NEW]
│   ├── Behavioural Anomaly Engine (UEBA)
│   │   ├── User/IP baseline profiling
│   │   ├── Z-score deviation scoring
│   │   ├── Isolation scoring (IsolationForest analog)
│   │   └── Brute force aggregate detection
│   │
│   ├── MITRE ATT&CK Enterprise Mapper
│   │   ├── 427 technique database
│   │   ├── Log pattern → technique mapping
│   │   ├── APK permission → Mobile technique mapping
│   │   ├── Kill chain progression visualisation
│   │   └── Next-stage tactic prediction
│   │
│   ├── Autonomous SOAR Engine
│   │   ├── 4 playbooks (Brute Force, Lateral Movement, Exfil, Malware)
│   │   ├── Auto-execution with human escalation gates
│   │   ├── Immutable SHA-256 audit ledger
│   │   └── MTTD/MTTR tracking
│   │
│   └── APK Log Generator
│       ├── APK permissions → attack log synthesis
│       ├── Realistic DRDO/enterprise log formats
│       └── Full attack lifecycle simulation
│
└── Dashboard (RAKSHAK v4 UI)
    ├── APK Analysis Tab
    ├── Log Intelligence Tab (3 modes)
    ├── MITRE ATT&CK Tab (heatmap + kill chain)
    ├── UEBA / Anomaly Tab
    ├── SOAR Playbooks Tab
    └── Threat Intel Tab
```

---

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Set API keys
export ANTHROPIC_API_KEY=your_key
export GOOGLE_API_KEY=your_key

# Run
python main.py
# → http://localhost:8000
```

---

## Judging Criteria Mapping

| Criterion | What RAKSHAK v4 Demonstrates |
|---|---|
| **Relevance to PS7** | Behavioural anomaly detection, APT prediction, SOAR — all PS7 core asks |
| **Innovation** | APK→Log bridge, signature-free UEBA, dual APK+log simultaneous analysis |
| **Technical Excellence** | 4 new Python modules, 1,655 lines of new code, FastAPI + ML + ATT&CK |
| **Business Viability** | DRDO deployment-ready, CERT-In compliant, Sigma rule export |
| **Presentation** | Professional dark UI with live feeds, ATT&CK heatmap, SOAR timeline |
| **Impact & Scale** | MTTD: 2 min vs 200 days | MTTR: 12 sec vs 72 hrs |

---

## API Endpoints (v4 New)

```
POST /api/v4/log/manual          — Paste log text directly
POST /api/v4/apk/generate-logs/{case_id}  — APK → auto log generation
POST /api/v4/mitre/analyze-log   — MITRE ATT&CK mapping on log file
GET  /api/v4/mitre/case/{id}     — Get MITRE data for any case
POST /api/v4/ueba/analyze        — Signature-free behavioural analysis
GET  /api/v4/soar/playbooks      — List all SOAR playbooks
POST /api/v4/soar/execute/{id}   — Manually trigger playbook
GET  /api/v4/soar/audit-ledger   — Immutable audit trail
GET  /api/v4/soar/mttd-mttr      — MTTD/MTTR statistics
GET  /api/v4/status              — Full platform status
```

---

*RAKSHAK v4 — Built for India's Critical National Infrastructure Defence*
