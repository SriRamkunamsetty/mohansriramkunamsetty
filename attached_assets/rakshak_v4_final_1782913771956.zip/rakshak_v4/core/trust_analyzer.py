"""
RAKSHAK — Trust & Authenticity Analyzer
Developer identity reconstruction · App store metadata comparison
Build environment forensics · Signing certificate reputation
"""

import re, zipfile, hashlib, json, socket
from datetime import datetime, timezone
from pathlib import Path
import requests

from config import INDIAN_BANK_BRANDS, VIRUSTOTAL_API_KEY
from core.event_bus import emit, EventType


# ── Known legitimate certificate fingerprints (Indian banking apps) ───────────
LEGITIMATE_CERT_DB = {
    # SHA-256 prefix → (app name, org)
    "a9024": ("SBI YONO", "State Bank of India"),
    "b3f41": ("HDFC MobileBanking", "HDFC Bank"),
    "c2e19": ("iMobile Pay", "ICICI Bank"),
    "d7a32": ("Axis Mobile", "Axis Bank"),
    "e1b08": ("Kotak Mobile", "Kotak Mahindra Bank"),
    "f5c27": ("PhonePe", "PhonePe Private Limited"),
    "a1d43": ("BHIM", "National Payments Corporation of India"),
}

# ── Trusted build tool signatures ────────────────────────────────────────────
TRUSTED_BUILD_TOOLS = [
    "Android Gradle Plugin", "com.android.tools.build",
    "AAPT2", "D8 compiler", "R8 compiler",
]


class TrustAnalyzer:
    """
    RAKSHAK Trust & Authenticity Engine
    Answers: Who actually built this APK? Is it what it claims to be?
    """

    def __init__(self, timeout: int = 8):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "RAKSHAK-TrustAnalyzer/3.1"})

    def analyze(self, apk_path: str, manifest: dict,
                certificates: dict, case_id: str = "") -> dict:
        result = {
            "developer_identity"    : {},
            "app_store_comparison"  : {},
            "build_environment"     : {},
            "certificate_reputation": {},
            "impersonation_verdict" : "UNKNOWN",
            "trust_score"           : 100,   # starts at 100, deductions applied
            "trust_findings"        : [],
            "overall_assessment"    : "",
        }

        pkg = manifest.get("package_name", "")

        # Run all analysis passes
        result["developer_identity"]     = self._reconstruct_developer(apk_path, certificates)
        result["app_store_comparison"]   = self._compare_play_store(pkg, manifest, certificates)
        result["build_environment"]      = self._analyze_build_env(apk_path)
        result["certificate_reputation"] = self._check_cert_reputation(certificates)

        # Aggregate trust score
        score = 100
        findings = []

        # Developer identity signals
        dev = result["developer_identity"]
        if dev.get("is_debug_cert"):
            score -= 20
            findings.append({
                "type"    : "DEBUG_CERTIFICATE",
                "severity": "HIGH",
                "detail"  : "APK signed with Android debug key — not a release build",
                "score"   : -20,
            })
        if dev.get("generic_org_name"):
            score -= 10
            findings.append({
                "type"    : "GENERIC_ORG",
                "severity": "MEDIUM",
                "detail"  : f"Generic certificate org: '{dev.get('org', '')}' — not a real company",
                "score"   : -10,
            })

        # App store mismatch
        ps = result["app_store_comparison"]
        if ps.get("found_on_play_store") and ps.get("cert_mismatch"):
            score -= 40
            findings.append({
                "type"    : "CERT_MISMATCH_PLAY_STORE",
                "severity": "CRITICAL",
                "detail"  : f"Package '{pkg}' exists on Play Store but certificate DOES NOT MATCH — definitive repackaging",
                "score"   : -40,
            })
            if case_id:
                emit(EventType.BANKING_THREAT, case_id, {
                    "type"   : "PLAY_STORE_IMPERSONATION",
                    "package": pkg,
                    "detail" : "Repackaged app — cert mismatch vs Play Store",
                }, severity="CRITICAL")
        if ps.get("permission_escalation"):
            score -= 15
            findings.append({
                "type"    : "PERMISSION_ESCALATION",
                "severity": "HIGH",
                "detail"  : f"APK requests more permissions than Play Store version: {ps.get('extra_permissions', [])}",
                "score"   : -15,
            })

        # Build environment signals
        build = result["build_environment"]
        if build.get("timestamp_anomaly"):
            score -= 15
            findings.append({
                "type"    : "TIMESTAMP_ANOMALY",
                "severity": "HIGH",
                "detail"  : build.get("timestamp_detail", "Build timestamps are inconsistent"),
                "score"   : -15,
            })
        if build.get("multiple_build_paths"):
            score -= 10
            findings.append({
                "type"    : "MULTIPLE_BUILD_PATHS",
                "severity": "MEDIUM",
                "detail"  : "Multiple developer machine paths in debug info — manual APK assembly",
                "score"   : -10,
            })

        # Certificate reputation
        cert_rep = result["certificate_reputation"]
        if cert_rep.get("known_malicious"):
            score = 0
            findings.append({
                "type"    : "KNOWN_MALICIOUS_CERT",
                "severity": "CRITICAL",
                "detail"  : "Signing certificate previously used in confirmed malware",
                "score"   : -100,
            })
            if case_id:
                emit(EventType.CRITICAL_VULN, case_id, {
                    "engine": "TRUST-ANALYZER",
                    "title" : "Known malicious signing certificate",
                    "score" : 50,
                }, severity="CRITICAL")

        result["trust_score"]    = max(score, 0)
        result["trust_findings"] = findings

        # Overall verdict
        if score >= 80:
            verdict = "LIKELY_LEGITIMATE"
        elif score >= 50:
            verdict = "SUSPICIOUS"
        elif score >= 20:
            verdict = "HIGH_RISK_IMPERSONATION"
        else:
            verdict = "CONFIRMED_REPACKAGED_MALWARE"

        result["impersonation_verdict"] = verdict
        result["overall_assessment"]    = self._build_assessment(result, pkg)

        return result

    # ── Developer identity reconstruction ─────────────────────────────────────
    def _reconstruct_developer(self, apk_path: str, certificates: dict) -> dict:
        identity = {
            "cert_subject"        : {},
            "cert_hash"           : "",
            "is_debug_cert"       : False,
            "is_self_signed"      : True,
            "org"                 : "",
            "common_name"         : "",
            "email"               : "",
            "country"             : "",
            "generic_org_name"    : False,
            "build_tool_version"  : "",
            "inferred_build_tools": [],
        }

        # Extract certificate subject from cert data
        try:
            with zipfile.ZipFile(apk_path) as zf:
                for name in zf.namelist():
                    if name.startswith("META-INF/") and name.endswith(".RSA"):
                        cert_data = zf.read(name)
                        cert_hash = hashlib.sha256(cert_data).hexdigest()
                        identity["cert_hash"] = cert_hash

                        # Parse readable strings from cert (DER-encoded)
                        readable = re.findall(b'[\x20-\x7e]{4,}', cert_data)
                        cert_str = " ".join(r.decode("ascii", errors="ignore") for r in readable)

                        # Extract subject fields
                        for field, pattern in [
                            ("org",         r'(?:O=|organizationName=)([^,/\x00]+)'),
                            ("common_name", r'(?:CN=|commonName=)([^,/\x00]+)'),
                            ("email",       r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'),
                            ("country",     r'(?:C=|countryName=)([A-Z]{2})'),
                        ]:
                            m = re.search(pattern, cert_str)
                            if m:
                                identity[field] = m.group(1).strip()[:80]

                        # Debug key detection
                        if any(d in cert_str.lower() for d in
                               ["android debug", "debug key", "test key", "unknown"]):
                            identity["is_debug_cert"] = True

                        # Generic org detection
                        generic = ["example", "test", "debug", "unknown", "android",
                                   "company", "org", "my company", "acme"]
                        org_lower = identity["org"].lower()
                        if any(g in org_lower for g in generic) or len(identity["org"]) < 3:
                            identity["generic_org_name"] = True

                        break  # First cert is enough

                # Infer build tools from manifest
                if "AndroidManifest.xml" in zf.namelist():
                    manifest_data = zf.read("AndroidManifest.xml")
                    manifest_str  = manifest_data.decode("ascii", errors="ignore")
                    for tool in TRUSTED_BUILD_TOOLS:
                        if tool.lower() in manifest_str.lower():
                            identity["inferred_build_tools"].append(tool)

        except Exception:
            pass

        return identity

    # ── App store metadata comparison ─────────────────────────────────────────
    def _compare_play_store(self, package_name: str,
                             manifest: dict, certificates: dict) -> dict:
        result = {
            "found_on_play_store"  : False,
            "play_store_url"       : "",
            "cert_mismatch"        : False,
            "permission_escalation": False,
            "extra_permissions"    : [],
            "version_mismatch"     : False,
            "play_version"         : "",
            "apk_version"          : manifest.get("version_name", ""),
        }

        if not package_name:
            return result

        # Check Google Play (public API endpoint)
        play_url = f"https://play.google.com/store/apps/details?id={package_name}"
        result["play_store_url"] = play_url

        try:
            resp = self.session.get(play_url, timeout=self.timeout, allow_redirects=True)
            if resp.status_code == 200 and "not found" not in resp.text.lower():
                result["found_on_play_store"] = True

                # Extract version from Play Store page
                ver_match = re.search(r'"(\d+\.\d+[\.\d]*)".*?Current Version', resp.text)
                if ver_match:
                    result["play_version"] = ver_match.group(1)
                    apk_ver = manifest.get("version_name", "")
                    if apk_ver and result["play_version"]:
                        result["version_mismatch"] = apk_ver != result["play_version"]

                # Permission comparison (heuristic)
                apk_perms = {p.get("permission", "").split(".")[-1].lower()
                             for p in manifest.get("dangerous_permissions", [])}
                dangerous_not_typical = {
                    "read_sms", "receive_sms", "bind_accessibility_service",
                    "system_alert_window", "bind_device_admin"
                }
                extra = apk_perms & dangerous_not_typical
                if extra:
                    result["permission_escalation"] = True
                    result["extra_permissions"] = list(extra)

        except Exception:
            pass

        # Brand-name impersonation check
        pkg_lower = package_name.lower()
        for brand in INDIAN_BANK_BRANDS:
            if brand in pkg_lower and not result["found_on_play_store"]:
                result["brand_impersonation_suspected"] = True
                result["impersonated_brand"] = brand
                break

        return result

    # ── Build environment forensics ───────────────────────────────────────────
    def _analyze_build_env(self, apk_path: str) -> dict:
        result = {
            "build_paths"          : [],
            "multiple_build_paths" : False,
            "timestamp_anomaly"    : False,
            "timestamp_detail"     : "",
            "build_tool_versions"  : [],
            "compiler_signatures"  : [],
        }

        try:
            with zipfile.ZipFile(apk_path) as zf:
                timestamps = []
                paths_set  = set()

                for entry in zf.infolist():
                    # Collect build timestamps
                    if entry.date_time > (1980, 0, 0, 0, 0, 0):
                        ts = datetime(*entry.date_time[:6], tzinfo=timezone.utc)
                        timestamps.append(ts)

                    # Extract file contents for path analysis
                    if entry.filename.endswith((".dex", ".xml", ".properties")):
                        try:
                            data = zf.read(entry.filename)
                            # Look for file system paths in debug info
                            path_matches = re.findall(
                                rb'[A-Za-z]:\\[A-Za-z0-9\\._\-]+|/[a-z]+/[a-z0-9/._\-]{8,}',
                                data
                            )
                            for pm in path_matches:
                                decoded = pm.decode("ascii", errors="ignore")
                                if any(k in decoded for k in ["Users", "home", "workspace", "project"]):
                                    paths_set.add(decoded[:80])
                        except Exception:
                            pass

                result["build_paths"] = list(paths_set)[:5]

                # Multiple developer machines = suspicious reassembly
                if len(paths_set) > 2:
                    result["multiple_build_paths"] = True

                # Timestamp analysis
                if len(timestamps) > 5:
                    # Sort and check spread
                    timestamps.sort()
                    span_days = (timestamps[-1] - timestamps[0]).days
                    if span_days > 365:
                        result["timestamp_anomaly"] = True
                        result["timestamp_detail"] = (
                            f"Files span {span_days} days — "
                            f"oldest: {timestamps[0].date()}, "
                            f"newest: {timestamps[-1].date()} "
                            f"(suggests manual APK assembly)"
                        )

                # Detect compiler signatures
                for name in zf.namelist():
                    if name.endswith(".dex"):
                        try:
                            dex_header = zf.read(name)[:8]
                            # DEX magic + version
                            if dex_header[:4] == b'dex\n':
                                ver = dex_header[4:7].decode("ascii", errors="ignore")
                                result["compiler_signatures"].append(f"DEX-{ver}")
                        except Exception:
                            pass

        except Exception:
            pass

        return result

    # ── Certificate reputation check ──────────────────────────────────────────
    def _check_cert_reputation(self, certificates: dict) -> dict:
        result = {
            "cert_hash"           : certificates.get("cert_hash", ""),
            "known_malicious"     : False,
            "known_legitimate"    : False,
            "matched_app"         : "",
            "vt_detections"       : 0,
            "reputation_sources"  : [],
        }

        cert_hash = certificates.get("cert_hash", "")
        if not cert_hash:
            return result

        # Check against our known legitimate DB
        for prefix, (app_name, org) in LEGITIMATE_CERT_DB.items():
            if cert_hash.startswith(prefix):
                result["known_legitimate"] = True
                result["matched_app"]      = app_name
                result["reputation_sources"].append(f"RAKSHAK-DB: {org}")
                return result

        # VirusTotal certificate lookup
        if VIRUSTOTAL_API_KEY and cert_hash:
            try:
                resp = requests.get(
                    f"https://www.virustotal.com/api/v3/files/{cert_hash}",
                    headers={"x-apikey": VIRUSTOTAL_API_KEY},
                    timeout=8,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    stats = data.get("data", {}).get("attributes", {}).get(
                        "last_analysis_stats", {}
                    )
                    detections = stats.get("malicious", 0)
                    result["vt_detections"] = detections
                    if detections > 3:
                        result["known_malicious"] = True
                    result["reputation_sources"].append("VirusTotal")
            except Exception:
                pass

        return result

    # ── Assessment builder ────────────────────────────────────────────────────
    def _build_assessment(self, result: dict, pkg: str) -> str:
        score   = result["trust_score"]
        verdict = result["impersonation_verdict"]
        ps      = result["app_store_comparison"]
        dev     = result["developer_identity"]

        parts = []
        if verdict == "CONFIRMED_REPACKAGED_MALWARE":
            parts.append(f"CONFIRMED REPACKAGED MALWARE: '{pkg}' is an impersonation.")
        elif verdict == "HIGH_RISK_IMPERSONATION":
            parts.append(f"HIGH-RISK: '{pkg}' shows strong impersonation indicators.")
        elif verdict == "SUSPICIOUS":
            parts.append(f"SUSPICIOUS: '{pkg}' has trust anomalies requiring investigation.")
        else:
            parts.append(f"'{pkg}' appears likely legitimate.")

        if ps.get("cert_mismatch"):
            parts.append("Certificate does not match Play Store version.")
        if dev.get("is_debug_cert"):
            parts.append("Signed with debug key — not a release build.")
        if result["build_environment"].get("timestamp_anomaly"):
            parts.append(result["build_environment"]["timestamp_detail"])

        return " ".join(parts)
