"""
RAKSHAK — Threat Actor Attribution Engine
Correlates all evidence to identify WHO built the malware.
Developer fingerprinting · Infrastructure pivoting · Campaign linking
Produces law-enforcement-grade attribution dossier.
"""

import re, hashlib, json, socket, time
from datetime import datetime, timezone
import requests
from core.event_bus import emit, EventType


# ── Known APT group fingerprints ──────────────────────────────────────────────
KNOWN_THREAT_ACTORS = {
    "APT36 / Transparent Tribe": {
        "country"      : "Pakistan",
        "targets"      : ["DRDO", "Indian Army", "Indian Air Force", "MHA", "MEA"],
        "c2_asns"      : ["AS45595", "AS138025", "AS135161"],
        "c2_countries" : ["Pakistan", "Netherlands", "Germany"],
        "cert_patterns": ["transparent", "tribe", "apt36", "crimson"],
        "pkg_patterns" : ["com.update", "com.sync", "com.android.service"],
        "ioc_domains"  : ["updateserver", "syncservice", "androidupdate"],
        "mitre_groups" : ["G0134"],
    },
    "SideWinder (APT-C-17)": {
        "country"      : "India (rogue insider) / South Asia",
        "targets"      : ["Pakistan Military", "Sri Lanka", "Bangladesh Govt"],
        "c2_asns"      : ["AS63199", "AS16276"],
        "c2_countries" : ["France", "Germany"],
        "cert_patterns": ["sidewinder", "rattlesnake", "razor tiger"],
        "pkg_patterns" : ["com.news", "com.weather", "com.maps"],
        "ioc_domains"  : ["newsportal", "weatherapp", "mapsview"],
        "mitre_groups" : ["G0121"],
    },
    "DoNot Team (APT-C-35)": {
        "country"      : "Unknown (targets South Asia)",
        "targets"      : ["Pakistan ISI", "Afghanistan Govt", "Indian dissidents"],
        "c2_asns"      : ["AS62240", "AS205016"],
        "c2_countries" : ["Netherlands", "Russia"],
        "cert_patterns": ["donot", "jungee", "vortex"],
        "pkg_patterns"  : ["com.document", "com.chat", "com.notes"],
        "ioc_domains"  : ["documentviewer", "chatapp", "notepad"],
        "mitre_groups" : ["G0116"],
    },
    "Bitter (APT-C-08)": {
        "country"      : "South Asia",
        "targets"      : ["Pakistan Govt", "Chinese Govt", "Bangladesh Govt"],
        "c2_asns"      : ["AS4766", "AS45102"],
        "c2_countries" : ["South Korea", "China"],
        "cert_patterns": ["bitter", "cricket"],
        "pkg_patterns" : ["com.android.update", "com.system.service"],
        "ioc_domains"  : ["systemupdate", "androidsync"],
        "mitre_groups" : ["G1002"],
    },
    "Indian Banking Fraud Ring": {
        "country"      : "India / Southeast Asia",
        "targets"      : ["SBI customers", "HDFC customers", "UPI users"],
        "c2_asns"      : ["AS60068", "AS202425"],
        "c2_countries" : ["Netherlands", "Bulgaria", "Russia"],
        "cert_patterns": ["sbi", "bank", "hdfc", "icici", "paytm"],
        "pkg_patterns" : ["com.sbi", "com.hdfc", "com.paytm", "com.bhim"],
        "ioc_domains"  : ["sbibank", "hdfcbank", "paytmlogin"],
        "mitre_groups" : [],
    },
}

# ── Developer fingerprint patterns ────────────────────────────────────────────
DEV_FINGERPRINT_PATTERNS = {
    "Android Studio artifact" : [r"\.idea/", r"\.iml$", r"BuildConfig\.java"],
    "Gradle build system"     : [r"build\.gradle", r"gradlew", r"gradle\.properties"],
    "IntelliJ IDEA"           : [r"IntelliJ", r"\.iml", r"intellij"],
    "Eclipse ADT"             : [r"Eclipse", r"\.classpath", r"\.project"],
    "Command-line tools"      : [r"AAPT2", r"d8\.jar", r"apksigner"],
    "Windows developer"       : [r"C:\\Users\\", r"C:\\Documents", r"WINDOWS"],
    "Linux developer"         : [r"/home/\w+/", r"/root/", r"/opt/"],
    "Mac developer"           : [r"/Users/\w+/", r"/Library/Developer"],
    "Chinese development env" : [r"[\u4e00-\u9fff]", r"gb2312", r"gbk", r"utf-16-le.*[\u4e00-\u9fff]"],
    "Urdu/Arabic strings"     : [r"[\u0600-\u06ff]", r"[\u0750-\u077f]"],
}


class ThreatActorAttributionEngine:
    """
    RAKSHAK Attribution Engine
    Answers: WHO built this APK? WHERE are they? HOW do they operate?
    Correlates: cert metadata + build artifacts + C2 infra + code patterns
    Produces: law-enforcement dossier with confidence scores
    """

    def __init__(self, timeout: int = 8):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "RAKSHAK-Attribution/3.1"})

    def attribute(self, analysis: dict, case_id: str = "") -> dict:
        result = {
            "actor_identified"       : False,
            "matched_group"          : None,
            "attribution_confidence" : 0.0,
            "attribution_label"      : "UNKNOWN",
            "country_origin"         : "Unknown",
            "developer_fingerprint"  : {},
            "infrastructure_matches" : [],
            "code_similarity_matches": [],
            "campaign_indicators"    : [],
            "whois_data"             : [],
            "attribution_evidence"   : [],
            "law_enforcement_summary": "",
            "cert_in_alert_required" : False,
        }

        strings  = analysis.get("strings",   {})
        certs    = analysis.get("certificates", {})
        manifest = analysis.get("manifest",   {})
        yara     = analysis.get("yara_analysis", {})
        trust    = analysis.get("trust_analysis", {})

        # ── 1. APT group matching ─────────────────────────────────────────
        apt_matches = self._match_apt_group(
            strings, manifest, yara, certs, analysis
        )
        if apt_matches:
            best = max(apt_matches, key=lambda x: x["score"])
            if best["score"] > 0.4:
                result["actor_identified"]       = True
                result["matched_group"]          = best["group"]
                result["attribution_confidence"] = round(best["score"], 2)
                result["country_origin"]         = best["country"]
                result["cert_in_alert_required"] = True
                result["attribution_evidence"].extend(best["evidence"])

                if case_id:
                    emit(EventType.NATION_STATE, case_id, {
                        "actor"      : best["group"],
                        "confidence" : f"{int(best['score']*100)}%",
                        "country"    : best["country"],
                        "action"     : "ESCALATE — CERT-In + DRDO NOC + NTRO",
                    }, severity="CRITICAL")

        # ── 2. Developer fingerprint ──────────────────────────────────────
        result["developer_fingerprint"] = self._fingerprint_developer(
            analysis, certs
        )

        # ── 3. Infrastructure intelligence ────────────────────────────────
        for ip_entry in strings.get("ips", [])[:8]:
            ip = ip_entry.get("ip", "").split(":")[0]
            if ip:
                infra = self._enrich_infrastructure(ip)
                if infra:
                    result["infrastructure_matches"].append(infra)
                    result["attribution_evidence"].append(
                        f"C2 IP {ip} → {infra.get('country','?')} "
                        f"({infra.get('org','?')})"
                    )
                    if infra.get("whois_registrar"):
                        result["whois_data"].append({
                            "ip"        : ip,
                            "registrar" : infra["whois_registrar"],
                            "country"   : infra.get("country","?"),
                            "org"       : infra.get("org","?"),
                            "asn"       : infra.get("asn","?"),
                        })
                time.sleep(0.3)  # Rate limit

        for url_entry in strings.get("urls", [])[:5]:
            url = url_entry.get("url","")
            domain_match = re.search(r"https?://([^/?\s:]+)", url)
            if domain_match:
                domain = domain_match.group(1)
                whois  = self._whois_domain(domain)
                if whois:
                    result["whois_data"].append(whois)
                    result["attribution_evidence"].append(
                        f"Domain {domain} → registered: {whois.get('registrar','?')}"
                        f" country: {whois.get('registrant_country','?')}"
                        f" created: {whois.get('creation_date','?')}"
                    )

        # ── 4. Attribution confidence label ───────────────────────────────
        conf = result["attribution_confidence"]
        if conf >= 0.85:
            result["attribution_label"] = "HIGH CONFIDENCE — PROSECUTABLE"
        elif conf >= 0.65:
            result["attribution_label"] = "MEDIUM CONFIDENCE — FURTHER INTEL NEEDED"
        elif conf >= 0.40:
            result["attribution_label"] = "LOW CONFIDENCE — POSSIBLE MATCH"
        else:
            result["attribution_label"] = "UNKNOWN — INSUFFICIENT EVIDENCE"

        # ── 5. Build law enforcement summary ─────────────────────────────
        result["law_enforcement_summary"] = self._build_le_summary(result, analysis)

        return result

    # ── APT group matching ────────────────────────────────────────────────────
    def _match_apt_group(self, strings, manifest, yara, certs, analysis) -> list:
        matches = []
        pkg     = manifest.get("package_name", "").lower()
        yara_families = [f.lower() for f in yara.get("malware_families", [])]
        all_urls_ips  = " ".join(
            u.get("url","") for u in strings.get("urls",[])
        ) + " " + " ".join(
            i.get("ip","") for i in strings.get("ips",[])
        )
        cert_hash = certs.get("cert_hash","").lower()
        net_anal  = analysis.get("network_analysis", {})

        for group_name, group_info in KNOWN_THREAT_ACTORS.items():
            score    = 0.0
            evidence = []

            # YARA family match
            for family in yara_families:
                if any(kw in family for kw in group_name.lower().split()):
                    score += 0.45
                    evidence.append(f"YARA match: {family}")

            # C2 country match
            for country in group_info["c2_countries"]:
                for ioc in net_anal.get("enriched_ips", []):
                    if ioc.get("country","").lower() == country.lower():
                        score += 0.20
                        evidence.append(f"C2 in {country} — known {group_name} hosting")

            # Package name patterns
            for pkg_pat in group_info["pkg_patterns"]:
                if pkg_pat in pkg:
                    score += 0.15
                    evidence.append(f"Package matches {group_name} pattern: {pkg_pat}")

            # Domain patterns
            for dom in group_info["ioc_domains"]:
                if dom.lower() in all_urls_ips.lower():
                    score += 0.20
                    evidence.append(f"C2 domain pattern matches {group_name}: {dom}")

            # Cert subject match
            for cert_pat in group_info["cert_patterns"]:
                if cert_pat in cert_hash:
                    score += 0.30
                    evidence.append(f"Certificate matches {group_name}: {cert_pat}")

            if score > 0:
                matches.append({
                    "group"   : group_name,
                    "country" : group_info["country"],
                    "score"   : min(score, 1.0),
                    "targets" : group_info["targets"],
                    "evidence": evidence,
                })

        return matches

    # ── Developer fingerprinting ───────────────────────────────────────────────
    def _fingerprint_developer(self, analysis, certs) -> dict:
        fp = {
            "build_tools"       : [],
            "os_environment"    : "Unknown",
            "language_hints"    : [],
            "cert_subject"      : {},
            "likely_country"    : "Unknown",
            "fingerprint_score" : 0,
        }

        # From trust analysis
        trust  = analysis.get("trust_analysis", {})
        dev_id = trust.get("developer_identity", {})
        if dev_id:
            fp["cert_subject"] = {
                "org"        : dev_id.get("org", ""),
                "common_name": dev_id.get("common_name", ""),
                "country"    : dev_id.get("country", ""),
                "email"      : dev_id.get("email",""),
            }
            if dev_id.get("country"):
                fp["likely_country"] = dev_id["country"]

        # Infer OS from build paths
        build = trust.get("build_environment", {})
        paths = build.get("build_paths", [])
        for p in paths:
            if "\\" in p or "Users" in p:
                fp["os_environment"] = "Windows"
            elif "/home/" in p or "/root/" in p:
                fp["os_environment"] = "Linux"
            elif "/Users/" in p and "/Library/" in p:
                fp["os_environment"] = "macOS"

        # Language strings
        strings = analysis.get("strings", {})
        all_str = " ".join(
            str(v) for v in strings.get("bank_references", [])
        )
        if re.search(r'[\u4e00-\u9fff]', all_str):
            fp["language_hints"].append("Chinese (Simplified)")
            fp["likely_country"] = "China"
        if re.search(r'[\u0600-\u06ff]', all_str):
            fp["language_hints"].append("Arabic/Urdu")
            fp["likely_country"] = "Pakistan / Middle East"
        if re.search(r'[\u0900-\u097f]', all_str):
            fp["language_hints"].append("Hindi/Devanagari")
            fp["likely_country"] = "India"

        return fp

    # ── Infrastructure enrichment ─────────────────────────────────────────────
    def _enrich_infrastructure(self, ip: str) -> dict | None:
        try:
            resp = self.session.get(
                f"http://ip-api.com/json/{ip}?fields=status,country,countryCode,city,org,as,isp,hosting",
                timeout=self.timeout
            )
            if resp.status_code == 200:
                d = resp.json()
                if d.get("status") == "success":
                    return {
                        "ip"            : ip,
                        "country"       : d.get("country","?"),
                        "country_code"  : d.get("countryCode",""),
                        "city"          : d.get("city","?"),
                        "org"           : d.get("org","?"),
                        "isp"           : d.get("isp","?"),
                        "asn"           : d.get("as","?"),
                        "is_datacenter" : d.get("hosting", False),
                        "whois_registrar": d.get("org","?"),
                    }
        except Exception:
            pass
        return None

    # ── WHOIS domain lookup ────────────────────────────────────────────────────
    def _whois_domain(self, domain: str) -> dict | None:
        try:
            # Use public RDAP (no rate limit issues)
            tld = domain.split(".")[-1]
            resp = self.session.get(
                f"https://rdap.org/domain/{domain}",
                timeout=self.timeout
            )
            if resp.status_code == 200:
                data   = resp.json()
                events = {e.get("eventAction",""): e.get("eventDate","")
                          for e in data.get("events", [])}
                entities = data.get("entities",[])
                registrar = ""
                registrant_country = ""
                for ent in entities:
                    roles = ent.get("roles",[])
                    if "registrar" in roles:
                        vcard = ent.get("vcardArray",[])
                        if len(vcard) > 1:
                            for item in vcard[1]:
                                if item[0] == "fn":
                                    registrar = item[3][:50]
                    if "registrant" in roles:
                        for addr in ent.get("vcardArray",[[]])[1:]:
                            for item in addr:
                                if isinstance(item, list) and item[0] == "adr":
                                    registrant_country = str(item[3])[-3:]

                return {
                    "domain"            : domain,
                    "registrar"         : registrar or "Unknown",
                    "creation_date"     : events.get("registration","?")[:10],
                    "expiry_date"       : events.get("expiration","?")[:10],
                    "last_changed"      : events.get("last changed","?")[:10],
                    "registrant_country": registrant_country or "?",
                    "domain_age_days"   : self._calc_age(events.get("registration","")),
                }
        except Exception:
            pass
        return None

    def _calc_age(self, date_str: str) -> int:
        try:
            from datetime import datetime
            dt  = datetime.fromisoformat(date_str[:10])
            now = datetime.now()
            return (now - dt).days
        except Exception:
            return -1

    # ── Law enforcement summary ────────────────────────────────────────────────
    def _build_le_summary(self, result: dict, analysis: dict) -> str:
        lines = []
        lines.append("═" * 60)
        lines.append("RAKSHAK THREAT ACTOR ATTRIBUTION REPORT")
        lines.append(f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
        lines.append("═" * 60)

        if result["actor_identified"]:
            lines.append(f"IDENTIFIED ACTOR  : {result['matched_group']}")
            lines.append(f"COUNTRY OF ORIGIN : {result['country_origin']}")
            lines.append(f"CONFIDENCE        : {int(result['attribution_confidence']*100)}% — {result['attribution_label']}")
        else:
            lines.append("ACTOR             : UNATTRIBUTED (insufficient correlating evidence)")

        lines.append("")
        lines.append("ATTRIBUTION EVIDENCE:")
        for ev in result["attribution_evidence"][:10]:
            lines.append(f"  • {ev}")

        if result["whois_data"]:
            lines.append("")
            lines.append("INFRASTRUCTURE OWNERSHIP:")
            for w in result["whois_data"][:5]:
                domain  = w.get("domain", w.get("ip","?"))
                country = w.get("registrant_country", w.get("country","?"))
                lines.append(f"  • {domain} → {w.get('registrar','?')} ({country})"
                             f" — registered {w.get('creation_date','?')}")

        dev = result["developer_fingerprint"]
        if dev.get("likely_country","Unknown") != "Unknown":
            lines.append("")
            lines.append("DEVELOPER FINGERPRINT:")
            lines.append(f"  • OS Environment : {dev.get('os_environment','?')}")
            lines.append(f"  • Likely Country : {dev.get('likely_country','?')}")
            cert = dev.get("cert_subject",{})
            if cert.get("org"):
                lines.append(f"  • Cert Org       : {cert['org']}")
            if cert.get("email"):
                lines.append(f"  • Developer Email: {cert['email']}")

        lines.append("")
        lines.append("RECOMMENDED ACTIONS:")
        if result["cert_in_alert_required"]:
            lines.append("  1. FILE CERT-In incident report immediately")
            lines.append("  2. Share IOCs with NTRO and RAW technical cell")
            lines.append("  3. Request ISP-level block on all identified C2 IPs")
            lines.append("  4. Forward to Ministry of Home Affairs Cyber Cell")
        else:
            lines.append("  1. Continue monitoring — insufficient for CERT-In filing")
            lines.append("  2. Submit hashes to VirusTotal and MalwareBazaar")
            lines.append("  3. Enrich with additional telemetry")

        lines.append("═" * 60)
        return "\n".join(lines)
