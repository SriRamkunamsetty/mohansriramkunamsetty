"""
RAKSHAK — Email Server Log Analyzer
Postfix · Exchange · Microsoft 365 Unified Audit Log
Detects BEC, phishing campaigns, silent mail forwarding,
account takeover, spam bursts
"""

import re
from collections import defaultdict, Counter
from datetime import datetime


# ── BEC / Phishing keyword patterns ──────────────────────────────────────────
BEC_SUBJECTS = [
    r'urgent.*wire.*transfer', r'invoice.*payment.*due',
    r'ceo.*request', r'confidential.*transfer',
    r'payment.*instruction.*changed', r'supplier.*bank.*detail',
    r'gift.*card.*purchase', r'payroll.*update',
]
PHISHING_INDICATORS = [
    r'(?:click|verify).*(?:account|login|password)',
    r'your.*account.*(?:suspended|compromised|locked)',
    r'confirm.*identity.*(?:24|48|72)\s*hours',
    r'unusual.*(?:sign-in|login|activity).*detected',
    r'password.*(?:expir|reset|change).*immediately',
]

# ── Postfix log patterns ───────────────────────────────────────────────────────
POSTFIX_SENT_PAT  = re.compile(
    r'(?P<ts>[\w\s:]+)\s+postfix.*?from=<(?P<from>[^>]+)>.*?'
    r'to=<(?P<to>[^>]+)>.*?status=(?P<status>\w+)',
    re.IGNORECASE
)
POSTFIX_AUTH_PAT  = re.compile(
    r'(?P<ts>[\w\s:]+)\s+postfix.*?sasl_username=(?P<user>\S+).*?'
    r'(?P<ip>[\d.]+)',
    re.IGNORECASE
)
POSTFIX_REJECT_PAT = re.compile(
    r'(?P<ts>[\w\s:]+)\s+postfix.*?NOQUEUE.*?'
    r'(?P<reason>Relay access denied|spam|block|reject)',
    re.IGNORECASE
)

# ── Exchange / O365 patterns ──────────────────────────────────────────────────
EXCHANGE_RULE_PAT = re.compile(
    r'(?:InboxRule|ForwardRule|RedirectRule).*?'
    r'(?:ForwardTo|RedirectTo)=(?P<dest>[^\s,]+)',
    re.IGNORECASE
)
O365_SIGNIN_PAT   = re.compile(
    r'(?P<ts>[\d\-T:.Z]+).*?'
    r'"Operation":"UserLoggedIn".*?"UserId":"(?P<user>[^"]+)".*?'
    r'"ClientIP":"(?P<ip>[^"]+)"',
    re.IGNORECASE
)
O365_FORWARD_PAT  = re.compile(
    r'"Operation":"Set-Mailbox".*?"ForwardingSmtpAddress":"(?P<dest>[^"]+)"',
    re.IGNORECASE
)


class EmailLogAnalyzer:
    """
    RAKSHAK Email Server Log Analyzer
    Email is the #1 initial access vector for APT groups attacking DRDO.
    This module catches attacks before they reach endpoints.
    """

    def analyze(self, log_text: str) -> dict:
        lines = log_text.splitlines()

        result = {
            "bec_signals"         : self._detect_bec(lines, log_text),
            "phishing_campaigns"  : self._detect_phishing(lines, log_text),
            "silent_forwarding"   : self._detect_silent_forwarding(lines),
            "account_takeover"    : self._detect_account_takeover(lines),
            "spam_burst"          : self._detect_spam_burst(lines),
            "suspicious_senders"  : self._flag_suspicious_senders(lines),
            "auth_failures"       : self._detect_auth_failures(lines),
            "email_risk_score"    : 0,
            "email_findings"      : [],
        }

        score = 0
        score += min(len(result["bec_signals"])        * 30, 40)
        score += min(len(result["phishing_campaigns"]) * 20, 30)
        score += min(len(result["silent_forwarding"])  * 35, 40)
        score += min(len(result["account_takeover"])   * 25, 30)
        score += min(result["spam_burst"].get("count", 0) * 2, 20)
        result["email_risk_score"] = min(score, 100)
        result["email_findings"]   = self._build_findings(result)
        return result

    def _detect_bec(self, lines: list, text: str) -> list:
        """Business Email Compromise — fraudulent wire transfer / invoice requests."""
        signals = []
        for pattern in BEC_SUBJECTS:
            m = re.search(pattern, text, re.IGNORECASE)
            if m:
                # Find surrounding context
                line_idx = next(
                    (i for i, l in enumerate(lines) if re.search(pattern, l, re.IGNORECASE)),
                    None
                )
                signals.append({
                    "pattern"    : pattern,
                    "matched"    : m.group(0)[:60],
                    "context"    : lines[line_idx][:120] if line_idx is not None else "",
                    "severity"   : "CRITICAL",
                    "threat_type": "BEC",
                    "description": "Business Email Compromise pattern — possible financial fraud",
                    "mitre"      : "T1566 — Phishing (BEC variant)",
                    "action"     : "Alert finance team immediately + verify via phone before any transfer",
                })
        return signals

    def _detect_phishing(self, lines: list, text: str) -> list:
        """Phishing campaign detection."""
        campaigns = []
        for pattern in PHISHING_INDICATORS:
            m = re.search(pattern, text, re.IGNORECASE)
            if m:
                campaigns.append({
                    "indicator"  : m.group(0)[:80],
                    "severity"   : "HIGH",
                    "threat_type": "PHISHING",
                    "description": "Phishing email pattern detected in mail logs",
                    "mitre"      : "T1566.001 — Spear-phishing Attachment",
                    "action"     : "Block sending domain + warn recipients + check clicked links",
                })
        return campaigns

    def _detect_silent_forwarding(self, lines: list) -> list:
        """
        CRITICAL: Attacker adds silent forwarding rule to copy all emails
        to external address — most dangerous post-compromise persistence.
        """
        forwarding = []
        for line in lines:
            # Exchange inbox rules
            m = EXCHANGE_RULE_PAT.search(line)
            if m:
                dest = m.group("dest")
                if not any(d in dest for d in ["@drdo.gov.in", "@nic.in", "@gov.in"]):
                    forwarding.append({
                        "forward_to" : dest,
                        "raw"        : line[:120],
                        "severity"   : "CRITICAL",
                        "description": f"Silent email forwarding to EXTERNAL address: {dest}",
                        "mitre"      : "T1114.003 — Email Forwarding Rule",
                        "action"     : "Remove forwarding rule + audit all emails sent in last 30 days",
                    })
            # O365 Set-Mailbox ForwardingSmtpAddress
            m2 = O365_FORWARD_PAT.search(line)
            if m2:
                dest = m2.group("dest")
                forwarding.append({
                    "forward_to" : dest,
                    "raw"        : line[:120],
                    "severity"   : "CRITICAL",
                    "description": f"O365 mailbox forwarding configured: {dest}",
                    "mitre"      : "T1114.003 — Email Forwarding Rule",
                    "action"     : "Disable forwarding + incident investigation + user notification",
                })
        return forwarding

    def _detect_account_takeover(self, lines: list) -> list:
        """Detect email account compromise via auth pattern analysis."""
        ato_signals = []
        user_ips = defaultdict(set)

        for line in lines:
            m = POSTFIX_AUTH_PAT.search(line)
            if m:
                user_ips[m.group("user")].add(m.group("ip"))

            m2 = O365_SIGNIN_PAT.search(line)
            if m2:
                user_ips[m2.group("user")].add(m2.group("ip"))

        for user, ips in user_ips.items():
            # Multiple IPs for same user = compromised account or shared credentials
            if len(ips) > 3:
                external = [ip for ip in ips
                            if not ip.startswith(("10.", "192.168.", "172."))]
                if external:
                    ato_signals.append({
                        "user"       : user,
                        "ip_count"   : len(ips),
                        "external_ips": list(external)[:5],
                        "severity"   : "HIGH",
                        "description": f"Account '{user}' accessed from {len(ips)} IPs "
                                       f"including {len(external)} external — possible ATO",
                        "mitre"      : "T1078 — Valid Accounts",
                        "action"     : "Force MFA + password reset + session termination",
                    })
        return ato_signals

    def _detect_spam_burst(self, lines: list) -> dict:
        """Detect spam burst — account used to send mass email."""
        sent_by = Counter()
        for line in lines:
            m = POSTFIX_SENT_PAT.search(line)
            if m and m.group("status") in ("sent", "queued"):
                sender = m.group("from")
                sent_by[sender] += 1

        top_senders = sent_by.most_common(5)
        burst_threshold = 50  # >50 emails = possible spam burst

        bursting = [
            {"sender": s, "count": c, "severity": "HIGH"}
            for s, c in top_senders if c > burst_threshold
        ]
        return {
            "count"     : sum(c for _, c in top_senders),
            "bursting"  : bursting,
            "top_senders": [{"sender": s, "count": c} for s, c in top_senders],
        }

    def _flag_suspicious_senders(self, lines: list) -> list:
        """Flag senders with suspicious domains."""
        SUSPICIOUS_DOMAIN_PATS = [
            r'@(?:gov-pk|mil-pk|nic-gov-in)\.', "Govt impersonation domain",
            r'@drdo-(?!gov\.in)', "DRDO name abuse",
            r'@\d{3,}\.', "Numeric domain — bulk mailer",
        ]
        flags = []
        for line in lines:
            for i in range(0, len(SUSPICIOUS_DOMAIN_PATS), 2):
                pattern = SUSPICIOUS_DOMAIN_PATS[i]
                reason  = SUSPICIOUS_DOMAIN_PATS[i + 1]
                m = re.search(pattern, line, re.IGNORECASE)
                if m:
                    flags.append({
                        "sender" : m.group(0),
                        "reason" : reason,
                        "raw"    : line[:100],
                        "severity": "HIGH",
                    })
        return flags[:10]

    def _detect_auth_failures(self, lines: list) -> dict:
        count   = 0
        sources = Counter()
        for line in lines:
            if re.search(
                r'authentication failed|SASL LOGIN.*failed|'
                r'535 5\.7\.8|invalid credentials',
                line, re.IGNORECASE
            ):
                count += 1
                ip = re.search(r'([\d.]{7,15})', line)
                if ip:
                    sources[ip.group(1)] += 1
        return {"count": count, "top_sources": sources.most_common(5),
                "brute_force": count >= 10}

    def _build_findings(self, result: dict) -> list:
        findings = []
        if result["silent_forwarding"]:
            findings.append({
                "severity"   : "CRITICAL",
                "category"   : "Silent Email Exfiltration",
                "description": f"{len(result['silent_forwarding'])} silent email forwarding "
                               f"rule(s) detected — all emails being copied to external attacker",
                "action"     : "IMMEDIATE: Remove rules + audit all forwarded email content",
            })
        if result["bec_signals"]:
            findings.append({
                "severity"   : "CRITICAL",
                "category"   : "Business Email Compromise",
                "description": f"{len(result['bec_signals'])} BEC email pattern(s) — "
                               f"possible financial fraud in progress",
                "action"     : "Alert finance department + freeze pending transfers + verify via phone",
            })
        if result["account_takeover"]:
            findings.append({
                "severity"   : "HIGH",
                "category"   : "Email Account Takeover",
                "description": f"{len(result['account_takeover'])} account(s) showing "
                               f"multi-IP access patterns consistent with compromise",
                "action"     : "Force MFA enrollment + password reset + session revocation",
            })
        return findings
