"""
RAKSHAK — Security Incident Report Generator (PDF)
DRDO-grade incident report from log analysis results
Watermark: DEVELOPED BY MOHAN SRIRAM KUNAMSETTY
"""

import os
from datetime import datetime, timezone
from pathlib import Path

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import mm
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
        HRFlowable, KeepTogether
    )
    from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
    REPORTLAB_OK = True
except ImportError:
    REPORTLAB_OK = False

# ── Brand colours ─────────────────────────────────────────────────────────────
C_BG       = colors.HexColor('#040608')
C_ACCENT   = colors.HexColor('#00e5a0')
C_ACCENT2  = colors.HexColor('#00aaff')
C_RED      = colors.HexColor('#ff3333')
C_ORANGE   = colors.HexColor('#ff9900')
C_YELLOW   = colors.HexColor('#ffdd00')
C_WHITE    = colors.HexColor('#ffffff')
C_DARK     = colors.HexColor('#0f1d2b')
C_MID      = colors.HexColor('#162538')
C_TEXT     = colors.HexColor('#d4f0d4')
C_SUBTEXT  = colors.HexColor('#7a9a8a')

SEV_COLORS = {
    "CRITICAL": colors.HexColor('#ff3333'),
    "HIGH"    : colors.HexColor('#ff9900'),
    "MEDIUM"  : colors.HexColor('#ffdd00'),
    "LOW"     : colors.HexColor('#44bb44'),
    "INFO"    : colors.HexColor('#00aaff'),
}

DEVELOPER_WATERMARK = "DEVELOPED BY MOHAN SRIRAM KUNAMSETTY"


def generate_incident_report(log_result: dict, output_dir: str,
                              case_id: str = "") -> str:
    """
    Generate a DRDO-grade PDF Security Incident Report from log analysis results.
    Returns path to generated PDF.
    """
    if not REPORTLAB_OK:
        raise ImportError("reportlab not installed. Run: pip install reportlab")

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    fname = f"RAKSHAK-INCIDENT-{case_id or 'REPORT'}.pdf"
    path  = str(output_dir / fname)

    doc = SimpleDocTemplate(
        path,
        pagesize    = A4,
        leftMargin  = 18*mm,
        rightMargin = 18*mm,
        topMargin   = 22*mm,
        bottomMargin= 22*mm,
        title       = f"RAKSHAK Security Incident Report — {case_id}",
        author      = "Mohan Sriram Kunamsetty",
        subject     = "Security Incident Report",
    )

    story = []
    w, h  = A4

    def _header_footer(canvas, doc):
        canvas.saveState()
        # ── Header bar ───────────────────────────────────────────────
        canvas.setFillColor(C_BG)
        canvas.rect(0, h - 18*mm, w, 18*mm, stroke=0, fill=1)
        canvas.setFont("Helvetica-Bold", 11)
        canvas.setFillColor(C_ACCENT)
        canvas.drawString(18*mm, h - 11*mm, "RAKSHAK  —  SECURITY INCIDENT REPORT")
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(C_SUBTEXT)
        canvas.drawRightString(w - 18*mm, h - 11*mm,
            f"DRDO Cybersecurity Division  |  Page {doc.page}")

        # ── Footer watermark ─────────────────────────────────────────
        canvas.setFillColor(C_BG)
        canvas.rect(0, 0, w, 14*mm, stroke=0, fill=1)
        canvas.setFont("Helvetica-Bold", 8)
        canvas.setFillColor(C_ACCENT)
        canvas.drawCentredString(w/2, 5.5*mm,
            f"★  {DEVELOPER_WATERMARK}  ★")
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(C_SUBTEXT)
        canvas.drawString(18*mm, 5.5*mm,
            f"Case: {case_id}  |  {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
        canvas.drawRightString(w - 18*mm, 5.5*mm,
            "⬛  SENSITIVE — FOR AUTHORISED PERSONNEL ONLY")
        canvas.restoreState()

    styles = getSampleStyleSheet()

    def _style(name, **kw):
        return ParagraphStyle(name, **kw)

    S = {
        "title"  : _style("T", fontName="Helvetica-Bold",  fontSize=26,
                           textColor=C_ACCENT,  spaceAfter=4,  alignment=TA_LEFT),
        "sub"    : _style("S", fontName="Helvetica",        fontSize=10,
                           textColor=C_SUBTEXT, spaceAfter=2,  alignment=TA_LEFT),
        "h2"     : _style("H2",fontName="Helvetica-Bold",  fontSize=13,
                           textColor=C_ACCENT,  spaceBefore=10,spaceAfter=4),
        "h3"     : _style("H3",fontName="Helvetica-Bold",  fontSize=10,
                           textColor=C_ACCENT2, spaceBefore=6, spaceAfter=3),
        "body"   : _style("B", fontName="Helvetica",        fontSize=9,
                           textColor=C_TEXT,    spaceAfter=4,  leading=14),
        "mono"   : _style("M", fontName="Courier",          fontSize=8,
                           textColor=C_ACCENT,  spaceAfter=3),
        "warn"   : _style("W", fontName="Helvetica-Bold",  fontSize=9,
                           textColor=C_RED,     spaceAfter=4),
        "center" : _style("C", fontName="Helvetica",        fontSize=9,
                           textColor=C_TEXT,    alignment=TA_CENTER),
    }

    risk    = log_result.get("risk_level","LOW")
    score   = log_result.get("risk_score", 0)
    raw     = log_result.get("raw",{})
    source  = log_result.get("source_name","Unknown")
    now_str = datetime.now(timezone.utc).strftime("%d %B %Y  —  %H:%M UTC")
    risk_c  = SEV_COLORS.get(risk, C_ACCENT)

    # ════════════════════════════════════════════════════════
    # PAGE 1 COVER
    # ════════════════════════════════════════════════════════
    story.append(Spacer(1, 8*mm))

    # Classification banner
    banner_data = [["⬛  SECURITY INCIDENT REPORT  ⬛"]]
    banner = Table(banner_data, colWidths=[w - 36*mm])
    banner.setStyle(TableStyle([
        ("BACKGROUND",  (0,0),(-1,-1), C_BG),
        ("TEXTCOLOR",   (0,0),(-1,-1), C_ACCENT),
        ("FONTNAME",    (0,0),(-1,-1), "Helvetica-Bold"),
        ("FONTSIZE",    (0,0),(-1,-1), 10),
        ("ALIGN",       (0,0),(-1,-1), "CENTER"),
        ("TOPPADDING",  (0,0),(-1,-1), 6),
        ("BOTTOMPADDING",(0,0),(-1,-1),6),
        ("BOX",         (0,0),(-1,-1), 1.5, C_ACCENT),
    ]))
    story.append(banner)
    story.append(Spacer(1, 6*mm))

    story.append(Spacer(1, 3*mm))
    story.append(Paragraph("SECURITY INCIDENT REPORT", S["title"]))
    story.append(Spacer(1, 3*mm))
    story.append(Paragraph(f"RAKSHAK v3.1  ·  DRDO Cybersecurity Division  ·  {now_str}", S["sub"]))
    story.append(Spacer(1, 2*mm))
    story.append(HRFlowable(width="100%", thickness=1.5, color=C_ACCENT, spaceAfter=8))

    # ── Cover summary cards ─────────────────────────────────────────────────
    def _card(label, value, bg, fg=C_WHITE):
        t = Table([[value], [label]],
                  colWidths=[(w - 56*mm)/4])
        t.setStyle(TableStyle([
            ("BACKGROUND",  (0,0),(-1,-1), bg),
            ("TEXTCOLOR",   (0,0),(0,0),   fg),
            ("TEXTCOLOR",   (0,1),(0,1),   C_SUBTEXT),
            ("FONTNAME",    (0,0),(0,0),   "Helvetica-Bold"),
            ("FONTNAME",    (0,1),(0,1),   "Helvetica"),
            ("FONTSIZE",    (0,0),(0,0),   18),
            ("FONTSIZE",    (0,1),(0,1),   7),
            ("ALIGN",       (0,0),(-1,-1), "CENTER"),
            ("TOPPADDING",  (0,0),(-1,-1), 5),
            ("BOTTOMPADDING",(0,0),(-1,-1),5),
            ("ROUNDEDCORNERS", (0,0),(-1,-1), 3),
        ]))
        return t

    card_row = Table([[
        _card("RISK LEVEL",    risk,                      risk_c),
        _card("RISK SCORE",    f"{score}/100",            C_DARK, C_ACCENT),
        _card("TOTAL EVENTS",  str(raw.get("total_events",0)), C_DARK, C_ACCENT),
        _card("FAILED LOGINS", str(len(raw.get("failed_logins",[]))), C_DARK, C_ORANGE),
    ]], colWidths=[(w-56*mm)/4]*4, hAlign="CENTER")
    card_row.setStyle(TableStyle([("ALIGN",(0,0),(-1,-1),"CENTER"),
                                   ("VALIGN",(0,0),(-1,-1),"MIDDLE")]))
    story.append(card_row)
    story.append(Spacer(1, 5*mm))

    # ── Executive summary ───────────────────────────────────────────────────
    story.append(Paragraph("Executive Summary", S["h2"]))
    story.append(Paragraph(log_result.get("executive_summary","No summary available."), S["body"]))
    story.append(HRFlowable(width="100%", thickness=0.5, color=C_MID, spaceAfter=4))

    # ── Quick stats ─────────────────────────────────────────────────────────
    story.append(Paragraph("Log Statistics", S["h2"]))
    bf_count  = len(log_result.get("brute_force",[]))
    ps_count  = len(log_result.get("port_scan_suspects",[]))
    priv_fail = len([e for e in raw.get("privilege_escalations",[]) if e["type"]=="SUDO_FAILURE"])
    web_scans = len(raw.get("web_scans",[]))
    sens_acc  = len(raw.get("sensitive_accesses",[]))

    stats_data = [
        ["Metric", "Count", "Severity"],
        ["Total Log Lines Analysed",    str(log_result.get("line_count",0)),   "INFO"],
        ["Total Security Events",       str(raw.get("total_events",0)),         "INFO"],
        ["Failed Login Attempts",       str(len(raw.get("failed_logins",[]))),  "HIGH" if len(raw.get("failed_logins",[])) > 5 else "LOW"],
        ["Successful Logins",           str(len(raw.get("successful_logins",[]))), "INFO"],
        ["Brute Force Attack Sources",  str(bf_count),   "CRITICAL" if bf_count else "INFO"],
        ["Port Scan Suspects",          str(ps_count),   "HIGH" if ps_count else "INFO"],
        ["Privilege Escalation Attempts",str(priv_fail), "HIGH" if priv_fail else "INFO"],
        ["Web Application Scans",       str(web_scans),  "MEDIUM" if web_scans else "INFO"],
        ["Sensitive File Accesses",     str(sens_acc),   "CRITICAL" if sens_acc else "INFO"],
    ]

    col_w = [(w-36*mm)*0.55, (w-36*mm)*0.15, (w-36*mm)*0.30]
    stats_table = Table(stats_data, colWidths=col_w)
    ts = [
        ("BACKGROUND",  (0,0), (-1,0), C_BG),
        ("TEXTCOLOR",   (0,0), (-1,0), C_ACCENT),
        ("FONTNAME",    (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTSIZE",    (0,0), (-1,-1),8),
        ("ROWBACKGROUNDS",(0,1),(-1,-1),[C_DARK, C_MID]),
        ("TEXTCOLOR",   (0,1), (1,-1), C_TEXT),
        ("GRID",        (0,0), (-1,-1),0.3, C_ACCENT),
        ("ALIGN",       (1,0), (-1,-1),"CENTER"),
        ("TOPPADDING",  (0,0), (-1,-1),4),
        ("BOTTOMPADDING",(0,0),(-1,-1),4),
    ]
    # Colour severity column
    for i, row in enumerate(stats_data[1:], 1):
        sev = row[2]
        c   = SEV_COLORS.get(sev, C_TEXT)
        ts.append(("TEXTCOLOR", (2,i), (2,i), c))
        ts.append(("FONTNAME",  (2,i), (2,i), "Helvetica-Bold"))
    stats_table.setStyle(TableStyle(ts))
    story.append(stats_table)
    story.append(Spacer(1, 5*mm))

    # ════════════════════════════════════════════════════════
    # FINDINGS SECTION
    # ════════════════════════════════════════════════════════
    story.append(Paragraph("Security Findings", S["h2"]))
    for i, finding in enumerate(log_result.get("findings",[]), 1):
        sev  = finding.get("severity","INFO")
        bg   = {
            "CRITICAL": colors.HexColor('#2a0a0a'),
            "HIGH"    : colors.HexColor('#2a1a00'),
            "MEDIUM"  : colors.HexColor('#1a1a00'),
            "INFO"    : C_DARK,
        }.get(sev, C_DARK)
        fc   = SEV_COLORS.get(sev, C_TEXT)
        data = [[
            Paragraph(f"<b>[{sev}]  {finding.get('category','')}</b>", _style("X", fontName="Helvetica-Bold", fontSize=9, textColor=fc)),
            Paragraph(f"Count: {finding.get('count',0)}", _style("Y", fontName="Helvetica", fontSize=8, textColor=C_SUBTEXT, alignment=TA_RIGHT))
        ],[
            Paragraph(finding.get("description",""), _style("Z", fontName="Helvetica", fontSize=8, textColor=C_TEXT)),
            ""
        ],[
            Paragraph(f"→ {finding.get('action','')}", _style("A2", fontName="Helvetica-Oblique", fontSize=8, textColor=C_ACCENT2)),
            ""
        ]]
        ft = Table(data, colWidths=[(w-36*mm)*0.8, (w-36*mm)*0.2])
        ft.setStyle(TableStyle([
            ("BACKGROUND", (0,0),(-1,-1), bg),
            ("BOX",        (0,0),(-1,-1), 1, fc),
            ("SPAN",       (0,1),(1,1)),
            ("SPAN",       (0,2),(1,2)),
            ("TOPPADDING", (0,0),(-1,-1), 4),
            ("BOTTOMPADDING",(0,0),(-1,-1),4),
            ("LEFTPADDING",(0,0),(-1,-1), 8),
        ]))
        story.append(KeepTogether([ft, Spacer(1, 3*mm)]))

    # ════════════════════════════════════════════════════════
    # TOP ATTACKING IPs
    # ════════════════════════════════════════════════════════
    top_ips = log_result.get("top_attacking_ips",[])
    if top_ips:
        story.append(Paragraph("Top Attacking IP Addresses", S["h2"]))
        from reportlab.platypus import Paragraph as P2
        _im = _style("IM", fontName="Courier", fontSize=7.5, textColor=C_TEXT, leading=10)
        _ih = _style("IH", fontName="Helvetica-Bold", fontSize=7.5, textColor=C_ACCENT, leading=10)
        ip_data = [[P2("IP Address",_ih), P2("Failed",_ih), P2("Web",_ih), P2("Ports",_ih), P2("Threat",_ih)]]
        for ip_info in top_ips[:10]:
            c2 = SEV_COLORS.get(ip_info["threat_level"], C_TEXT)
            _it = _style("IT", fontName="Helvetica-Bold", fontSize=7.5, textColor=c2, leading=10)
            ip_data.append([
                P2(ip_info["ip"], _im),
                P2(str(ip_info["failed_logins"]), _im),
                P2(str(ip_info["web_scans"]), _im),
                P2(str(ip_info["port_drops"]), _im),
                P2(ip_info["threat_level"], _it),
            ])
        ip_cw = [(w-36*mm)*f for f in [0.28,0.18,0.18,0.18,0.18]]
        ip_table = Table(ip_data, colWidths=ip_cw)
        ip_ts = [
            ("BACKGROUND",    (0,0),(-1,0), C_BG),
            ("TEXTCOLOR",     (0,0),(-1,0), C_ACCENT),
            ("FONTNAME",      (0,0),(-1,0), "Helvetica-Bold"),
            ("FONTSIZE",      (0,0),(-1,-1),8),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[C_DARK, C_MID]),
            ("TEXTCOLOR",     (0,1),(-1,-1), C_TEXT),
            ("GRID",          (0,0),(-1,-1),0.3, C_ACCENT),
            ("ALIGN",         (1,0),(-1,-1),"CENTER"),
            ("FONTNAME",      (0,1),(0,-1),"Courier"),
            ("TOPPADDING",    (0,0),(-1,-1),4),
            ("BOTTOMPADDING", (0,0),(-1,-1),4),
        ]
        for i, row in enumerate(ip_data[1:], 1):
            lvl = row[4]
            c   = SEV_COLORS.get(lvl, C_TEXT)
            ip_ts.append(("TEXTCOLOR", (4,i),(4,i), c))
            ip_ts.append(("FONTNAME",  (4,i),(4,i), "Helvetica-Bold"))
        ip_table.setStyle(TableStyle(ip_ts))
        story.append(ip_table)
        story.append(Spacer(1, 5*mm))

    # ════════════════════════════════════════════════════════
    # BRUTE FORCE DETAILS
    # ════════════════════════════════════════════════════════
    bf_list = log_result.get("brute_force",[])
    if bf_list:
        story.append(Paragraph("Brute Force Attack Details", S["h2"]))
        for bf in bf_list[:5]:
            users_str = ', '.join(bf['users_tried'][:10])
            bf_data = [
                [Paragraph(f"<b>Attacking IP: {bf['ip']}</b>", _style("BF", fontName="Helvetica-Bold", fontSize=10, textColor=C_RED))],
                [Paragraph(f"Attempts: {bf['attempts']}  |  Severity: {bf['severity']}  |  Type: {bf['threat_type']}", _style("BF2", fontName="Helvetica", fontSize=8, textColor=C_TEXT))],
                [Paragraph(f"Accounts targeted: {users_str}", _style("BF3", fontName="Courier", fontSize=7.5, textColor=C_ORANGE, wordWrap="CJK", leading=11))],
            ]
            bf_table = Table(bf_data, colWidths=[w-36*mm])
            bf_table.setStyle(TableStyle([
                ("BACKGROUND",   (0,0),(-1,-1), colors.HexColor('#1a0505')),
                ("BOX",          (0,0),(-1,-1), 1.5, C_RED),
                ("TOPPADDING",   (0,0),(-1,-1), 5),
                ("BOTTOMPADDING",(0,0),(-1,-1), 5),
                ("LEFTPADDING",  (0,0),(-1,-1), 10),
            ]))
            story.append(bf_table)
            story.append(Spacer(1, 2*mm))

    # ════════════════════════════════════════════════════════
    # RECOMMENDATIONS
    # ════════════════════════════════════════════════════════
    recs = log_result.get("recommendations",[])
    if recs:
        story.append(Spacer(1, 4*mm))
        story.append(Paragraph("Recommendations", S["h2"]))
        from reportlab.platypus import Paragraph as P
        from reportlab.lib.styles import ParagraphStyle as PS
        _rs = PS("rs", fontName="Helvetica", fontSize=7,
                 textColor=C_TEXT, leading=9, wordWrap="CJK")
        _rb = PS("rb", fontName="Helvetica-Bold", fontSize=7,
                 textColor=C_ACCENT, leading=9)
        rec_data = [[
            P("Priority", _rb), P("Action", _rb),
            P("Detail", _rb),   P("Timeline", _rb)
        ]]
        for rec in recs:
            c = SEV_COLORS.get(rec.get("priority",""), C_TEXT)
            _rp = PS("rp", fontName="Helvetica-Bold", fontSize=7,
                     textColor=c, leading=9)
            rec_data.append([
                P(rec.get("priority",""), _rp),
                P(rec.get("action","")[:50], _rs),
                P(rec.get("detail","")[:80], _rs),
                P(rec.get("timeline",""), _rs),
            ])
        rec_cw = [(w-36*mm)*f for f in [0.12,0.28,0.40,0.20]]
        rec_table = Table(rec_data, colWidths=rec_cw)
        rec_ts = [
            ("BACKGROUND",    (0,0),(-1,0), C_BG),
            ("TEXTCOLOR",     (0,0),(-1,0), C_ACCENT),
            ("FONTNAME",      (0,0),(-1,0), "Helvetica-Bold"),
            ("FONTSIZE",      (0,0),(-1,-1),7),
            ("ROWBACKGROUNDS",(0,1),(-1,-1),[C_DARK, C_MID]),
            ("TEXTCOLOR",     (0,1),(-1,-1), C_TEXT),
            ("GRID",          (0,0),(-1,-1),0.3, C_ACCENT),
            ("ALIGN",         (0,0),(0,-1),"CENTER"),
            ("VALIGN",        (0,0),(-1,-1),"TOP"),
            ("TOPPADDING",    (0,0),(-1,-1),4),
            ("BOTTOMPADDING", (0,0),(-1,-1),4),
            ("LEFTPADDING",   (0,0),(-1,-1),4),
            ("RIGHTPADDING",  (0,0),(-1,-1),4),
            ("WORDWRAP",      (0,0),(-1,-1), True),
        ]
        for i, row in enumerate(rec_data[1:], 1):
            c = SEV_COLORS.get(row[0], C_TEXT)
            rec_ts.append(("TEXTCOLOR", (0,i),(0,i), c))
            rec_ts.append(("FONTNAME",  (0,i),(0,i), "Helvetica-Bold"))
        rec_table.setStyle(TableStyle(rec_ts))
        story.append(rec_table)


    # ════════════════════════════════════════════════════════
    # ATTACK TOOL FINGERPRINT
    # ════════════════════════════════════════════════════════
    fps = log_result.get("attack_fingerprint", [])
    if fps:
        story.append(Paragraph("Attack Tool Fingerprint", S["h2"]))
        fp_data = [["Attacker IP", "Tool Identified", "Confidence", "Sophistication", "Description"]]
        for fp in fps[:5]:
            fp_data.append([
                fp.get("ip", "?"),
                fp.get("tool", "Unknown"),
                f"{fp.get('confidence', 0)}%",
                fp.get("sophistication", "?"),
                fp.get("description", "")[:50],
            ])
        fp_cw = [(w-36*mm)*f for f in [0.20, 0.22, 0.12, 0.14, 0.32]]
        fp_table = Table(fp_data, colWidths=fp_cw)
        fp_ts = [
            ("BACKGROUND",    (0,0), (-1,0), C_BG),
            ("TEXTCOLOR",     (0,0), (-1,0), C_ACCENT),
            ("FONTNAME",      (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",      (0,0), (-1,-1), 8),
            ("ROWBACKGROUNDS",(0,1), (-1,-1), [C_DARK, C_MID]),
            ("TEXTCOLOR",     (0,1), (-1,-1), C_TEXT),
            ("TEXTCOLOR",     (2,1), (2,-1), C_RED),
            ("FONTNAME",      (2,1), (2,-1), "Helvetica-Bold"),
            ("GRID",          (0,0), (-1,-1), 0.3, C_ACCENT),
            ("TOPPADDING",    (0,0), (-1,-1), 4),
            ("BOTTOMPADDING", (0,0), (-1,-1), 4),
        ]
        fp_table.setStyle(TableStyle(fp_ts))
        story.append(fp_table)
        story.append(Spacer(1, 4*mm))

    # ════════════════════════════════════════════════════════
    # SESSION RECONSTRUCTION
    # ════════════════════════════════════════════════════════
    sess = log_result.get("sessions", {})
    comp = sess.get("compromised_sessions", [])
    if comp:
        story.append(Paragraph("Attacker Session Reconstruction", S["h2"]))
        story.append(Paragraph(
            "CRITICAL: The following sessions show post-compromise attacker activity. "
            "This evidence is FIR-admissible under IT Act 2000 Section 66.",
            S["warn"]
        ))
        for s in comp[:3]:
            sc   = colors.HexColor("#ff3333") if s["session_risk_score"] >= 70 else C_ORANGE
            sdata= [
                [Paragraph(f"<b>Session: {s['attacker_ip']} → {s['username']} | {s['session_verdict']}</b>",
                           _style("SH", fontName="Helvetica-Bold", fontSize=9, textColor=sc))],
                [Paragraph(
                    f"Kill Chain: {' → '.join(s.get('kill_chain_stage', [])[:6])} | "
                    f"Risk Score: {s['session_risk_score']}/100 | "
                    f"Login: {s['login_timestamp']}",
                    _style("SB", fontName="Helvetica", fontSize=8, textColor=C_TEXT)
                )],
            ]
            for cmd in s.get("commands_run", [])[:5]:
                sdata.append([Paragraph(
                    f"[{cmd['category']}] {cmd['command'][:80]} — {cmd['description']}",
                    _style("SC", fontName="Courier", fontSize=7.5, textColor=C_ORANGE)
                )])
            for ev in s.get("evidence_for_fir", [])[:3]:
                sdata.append([Paragraph(
                    f"★ FIR EVIDENCE: {ev[:100]}",
                    _style("SE", fontName="Helvetica-Oblique", fontSize=7.5, textColor=C_ACCENT2)
                )])
            st = Table(sdata, colWidths=[w-36*mm])
            st.setStyle(TableStyle([
                ("BACKGROUND",   (0,0), (-1,-1), colors.HexColor("#1a0505")),
                ("BOX",          (0,0), (-1,-1), 1.5, sc),
                ("TOPPADDING",   (0,0), (-1,-1), 4),
                ("BOTTOMPADDING",(0,0), (-1,-1), 4),
                ("LEFTPADDING",  (0,0), (-1,-1), 8),
            ]))
            story.append(st)
            story.append(Spacer(1, 2*mm))

    # ════════════════════════════════════════════════════════
    # ADVANCED DETECTIONS SUMMARY
    # ════════════════════════════════════════════════════════
    adv_findings = []
    if log_result.get("tampering", {}).get("tampering_detected"):
        adv_findings.append(("LOG TAMPERING", "CRITICAL",
            "Attacker attempted to erase evidence. Log integrity: COMPROMISED"))
    if log_result.get("lateral_movement", {}).get("lateral_movement_detected"):
        adv_findings.append(("LATERAL MOVEMENT", "CRITICAL",
            "Internal network probing detected — ransomware/APT propagation risk"))
    if log_result.get("credential_stuffing", {}).get("credential_stuffing_detected"):
        adv_findings.append(("CREDENTIAL STUFFING", "HIGH",
            "Multiple accounts targeted — leaked credentials being tested"))
    anom = log_result.get("anomalies", {}).get("high_risk_anomalies", [])
    for a in anom[:2]:
        adv_findings.append(("ANOMALY", a.get("severity","HIGH"), a.get("description","")[:80]))

    if adv_findings:
        story.append(Paragraph("Advanced Detection Results", S["h2"]))
        for atype, asev, adesc in adv_findings:
            ac = SEV_COLORS.get(asev, C_TEXT)
            at = Table([[
                Paragraph(f"[{asev}] {atype}", _style("AT", fontName="Helvetica-Bold",
                           fontSize=9, textColor=ac)),
                Paragraph(adesc, _style("AD", fontName="Helvetica", fontSize=8, textColor=C_TEXT))
            ]], colWidths=[(w-36*mm)*0.25, (w-36*mm)*0.75])
            at.setStyle(TableStyle([
                ("BACKGROUND",(0,0),(-1,-1), colors.HexColor("#0f1d2b")),
                ("BOX",(0,0),(-1,-1), 1, ac),
                ("TOPPADDING",(0,0),(-1,-1), 4),
                ("BOTTOMPADDING",(0,0),(-1,-1), 4),
                ("LEFTPADDING",(0,0),(-1,-1), 6),
                ("VALIGN",(0,0),(-1,-1),"MIDDLE"),
            ]))
            story.append(at)
            story.append(Spacer(1, 2*mm))
        story.append(Spacer(1, 3*mm))

        # ── Certificate of analysis ─────────────────────────────────────────────
    story.append(Spacer(1, 8*mm))
    story.append(HRFlowable(width="100%", thickness=1, color=C_ACCENT))
    story.append(Spacer(1, 3*mm))
    cert_data = [[
        Paragraph("RAKSHAK v3.1.0", _style("CF1", fontName="Helvetica-Bold", fontSize=8, textColor=C_ACCENT)),
        Paragraph(f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}", _style("CF2", fontName="Helvetica", fontSize=8, textColor=C_SUBTEXT, alignment=TA_CENTER)),
        Paragraph(DEVELOPER_WATERMARK, _style("CF3", fontName="Helvetica-Bold", fontSize=8, textColor=C_ACCENT, alignment=TA_RIGHT)),
    ]]
    cert_t = Table(cert_data, colWidths=[(w-36*mm)/3]*3)
    cert_t.setStyle(TableStyle([("ALIGN",(0,0),(-1,-1),"LEFT"),("VALIGN",(0,0),(-1,-1),"MIDDLE")]))
    story.append(cert_t)

    doc.build(story, onFirstPage=_header_footer, onLaterPages=_header_footer)
    return path
