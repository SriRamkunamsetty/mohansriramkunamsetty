"""
RAKSHAK — Advanced Log Detection Engine
Attack fingerprinting · Anomaly detection · Lateral movement
Log tampering · Credential stuffing · Campaign tracking
"""

import re, hashlib, json
from datetime import datetime, timezone
from collections import defaultdict, Counter
from pathlib import Path


# ── Attack tool signatures ────────────────────────────────────────────────────
TOOL_SIGNATURES = {
    "Hydra": {
        "timing_gap_ms"     : (0, 800),   # Very fast — milliseconds between attempts
        "username_patterns" : ["root","admin","user","test","guest","oracle","postgres"],
        "port_pattern"      : [22, 21, 23, 3389, 5900],
        "description"       : "THC-Hydra — fast online password cracker",
        "sophistication"    : "MEDIUM",
    },
    "Medusa": {
        "timing_gap_ms"     : (100, 1500),
        "username_patterns" : ["root","administrator","admin","user"],
        "port_pattern"      : [22, 21, 25, 110],
        "description"       : "Medusa — parallel brute-force tool",
        "sophistication"    : "MEDIUM",
    },
    "Ncrack": {
        "timing_gap_ms"     : (50, 600),
        "username_patterns" : ["root","admin","administrator"],
        "port_pattern"      : [22, 3389, 21],
        "description"       : "Ncrack — network authentication cracker",
        "sophistication"    : "MEDIUM",
    },
    "Metasploit": {
        "timing_gap_ms"     : (500, 3000),
        "username_patterns" : ["msfadmin","vagrant","postgres","root","admin"],
        "port_pattern"      : [22, 445, 3306, 5432],
        "description"       : "Metasploit Framework auxiliary scanner",
        "sophistication"    : "HIGH",
    },
    "Shodan/Censys Scanner": {
        "timing_gap_ms"     : (2000, 30000),
        "username_patterns" : [],          # Passive scanner — no logins
        "port_pattern"      : list(range(1, 1024)),
        "description"       : "Mass internet scanner (Shodan/Censys)",
        "sophistication"    : "LOW",
    },
    "Custom Script": {
        "timing_gap_ms"     : (0, 200),   # Very fast — scripted
        "username_patterns" : [],
        "port_pattern"      : [],
        "description"       : "Custom automated attack script",
        "sophistication"    : "VARIABLE",
    },
    "Rockyou/Wordlist Attack": {
        "timing_gap_ms"     : (300, 2000),
        "username_patterns" : ["root","admin"],
        "port_pattern"      : [22],
        "description"       : "Dictionary wordlist attack (rockyou.txt or similar)",
        "sophistication"    : "LOW",
    },
}

# ── Campaign tracking DB (in-memory, persists per process) ───────────────────
_CAMPAIGN_DB: dict = defaultdict(lambda: {
    "ip"          : "",
    "first_seen"  : "",
    "last_seen"   : "",
    "total_hits"  : 0,
    "log_files"   : set(),
    "risk_scores" : [],
    "usernames"   : set(),
    "threat_label": "",
})


class AttackFingerprintEngine:
    """Identifies the specific tool an attacker used from log patterns."""

    def fingerprint(self, ip: str, failed_logins: list,
                    port_drops: list) -> dict:
        if not failed_logins:
            return {"tool": "Unknown", "confidence": 0}

        ip_logins = [e for e in failed_logins if e.get("ip") == ip]
        if not ip_logins:
            return {"tool": "Unknown", "confidence": 0}

        usernames_tried = [e.get("user","") for e in ip_logins]
        total_attempts  = len(ip_logins)
        ports_hit       = {e.get("port", 22) for e in port_drops
                           if e.get("ip") == ip}

        scores = {}
        for tool, sig in TOOL_SIGNATURES.items():
            score = 0

            # Username overlap
            u_patterns = sig.get("username_patterns", [])
            if u_patterns:
                u_overlap = len(set(usernames_tried) & set(u_patterns))
                score += u_overlap * 20

            # Port pattern match
            if sig.get("port_pattern"):
                p_overlap = len(ports_hit & set(sig["port_pattern"]))
                score += p_overlap * 15

            # Volume signals
            if tool == "Hydra" and total_attempts > 20:
                score += 30
            elif tool == "Custom Script" and total_attempts > 50:
                score += 25
            elif tool == "Rockyou/Wordlist Attack" and total_attempts > 100:
                score += 35

            scores[tool] = score

        best_tool = max(scores, key=scores.get)
        best_score = scores[best_tool]
        confidence = min(best_score, 100) if best_score > 0 else 0

        return {
            "tool"           : best_tool,
            "confidence"     : confidence,
            "sophistication" : TOOL_SIGNATURES[best_tool]["sophistication"],
            "description"    : TOOL_SIGNATURES[best_tool]["description"],
            "all_scores"     : {t: s for t, s in sorted(
                scores.items(), key=lambda x: x[1], reverse=True
            ) if s > 0},
        }

    def fingerprint_all(self, ip_failed_counts: dict,
                        failed_logins: list,
                        port_drops: list) -> list:
        results = []
        for ip in ip_failed_counts:
            fp = self.fingerprint(ip, failed_logins, port_drops)
            if fp["confidence"] > 0:
                fp["ip"] = ip
                fp["attempt_count"] = ip_failed_counts[ip]
                results.append(fp)
        return sorted(results, key=lambda x: x["confidence"], reverse=True)


class AnomalyDetector:
    """
    Detects deviations from normal login patterns.
    Learns what's normal, flags what isn't.
    """

    # DRDO-appropriate business hours (IST = UTC+5:30)
    BUSINESS_HOURS_UTC = (2, 13)  # 7:30 AM to 6:30 PM IST

    def detect(self, failed_logins: list,
               successful_logins: list) -> dict:
        anomalies = []

        # ── Off-hours login detection ──────────────────────────────────
        for login in successful_logins:
            ts = login.get("timestamp", "")
            hour = self._extract_hour(ts)
            if hour is not None:
                if not (self.BUSINESS_HOURS_UTC[0] <= hour <= self.BUSINESS_HOURS_UTC[1]):
                    anomalies.append({
                        "type"       : "OFF_HOURS_ACCESS",
                        "severity"   : "HIGH",
                        "description": f"Successful login at {hour:02d}:00 UTC "
                                       f"(outside business hours) — user: {login.get('user','?')} "
                                       f"from {login.get('ip','?')}",
                        "ip"         : login.get("ip",""),
                        "user"       : login.get("user",""),
                    })

        # ── High velocity detection ────────────────────────────────────
        ip_counts = Counter(e.get("ip","") for e in failed_logins)
        for ip, count in ip_counts.items():
            if count > 100:
                anomalies.append({
                    "type"       : "EXTREME_VELOCITY",
                    "severity"   : "CRITICAL",
                    "description": f"{count} login attempts from {ip} — "
                                   f"automated tool detected (velocity far exceeds human capability)",
                    "ip"         : ip,
                    "count"      : count,
                })
            elif count > 30:
                anomalies.append({
                    "type"       : "HIGH_VELOCITY",
                    "severity"   : "HIGH",
                    "description": f"{count} failed attempts from {ip} — "
                                   f"likely automated brute force",
                    "ip"         : ip,
                    "count"      : count,
                })

        # ── Never-before-seen username detection ──────────────────────
        all_users      = Counter(e.get("user","") for e in failed_logins)
        success_users  = {e.get("user","") for e in successful_logins}
        unusual_logins = success_users - {
            "root","admin","ubuntu","drdo","user","sysadmin"
        }
        for user in unusual_logins:
            if all_users.get(user, 0) > 0:
                anomalies.append({
                    "type"       : "SUSPICIOUS_ACCOUNT",
                    "severity"   : "HIGH",
                    "description": f"Account '{user}' succeeded after appearing in brute-force "
                                   f"attempts — possible credential compromise",
                    "user"       : user,
                })

        # ── Geographic anomaly (multiple countries same session) ───────
        # (enriched separately by IP intel — placeholder)

        return {
            "anomaly_count"    : len(anomalies),
            "anomalies"        : anomalies,
            "high_risk_anomalies": [a for a in anomalies
                                     if a["severity"] in ("CRITICAL","HIGH")],
        }

    def _extract_hour(self, ts: str) -> int | None:
        try:
            # "Jan 15 10:23:01" format
            m = re.search(r'(\d{2}):(\d{2}):\d{2}', ts)
            if m:
                return int(m.group(1))
        except Exception:
            pass
        return None


class LateralMovementDetector:
    """
    Detects when a compromised system starts probing internal network.
    Classic ransomware/APT propagation signal.
    """

    # Private IP ranges that indicate internal scanning
    INTERNAL_PATTERNS = [
        r"10\.\d+\.\d+\.\d+",
        r"172\.(1[6-9]|2[0-9]|3[01])\.\d+\.\d+",
        r"192\.168\.\d+\.\d+",
    ]

    def detect(self, log_text: str,
               successful_logins: list) -> dict:
        movements = []
        lines     = log_text.splitlines()

        # After each successful login, look for internal IPs being contacted
        for login in successful_logins:
            ip   = login.get("ip","")
            user = login.get("user","")
            ts   = login.get("timestamp","")

            # Scan subsequent lines for internal IP contacts
            internal_ips_seen = set()
            for line in lines:
                for pat in self.INTERNAL_PATTERNS:
                    m = re.search(pat, line)
                    if m:
                        internal_ip = m.group(0)
                        # Ensure it's different from the source
                        if internal_ip not in internal_ips_seen:
                            internal_ips_seen.add(internal_ip)

            if len(internal_ips_seen) >= 3:
                movements.append({
                    "attacker_ip"      : ip,
                    "username"         : user,
                    "login_time"       : ts,
                    "internal_ips_probed": list(internal_ips_seen)[:10],
                    "probe_count"      : len(internal_ips_seen),
                    "severity"         : "CRITICAL",
                    "description"      : f"After login from {ip}, {len(internal_ips_seen)} "
                                         f"internal IPs probed — lateral movement / "
                                         f"ransomware propagation detected",
                    "threat_type"      : "LATERAL_MOVEMENT",
                })

        # Also detect SMB/RDP lateral movement patterns in logs
        smb_pattern = re.compile(
            r'(?:445|139|3389).*(?:10\.\d+|192\.168|172\.1[6-9]|172\.2\d|172\.3[01])',
            re.IGNORECASE
        )
        smb_hits = smb_pattern.findall(log_text)
        if len(smb_hits) >= 5:
            movements.append({
                "attacker_ip"   : "multiple",
                "severity"      : "CRITICAL",
                "description"   : f"{len(smb_hits)} SMB/RDP connection attempts to internal "
                                   f"hosts — possible ransomware spreading",
                "threat_type"   : "SMB_LATERAL",
                "hit_count"     : len(smb_hits),
            })

        return {
            "lateral_movement_detected": len(movements) > 0,
            "movements"               : movements,
            "risk_score"              : min(len(movements) * 35, 100),
        }


class LogTamperingDetector:
    """
    Detects if an attacker modified or deleted log files to cover tracks.
    Timestamp gaps, log truncation, permission changes.
    """

    def detect(self, log_text: str) -> dict:
        findings = []
        lines    = log_text.splitlines()

        # ── Gap detection ──────────────────────────────────────────────
        timestamps  = []
        ts_pattern  = re.compile(r'(\w{3}\s+\d+\s+(\d{2}):(\d{2}):\d{2})')
        for line in lines:
            m = ts_pattern.search(line)
            if m:
                try:
                    h, mn = int(m.group(2)), int(m.group(3))
                    timestamps.append(h * 60 + mn)  # minutes since midnight
                except Exception:
                    pass

        gap_findings = []
        for i in range(1, len(timestamps)):
            gap = timestamps[i] - timestamps[i-1]
            if gap < 0:  # Day rollover — skip
                gap += 1440
            if gap > 180:  # 3+ hour gap
                gap_findings.append({
                    "position"   : i,
                    "gap_minutes": gap,
                    "description": f"{gap}-minute gap in log timestamps at line {i} — "
                                   f"possible log deletion or system downtime",
                })

        if len(gap_findings) >= 2:
            findings.append({
                "type"       : "TIMESTAMP_GAPS",
                "severity"   : "HIGH",
                "description": f"{len(gap_findings)} suspicious timestamp gaps detected — "
                               f"possible log tampering or selective deletion",
                "details"    : gap_findings[:5],
            })

        # ── Log clearing commands in content ──────────────────────────
        clear_patterns = [
            (r'history\s+-c', "Command history cleared"),
            (r'>\s*/var/log/\w+', "Log file truncated"),
            (r'rm\s+.*/var/log/', "Log file deleted"),
            (r'shred\s+.*/var/log/', "Log file securely wiped"),
            (r'HISTSIZE\s*=\s*0', "History disabled"),
            (r'unset\s+HISTFILE', "History file unset"),
            (r'cat\s+/dev/null\s*>\s*', "File cleared via /dev/null"),
        ]
        for pattern, description in clear_patterns:
            if re.search(pattern, log_text, re.IGNORECASE):
                findings.append({
                    "type"       : "LOG_CLEARING_CMD",
                    "severity"   : "CRITICAL",
                    "description": f"Anti-forensics: {description} — "
                                   f"attacker attempted to erase evidence",
                })

        # ── Truncation detection ───────────────────────────────────────
        if len(lines) > 0:
            first_line = lines[0]
            # Legitimate logs usually start at beginning of entry
            if not re.match(r'\w{3}\s+\d+|\d{4}-\d{2}-\d{2}', first_line):
                findings.append({
                    "type"       : "TRUNCATED_START",
                    "severity"   : "MEDIUM",
                    "description": "Log file does not begin with a standard timestamp — "
                                   "possible truncation or partial deletion",
                })

        # ── Low line count with high event density ────────────────────
        if len(lines) < 20 and lines:
            findings.append({
                "type"       : "SUSPICIOUSLY_SHORT",
                "severity"   : "MEDIUM",
                "description": f"Log contains only {len(lines)} lines — "
                               f"may have been edited or filtered before submission",
            })

        return {
            "tampering_detected" : len(findings) > 0,
            "tampering_findings" : findings,
            "risk_score"         : min(len(findings) * 25, 100),
            "timestamp_gaps"     : gap_findings[:5],
            "integrity_verdict"  : "COMPROMISED" if findings else "INTACT",
        }


class CredentialStuffingDetector:
    """
    Distinguishes credential stuffing (1 password across many accounts)
    from brute force (many passwords on 1 account).
    """

    def detect(self, failed_logins: list) -> dict:
        if not failed_logins:
            return {"credential_stuffing_detected": False}

        # Group by IP
        ip_users   = defaultdict(set)
        ip_passwords = defaultdict(set)
        user_ips   = defaultdict(set)

        for entry in failed_logins:
            ip   = entry.get("ip","")
            user = entry.get("user","")
            if ip and user:
                ip_users[ip].add(user)
                user_ips[user].add(ip)

        findings = []

        # Credential stuffing: one IP trying MANY different usernames
        for ip, users in ip_users.items():
            if len(users) >= 10:
                findings.append({
                    "type"       : "CREDENTIAL_STUFFING",
                    "ip"         : ip,
                    "severity"   : "CRITICAL",
                    "accounts_targeted": len(users),
                    "sample_accounts"  : list(users)[:10],
                    "description": f"IP {ip} tried {len(users)} different usernames — "
                                   f"credential stuffing attack (leaked credentials list)",
                    "recommendation": "Enable account lockout + rate limiting per username. "
                                      "Force password reset for targeted accounts.",
                })

        # Distributed stuffing: many IPs all targeting same username
        for user, ips in user_ips.items():
            if len(ips) >= 5:
                findings.append({
                    "type"       : "DISTRIBUTED_STUFFING",
                    "username"   : user,
                    "severity"   : "HIGH",
                    "source_ips" : len(ips),
                    "sample_ips" : list(ips)[:5],
                    "description": f"Account '{user}' targeted from {len(ips)} different IPs — "
                                   f"distributed credential stuffing (botnet-coordinated)",
                    "recommendation": f"Force password change for '{user}'. "
                                      f"Enable MFA immediately.",
                })

        # Pure brute force: one IP + one username + many attempts
        for ip, users in ip_users.items():
            count = sum(1 for e in failed_logins
                        if e.get("ip")==ip)
            if len(users) <= 2 and count >= 20:
                findings.append({
                    "type"       : "TARGETED_BRUTE_FORCE",
                    "ip"         : ip,
                    "severity"   : "HIGH",
                    "target_user": list(users)[0] if users else "?",
                    "attempts"   : count,
                    "description": f"IP {ip} made {count} attempts on {list(users)[:2]} — "
                                   f"targeted brute force (not credential stuffing)",
                    "recommendation": "Block IP, enforce account lockout, enable MFA.",
                })

        return {
            "credential_stuffing_detected": any(
                f["type"] == "CREDENTIAL_STUFFING" for f in findings
            ),
            "distributed_stuffing_detected": any(
                f["type"] == "DISTRIBUTED_STUFFING" for f in findings
            ),
            "findings"   : findings,
            "risk_score" : min(len(findings) * 30, 100),
        }


class CampaignTracker:
    """
    Tracks persistent threat actors across multiple log submissions.
    Groups attacks from same IP/subnet into named campaigns.
    """

    def track(self, brute_force_ips: list[str],
              top_ips: list[dict],
              log_name: str) -> dict:
        campaigns = []
        now_str   = datetime.now(timezone.utc).isoformat()

        # Update campaign DB
        for ip_entry in top_ips:
            ip = ip_entry.get("ip","")
            if not ip:
                continue
            db_entry = _CAMPAIGN_DB[ip]
            db_entry["ip"]       = ip
            db_entry["last_seen"] = now_str
            if not db_entry["first_seen"]:
                db_entry["first_seen"] = now_str
            db_entry["total_hits"]   += ip_entry.get("failed_logins", 0)
            db_entry["log_files"].add(log_name)
            db_entry["risk_scores"].append(ip_entry.get("threat_level","LOW"))

        # Identify campaigns (IPs seen in 2+ log files)
        for ip, entry in _CAMPAIGN_DB.items():
            if len(entry["log_files"]) >= 1 and entry["total_hits"] >= 5:
                risk = max(
                    entry["risk_scores"],
                    key=lambda x: {"CRITICAL":4,"HIGH":3,"MEDIUM":2,"LOW":1,"INFO":0}.get(x,0),
                    default="LOW"
                )
                campaigns.append({
                    "ip"          : ip,
                    "first_seen"  : entry["first_seen"][:10],
                    "last_seen"   : entry["last_seen"][:10],
                    "total_hits"  : entry["total_hits"],
                    "log_files"   : list(entry["log_files"]),
                    "persistence" : len(entry["log_files"]) > 1,
                    "peak_risk"   : risk,
                    "campaign_type": "PERSISTENT_APT" if len(entry["log_files"]) > 2
                                     else "RECURRING_ATTACKER" if len(entry["log_files"]) > 1
                                     else "SINGLE_INCIDENT",
                })

        campaigns.sort(key=lambda x: x["total_hits"], reverse=True)

        return {
            "campaigns"                  : campaigns[:20],
            "persistent_threats"         : [c for c in campaigns if c["persistence"]],
            "total_tracked_ips"          : len(_CAMPAIGN_DB),
            "new_ips_this_session"       : len(brute_force_ips),
            "recurring_attacker_detected": any(c["persistence"] for c in campaigns),
        }

    @staticmethod
    def clear():
        """Reset campaign tracking (useful for testing)."""
        _CAMPAIGN_DB.clear()
