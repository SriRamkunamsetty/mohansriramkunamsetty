"""
RAKSHAK — DNS Log Analyzer
DNS tunneling detection · DGA detection · Fast flux · Entropy analysis
APT36 extensively uses DNS tunneling — this module catches it
"""

import re, math, statistics
from collections import defaultdict, Counter
from datetime import datetime, timezone


# ── Known legitimate high-volume domains (allowlist) ─────────────────────────
LEGIT_DOMAINS = {
    "google.com", "googleapis.com", "gstatic.com", "microsoft.com",
    "windows.com", "windowsupdate.com", "office.com", "live.com",
    "amazonaws.com", "cloudfront.net", "akamai.net", "fastly.net",
    "cloudflare.com", "digicert.com", "ocsp.verisign.com",
    "akamaitechnologies.com", "cdn.jsdelivr.net", "github.com",
}

# ── DGA characteristics ────────────────────────────────────────────────────────
DGA_ENTROPY_THRESHOLD = 3.5      # High entropy = random = DGA
DGA_MIN_LENGTH        = 8        # Short domains less suspicious
DGA_CONSONANT_RATIO   = 0.65     # DGA domains have too many consonants

# ── DNS tunneling signals ─────────────────────────────────────────────────────
TUNNEL_SUBDOMAIN_LENGTH = 30     # Legitimate subdomains rarely exceed 30 chars
TUNNEL_QUERY_RATE       = 100    # >100 queries/minute = data transfer
TUNNEL_ENTROPY_THRESHOLD= 4.0    # Base64/hex encoded data has high entropy

# ── Fast flux signals ─────────────────────────────────────────────────────────
FAST_FLUX_IP_THRESHOLD  = 5      # >5 IPs for same domain = fast flux
FAST_FLUX_TTL_THRESHOLD = 300    # Very low TTL = fast flux

# ── Log format patterns ───────────────────────────────────────────────────────
DNS_LOG_PATTERNS = [
    # BIND/named query log: "queries: info: client 10.0.0.1#1234: query: evil.com IN A"
    re.compile(
        r'client\s+(?P<client>[\d.]+)#\d+.*query:\s+(?P<domain>[\w.\-]+)\s+IN\s+(?P<type>\w+)',
        re.IGNORECASE
    ),
    # Windows DNS debug log
    re.compile(
        r'(?P<timestamp>[\d/]+\s+[\d:]+)\s+\w+\s+PACKET.*\s+(?P<type>Q|A)\s+\[.*\]\s+(?P<domain>[\w.\-]+)',
        re.IGNORECASE
    ),
    # Generic DNS line
    re.compile(
        r'(?:query|resolve|lookup).*?(?P<domain>[a-z0-9](?:[a-z0-9\-]{0,61}[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9\-]{0,61}[a-z0-9])?)*\.[a-z]{2,})',
        re.IGNORECASE
    ),
]


class DNSAnalyzer:
    """
    RAKSHAK DNS Log Analyzer
    Detects DNS-based attacks invisible to firewall and auth.log analysis.
    """

    def analyze(self, log_text: str, case_id: str = "") -> dict:
        lines   = log_text.splitlines()
        queries = self._parse_dns_queries(lines)

        result = {
            "total_queries"          : len(queries),
            "unique_domains"         : len({q["domain"] for q in queries}),
            "dns_tunneling"          : self._detect_tunneling(queries),
            "dga_domains"            : self._detect_dga(queries),
            "fast_flux"              : self._detect_fast_flux(queries),
            "suspicious_domains"     : self._flag_suspicious(queries),
            "top_queried_domains"    : self._top_domains(queries),
            "query_rate_anomaly"     : self._query_rate_anomaly(queries),
            "dns_risk_score"         : 0,
            "dns_findings"           : [],
        }

        # Compute overall DNS risk score
        score = 0
        score += min(len(result["dns_tunneling"]) * 35, 40)
        score += min(len(result["dga_domains"]) * 15, 30)
        score += min(len(result["fast_flux"]) * 20, 25)
        score += min(len(result["suspicious_domains"]) * 5, 20)
        result["dns_risk_score"] = min(score, 100)

        # Build findings
        result["dns_findings"] = self._build_findings(result)
        return result

    def _parse_dns_queries(self, lines: list) -> list:
        queries = []
        for line in lines:
            for pat in DNS_LOG_PATTERNS:
                m = pat.search(line)
                if m:
                    domain = m.group("domain").lower().strip(".")
                    # Skip if in allowlist
                    root = ".".join(domain.split(".")[-2:])
                    if root in LEGIT_DOMAINS:
                        break
                    queries.append({
                        "domain"    : domain,
                        "client"    : m.groupdict().get("client", ""),
                        "qtype"     : m.groupdict().get("type", "A"),
                        "raw"       : line[:120],
                        "subdomain" : ".".join(domain.split(".")[:-2]) if domain.count(".") >= 2 else "",
                    })
                    break
        return queries

    def _shannon_entropy(self, s: str) -> float:
        if not s:
            return 0.0
        freq = Counter(s)
        length = len(s)
        return -sum((c/length) * math.log2(c/length) for c in freq.values())

    def _detect_tunneling(self, queries: list) -> list:
        """Detect DNS tunneling via subdomain entropy and length analysis."""
        suspects = []
        domain_subdomains = defaultdict(list)

        for q in queries:
            sub = q.get("subdomain", "")
            if sub:
                domain_subdomains[q["domain"]].append(sub)

        for domain, subdomains in domain_subdomains.items():
            for sub in subdomains:
                entropy = self._shannon_entropy(sub)
                if len(sub) > TUNNEL_SUBDOMAIN_LENGTH and entropy > TUNNEL_ENTROPY_THRESHOLD:
                    # High entropy + long subdomain = encoded data
                    suspects.append({
                        "domain"     : domain,
                        "subdomain"  : sub[:60],
                        "entropy"    : round(entropy, 3),
                        "length"     : len(sub),
                        "severity"   : "CRITICAL",
                        "threat_type": "DNS_TUNNELING",
                        "description": f"Subdomain entropy {entropy:.2f} (>{TUNNEL_ENTROPY_THRESHOLD}) "
                                       f"and length {len(sub)} chars — data encoded in DNS query",
                        "mitre"      : "T1071.004 — Application Layer Protocol: DNS",
                    })

        return suspects[:20]

    def _detect_dga(self, queries: list) -> list:
        """Detect Domain Generation Algorithm domains."""
        dga_suspects = []
        seen = set()

        for q in queries:
            domain = q["domain"]
            parts  = domain.split(".")
            if len(parts) < 2:
                continue
            subdomain_part = parts[0]
            if subdomain_part in seen or len(subdomain_part) < DGA_MIN_LENGTH:
                continue
            seen.add(subdomain_part)

            entropy = self._shannon_entropy(subdomain_part)
            consonants = sum(1 for c in subdomain_part if c in 'bcdfghjklmnpqrstvwxyz')
            consonant_ratio = consonants / len(subdomain_part) if subdomain_part else 0

            dga_score = 0
            reasons   = []
            if entropy > DGA_ENTROPY_THRESHOLD:
                dga_score += 40
                reasons.append(f"High entropy: {entropy:.2f}")
            if consonant_ratio > DGA_CONSONANT_RATIO:
                dga_score += 30
                reasons.append(f"High consonant ratio: {consonant_ratio:.0%}")
            if len(subdomain_part) > 15:
                dga_score += 20
                reasons.append(f"Long domain: {len(subdomain_part)} chars")
            if not any(v in subdomain_part for v in 'aeiou'):
                dga_score += 30
                reasons.append("No vowels — random string")

            if dga_score >= 60:
                dga_suspects.append({
                    "domain"      : domain,
                    "dga_score"   : dga_score,
                    "entropy"     : round(entropy, 3),
                    "consonant_r" : round(consonant_ratio, 3),
                    "reasons"     : reasons,
                    "severity"    : "HIGH",
                    "threat_type" : "DGA_DOMAIN",
                    "description" : f"Possible DGA domain — {', '.join(reasons)}",
                    "mitre"       : "T1568.002 — Domain Generation Algorithms",
                })

        return sorted(dga_suspects, key=lambda x: x["dga_score"], reverse=True)[:15]

    def _detect_fast_flux(self, queries: list) -> list:
        """Detect fast flux DNS — same domain, many different IPs, very low TTL."""
        domain_ips = defaultdict(set)
        for q in queries:
            # Look for IP patterns in raw line (DNS responses)
            ips = re.findall(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b', q.get("raw", ""))
            for ip in ips:
                if not ip.startswith(("10.", "192.168.", "127.")):
                    domain_ips[q["domain"]].add(ip)

        fast_flux = []
        for domain, ips in domain_ips.items():
            if len(ips) >= FAST_FLUX_IP_THRESHOLD:
                fast_flux.append({
                    "domain"     : domain,
                    "ip_count"   : len(ips),
                    "sample_ips" : list(ips)[:8],
                    "severity"   : "HIGH",
                    "threat_type": "FAST_FLUX",
                    "description": f"{len(ips)} different IPs for '{domain}' — "
                                   f"botnet fast flux infrastructure",
                    "mitre"      : "T1568.001 — Fast Flux DNS",
                })
        return sorted(fast_flux, key=lambda x: x["ip_count"], reverse=True)

    def _flag_suspicious(self, queries: list) -> list:
        suspicious = []
        SUSPICIOUS_PATTERNS = [
            (r'\.(tk|ml|ga|cf|gq|xyz|top|click|pw|loan)$', "Suspicious free TLD"),
            (r'(ngrok|serveo|pagekite|localhost\.run)', "Tunneling service domain"),
            (r'(pastebin|hastebin|paste\.ee)', "Paste site — config delivery"),
            (r'(\d{5,}\.)', "Numeric subdomain — possible encoding"),
            (r'(tor2web|onion\.to|onion\.link)', "Tor-to-web proxy"),
        ]
        seen = set()
        for q in queries:
            domain = q["domain"]
            if domain in seen:
                continue
            seen.add(domain)
            for pattern, reason in SUSPICIOUS_PATTERNS:
                if re.search(pattern, domain, re.IGNORECASE):
                    suspicious.append({
                        "domain": domain, "reason": reason, "severity": "MEDIUM"
                    })
                    break
        return suspicious[:20]

    def _top_domains(self, queries: list) -> list:
        counts = Counter(q["domain"] for q in queries)
        return [{"domain": d, "count": c} for d, c in counts.most_common(10)]

    def _query_rate_anomaly(self, queries: list) -> dict:
        if len(queries) > TUNNEL_QUERY_RATE:
            return {
                "detected"   : True,
                "total"      : len(queries),
                "threshold"  : TUNNEL_QUERY_RATE,
                "description": f"{len(queries)} DNS queries — high volume may indicate tunneling",
            }
        return {"detected": False, "total": len(queries)}

    def _build_findings(self, result: dict) -> list:
        findings = []
        if result["dns_tunneling"]:
            findings.append({
                "severity"   : "CRITICAL",
                "category"   : "DNS Tunneling",
                "description": f"{len(result['dns_tunneling'])} domain(s) show data encoding "
                               f"in DNS queries — possible covert exfiltration channel (APT36 TTP)",
                "action"     : "Block domain immediately + analyze full packet capture",
            })
        if result["dga_domains"]:
            findings.append({
                "severity"   : "HIGH",
                "category"   : "DGA Domains",
                "description": f"{len(result['dga_domains'])} algorithmically-generated "
                               f"domain(s) — malware C2 evasion technique",
                "action"     : "Block domain pattern + check for malware on querying hosts",
            })
        if result["fast_flux"]:
            findings.append({
                "severity"   : "HIGH",
                "category"   : "Fast Flux DNS",
                "description": f"{len(result['fast_flux'])} domain(s) with multiple rotating "
                               f"IPs — botnet C2 infrastructure",
                "action"     : "Block entire domain + report to CERT-In",
            })
        return findings
