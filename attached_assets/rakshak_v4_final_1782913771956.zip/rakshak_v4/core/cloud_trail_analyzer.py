"""
RAKSHAK — Cloud Trail Analyzer
AWS CloudTrail · Azure Activity Logs · GCP Audit Logs
Detects cloud-layer attacks: IAM abuse, security group deletion,
MFA disable, credential exfiltration from cloud metadata
"""

import re, json
from collections import defaultdict, Counter
from datetime import datetime


# ── Critical cloud API actions ────────────────────────────────────────────────
AWS_CRITICAL_ACTIONS = {
    # IAM privilege escalation
    "iam:CreateUser"              : ("CRITICAL", "New IAM user created — backdoor account"),
    "iam:AttachUserPolicy"        : ("CRITICAL", "Admin policy attached to IAM user"),
    "iam:CreateAccessKey"         : ("HIGH",     "New access key created — credential theft"),
    "iam:DeleteAccessKey"         : ("MEDIUM",   "Access key deleted — covering tracks"),
    "iam:UpdateLoginProfile"      : ("HIGH",     "IAM password changed"),
    "iam:CreateLoginProfile"      : ("HIGH",     "Console access enabled for IAM user"),
    "iam:AddUserToGroup"          : ("HIGH",     "User added to IAM group"),
    "iam:AttachRolePolicy"        : ("CRITICAL", "Policy attached to role — privilege escalation"),
    "iam:PassRole"                : ("HIGH",     "Role passed to service — escalation risk"),
    # Security configuration changes
    "ec2:DeleteSecurityGroup"     : ("CRITICAL", "Security group deleted — firewall bypass"),
    "ec2:AuthorizeSecurityGroupIngress": ("HIGH","Inbound rule added — possible backdoor"),
    "ec2:RevokeSecurityGroupEgress": ("MEDIUM",  "Egress rule removed"),
    "guardduty:DeleteDetector"    : ("CRITICAL", "GuardDuty disabled — detection evasion"),
    "cloudtrail:StopLogging"      : ("CRITICAL", "CloudTrail logging STOPPED — anti-forensics"),
    "cloudtrail:DeleteTrail"      : ("CRITICAL", "CloudTrail DELETED — destroying audit trail"),
    "config:DeleteConfigRule"     : ("HIGH",     "AWS Config rule deleted"),
    # Data exfiltration
    "s3:GetObject"                : ("MEDIUM",   "S3 object downloaded"),
    "s3:PutBucketAcl"             : ("CRITICAL", "S3 bucket made PUBLIC — data exposure"),
    "s3:DeleteBucketPolicy"       : ("HIGH",     "S3 bucket policy removed"),
    "ec2:GetConsoleScreenshot"    : ("MEDIUM",   "EC2 console screenshot taken"),
    "secretsmanager:GetSecretValue": ("CRITICAL","Secret/credential accessed"),
    "ssm:GetParameter"            : ("HIGH",     "SSM Parameter (secret) read"),
    # Instance / container
    "ec2:RunInstances"            : ("MEDIUM",   "New EC2 instance launched"),
    "lambda:CreateFunction"       : ("HIGH",     "Lambda function created — persistence"),
    "ecs:RegisterTaskDefinition"  : ("HIGH",     "ECS task defined — container persistence"),
}

AZURE_CRITICAL_OPERATIONS = {
    "Microsoft.Authorization/roleAssignments/write"      : ("CRITICAL", "Role assigned — privilege escalation"),
    "Microsoft.Authorization/policyDefinitions/delete"   : ("HIGH",     "Policy deleted — compliance bypass"),
    "microsoft.aad/users/delete"                        : ("CRITICAL", "Azure AD user deleted"),
    "microsoft.aad/users/invalidateAllRefreshTokens"    : ("HIGH",     "All tokens invalidated"),
    "Microsoft.Network/networkSecurityGroups/delete"     : ("CRITICAL", "NSG deleted — firewall bypass"),
    "Microsoft.KeyVault/vaults/secrets/read"            : ("CRITICAL", "Key Vault secret accessed"),
    "microsoft.aad/directoryRoles/members/write"        : ("CRITICAL", "Global Admin role granted"),
    "Microsoft.Compute/virtualMachines/runCommand/action": ("CRITICAL", "Remote command on VM"),
    "microsoft.aad/auditLogs/read"                      : ("MEDIUM",   "Audit log accessed — recon"),
}

GCP_CRITICAL_METHODS = {
    "iam.serviceAccounts.create"       : ("HIGH",     "Service account created"),
    "iam.serviceAccountKeys.create"    : ("CRITICAL", "Service account key created — exfiltration risk"),
    "compute.firewalls.delete"         : ("CRITICAL", "Firewall rule deleted"),
    "compute.firewalls.insert"         : ("HIGH",     "Firewall rule added"),
    "logging.sinks.delete"             : ("CRITICAL", "Log sink deleted — audit trail destroyed"),
    "logging.logServices.delete"       : ("CRITICAL", "Logging service deleted"),
    "storage.buckets.setIamPolicy"     : ("CRITICAL", "Storage bucket IAM policy changed"),
    "cloudkms.cryptoKeyVersions.destroy": ("CRITICAL","KMS key destroyed — data loss risk"),
    "admin.googleapis.com.deleteUser"  : ("CRITICAL", "Google Workspace user deleted"),
}

# ── Log format patterns ───────────────────────────────────────────────────────
AWS_PAT   = re.compile(
    r'"eventName"\s*:\s*"(?P<action>[^"]+)".*?'
    r'"userIdentity".*?"arn"\s*:\s*"(?P<arn>[^"]+)".*?'
    r'"sourceIPAddress"\s*:\s*"(?P<ip>[^"]+)"',
    re.DOTALL | re.IGNORECASE
)
AZURE_PAT = re.compile(
    r'"operationName"\s*:\s*"(?P<op>[^"]+)".*?'
    r'"caller"\s*:\s*"(?P<caller>[^"]+)".*?'
    r'"callerIpAddress"\s*:\s*"(?P<ip>[^"]+)"',
    re.DOTALL | re.IGNORECASE
)
GCP_PAT   = re.compile(
    r'"methodName"\s*:\s*"(?P<method>[^"]+)".*?'
    r'"principalEmail"\s*:\s*"(?P<user>[^"]+)".*?'
    r'"callerIp"\s*:\s*"(?P<ip>[^"]+)"',
    re.DOTALL | re.IGNORECASE
)
# Simple text pattern fallback
SIMPLE_AWS_PAT = re.compile(
    r'(?P<action>(?:iam|ec2|s3|cloudtrail|guardduty|lambda|ecs|secretsmanager|ssm)'
    r':[A-Za-z]+)',
    re.IGNORECASE
)


class CloudTrailAnalyzer:
    """
    RAKSHAK Cloud Trail Analyzer
    Cloud IAM abuse is the #1 vector for cloud-native attacks.
    RAKSHAK detects privilege escalation, security bypass, and data
    exfiltration across AWS, Azure, and GCP in a single unified analysis.
    """

    def analyze(self, log_text: str) -> dict:
        cloud_type = self._detect_cloud(log_text)

        result = {
            "cloud_platform"      : cloud_type,
            "critical_api_calls"  : self._detect_critical_apis(log_text, cloud_type),
            "iam_abuse"           : self._detect_iam_abuse(log_text, cloud_type),
            "security_bypass"     : self._detect_security_bypass(log_text, cloud_type),
            "data_exfiltration"   : self._detect_cloud_exfil(log_text, cloud_type),
            "mfa_events"          : self._detect_mfa_events(log_text),
            "off_hours_api"       : self._detect_off_hours_api(log_text),
            "anonymous_access"    : self._detect_anonymous(log_text),
            "cloud_risk_score"    : 0,
            "cloud_findings"      : [],
        }

        # Risk scoring
        score = 0
        score += min(sum(1 for c in result["critical_api_calls"]
                         if c["severity"] == "CRITICAL") * 25, 50)
        score += min(len(result["iam_abuse"])         * 20, 40)
        score += min(len(result["security_bypass"])   * 30, 40)
        score += min(len(result["data_exfiltration"]) * 15, 30)
        score += 20 if result["anonymous_access"]           else 0
        result["cloud_risk_score"] = min(score, 100)
        result["cloud_findings"]   = self._build_findings(result)
        return result

    def _detect_cloud(self, text: str) -> str:
        if re.search(r'cloudtrail|amazonaws|aws:|eventSource', text, re.IGNORECASE):
            return "AWS"
        if re.search(r'microsoft\.azure|operationName|azureActiveDirectory', text, re.IGNORECASE):
            return "Azure"
        if re.search(r'google\.cloud|gcp|principalEmail|googleapis\.com', text, re.IGNORECASE):
            return "GCP"
        return "Unknown"

    def _detect_critical_apis(self, text: str, cloud: str) -> list:
        detections = []
        if cloud == "AWS":
            for action, (severity, description) in AWS_CRITICAL_ACTIONS.items():
                service, method = action.split(":", 1)
                if re.search(rf'"{method}"|{method}\b', text, re.IGNORECASE):
                    detections.append({
                        "action"     : action,
                        "severity"   : severity,
                        "description": description,
                        "mitre"      : self._get_cloud_mitre(action),
                    })
        elif cloud == "Azure":
            for op, (severity, description) in AZURE_CRITICAL_OPERATIONS.items():
                if re.search(re.escape(op), text, re.IGNORECASE):
                    detections.append({
                        "action"     : op,
                        "severity"   : severity,
                        "description": description,
                        "mitre"      : "T1078.004 — Valid Accounts: Cloud Accounts",
                    })
        elif cloud == "GCP":
            for method, (severity, description) in GCP_CRITICAL_METHODS.items():
                if re.search(re.escape(method), text, re.IGNORECASE):
                    detections.append({
                        "action"     : method,
                        "severity"   : severity,
                        "description": description,
                        "mitre"      : "T1078.004 — Valid Accounts: Cloud Accounts",
                    })
        # Fallback: generic pattern matching
        if not detections:
            for m in SIMPLE_AWS_PAT.finditer(text):
                action = m.group("action")
                if action in AWS_CRITICAL_ACTIONS:
                    sev, desc = AWS_CRITICAL_ACTIONS[action]
                    detections.append({
                        "action": action, "severity": sev, "description": desc,
                        "mitre": self._get_cloud_mitre(action),
                    })

        return sorted(detections,
                      key=lambda d: 0 if d["severity"] == "CRITICAL" else 1)[:20]

    def _detect_iam_abuse(self, text: str, cloud: str) -> list:
        """Detect IAM privilege escalation patterns."""
        abuse = []
        IAM_ESCALATION_COMBOS = [
            (r'CreateUser.*AttachUserPolicy',
             "User created then given admin policy — backdoor account creation"),
            (r'CreateAccessKey.*GetSecretValue',
             "New credential then secret access — credential + secret theft"),
            (r'CreateRole.*PassRole',
             "Role created then passed — privilege escalation via role chaining"),
            (r'DisableMFA.*CreateLoginProfile',
             "MFA disabled then console access given — account takeover prep"),
        ]
        for pattern, description in IAM_ESCALATION_COMBOS:
            if re.search(pattern, text, re.IGNORECASE | re.DOTALL):
                abuse.append({
                    "pattern"    : pattern,
                    "description": description,
                    "severity"   : "CRITICAL",
                    "mitre"      : "T1078.004 — Cloud IAM Privilege Escalation",
                    "action"     : "Revoke all keys/roles + rotate credentials + audit access",
                })

        # Simple individual IAM events
        iam_events = [
            (r'cloudtrail.*StopLogging|DeleteTrail',
             "CRITICAL", "Audit trail destroyed — anti-forensics in cloud"),
            (r'guardduty.*DeleteDetector|DisableOrganizationAdminAccount',
             "CRITICAL", "AWS GuardDuty disabled — blind to ongoing attack"),
            (r'secretsmanager.*GetSecretValue|ssm.*GetParameter',
             "CRITICAL", "Cloud secrets/credentials accessed"),
            (r's3.*PutBucketAcl.*public|s3.*BucketPublicAccess.*false',
             "CRITICAL", "S3 bucket made publicly accessible — data exposure"),
        ]
        for pattern, severity, description in iam_events:
            if re.search(pattern, text, re.IGNORECASE):
                abuse.append({
                    "description": description,
                    "severity"   : severity,
                    "mitre"      : "T1537 — Transfer Data to Cloud Account",
                })
        return abuse

    def _detect_security_bypass(self, text: str, cloud: str) -> list:
        bypass = []
        patterns = [
            (r'DeleteSecurityGroup|DeleteNetworkAcl',
             "CRITICAL", "Network security control deleted"),
            (r'AuthorizeSecurityGroupIngress.*0\.0\.0\.0/0',
             "CRITICAL", "Security group opened to entire internet (0.0.0.0/0)"),
            (r'DisableVpcClassicLink|DeleteFlowLogs',
             "HIGH", "VPC flow logging disabled — network visibility lost"),
            (r'DisableConfig|DeleteConfigRule',
             "HIGH", "AWS Config compliance rule deleted"),
            (r'waf.*delete|WebACL.*delete',
             "HIGH", "WAF rule/ACL deleted — web protection removed"),
        ]
        for pat, severity, description in patterns:
            if re.search(pat, text, re.IGNORECASE):
                bypass.append({
                    "description": description,
                    "severity"   : severity,
                    "mitre"      : "T1562 — Impair Defenses",
                })
        return bypass

    def _detect_cloud_exfil(self, text: str, cloud: str) -> list:
        exfil = []
        patterns = [
            (r's3.*GetObject.*\d{8,}', "Large S3 download — bulk data exfiltration"),
            (r'rds.*CreateDBSnapshot.*export', "RDS database snapshot exported"),
            (r'dynamodb.*Scan.*ConsistentRead', "Full DynamoDB table scan"),
            (r'ec2.*GetConsoleOutput|ec2.*GetPasswordData', "EC2 credential extraction"),
        ]
        for pat, description in patterns:
            if re.search(pat, text, re.IGNORECASE):
                exfil.append({"description": description, "severity": "HIGH",
                              "mitre": "T1537 — Transfer Data to Cloud Account"})
        return exfil

    def _detect_mfa_events(self, text: str) -> list:
        events = []
        if re.search(r'DeactivateMFADevice|DeleteVirtualMFADevice', text, re.IGNORECASE):
            events.append({"event": "MFA deactivated", "severity": "CRITICAL",
                           "description": "Multi-factor authentication removed from account"})
        if re.search(r'DisableMFA|StrongAuthenticationDetail.*disabled', text, re.IGNORECASE):
            events.append({"event": "MFA disabled", "severity": "CRITICAL",
                           "description": "MFA disabled — account now vulnerable to password-only attack"})
        return events

    def _detect_off_hours_api(self, text: str) -> list:
        """Flag API calls made at unusual hours (potential attacker activity)."""
        off_hours = []
        # Look for timestamps in off-hours (22:00 - 06:00 UTC)
        ts_pat = re.compile(r'"eventTime"\s*:\s*"[\d-]+T(?P<hour>\d{2}):\d{2}:\d{2}Z"')
        for m in ts_pat.finditer(text):
            hour = int(m.group("hour"))
            if not (6 <= hour <= 22):  # IST business hours roughly
                off_hours.append({
                    "utc_hour"   : hour,
                    "description": f"Cloud API call at {hour:02d}:xx UTC — off-hours activity",
                    "severity"   : "MEDIUM",
                })
        return off_hours[:5]

    def _detect_anonymous(self, text: str) -> list:
        patterns = [
            r'"userIdentity"\s*:\s*\{\s*"type"\s*:\s*"Anonymous"',
            r'"principalId"\s*:\s*"Anonymous"',
            r'unauthenticated.*access',
        ]
        for pat in patterns:
            if re.search(pat, text, re.IGNORECASE):
                return [{"description": "Anonymous/unauthenticated cloud API access detected",
                         "severity": "HIGH"}]
        return []

    def _get_cloud_mitre(self, action: str) -> str:
        mapping = {
            "iam:"          : "T1078.004 — Valid Accounts: Cloud Accounts",
            "cloudtrail:"   : "T1562.008 — Impair Defenses: Disable Cloud Logs",
            "guardduty:"    : "T1562 — Impair Defenses",
            "s3:"           : "T1537 — Transfer Data to Cloud Account",
            "secretsmanager:": "T1552.001 — Credentials in Files",
            "ec2:"          : "T1578 — Modify Cloud Compute Infrastructure",
        }
        for prefix, technique in mapping.items():
            if action.lower().startswith(prefix.lower()):
                return technique
        return "T1078.004 — Cloud Accounts"

    def _build_findings(self, result: dict) -> list:
        findings = []
        critical = [c for c in result["critical_api_calls"] if c["severity"] == "CRITICAL"]
        if critical:
            findings.append({
                "severity"   : "CRITICAL",
                "category"   : "Cloud Infrastructure Attack",
                "description": f"{len(critical)} critical cloud API calls detected including: "
                               f"{critical[0]['description']}",
                "action"     : "Rotate all cloud credentials + audit all IAM changes in last 7 days",
            })
        if result["security_bypass"]:
            findings.append({
                "severity"   : "CRITICAL",
                "category"   : "Cloud Security Controls Bypassed",
                "description": f"{len(result['security_bypass'])} security control(s) "
                               f"deleted/disabled — attacker operating without detection",
                "action"     : "Immediately restore security groups + re-enable GuardDuty/CloudTrail",
            })
        if result["mfa_events"]:
            findings.append({
                "severity"   : "CRITICAL",
                "category"   : "MFA Disabled",
                "description": "Multi-factor authentication removed from cloud account — "
                               "credential theft now sufficient for full access",
                "action"     : "Re-enable MFA + invalidate all sessions + audit who disabled it",
            })
        return findings
