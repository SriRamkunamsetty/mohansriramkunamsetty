"""
RAKSHAK — Confidence Scoring Engine
Bayesian confidence % for every finding.
Prosecutors and DRDO leadership understand confidence better than technical jargon.
"""

from typing import Any


# ── Base confidence weights per evidence type ─────────────────────────────────
EVIDENCE_WEIGHTS = {
    # High-confidence direct evidence
    "hardcoded_ip"             : 0.99,
    "hardcoded_telegram_token" : 0.98,
    "known_malware_cert"       : 0.98,
    "yara_apt_match"           : 0.97,
    "cert_mismatch_play_store" : 0.97,
    "hardcoded_credential"     : 0.95,
    "yara_banking_match"       : 0.93,
    "otp_harvesting_confirmed" : 0.92,
    "overlay_attack_confirmed" : 0.90,
    "shell_command_present"    : 0.90,
    "embedded_apk_dropper"     : 0.92,
    "embedded_elf_binary"      : 0.88,

    # Medium-confidence inferred evidence
    "dangerous_api_critical"   : 0.82,
    "accessibility_abuse"      : 0.80,
    "permission_combo_banking" : 0.80,
    "high_entropy_asset"       : 0.72,
    "obfuscation_detected"     : 0.70,
    "debug_cert_release_apk"   : 0.68,
    "suspicious_url"           : 0.65,
    "dangerous_api_high"       : 0.62,
    "vulnerable_library"       : 0.60,
    "multiple_build_paths"     : 0.58,

    # Lower-confidence contextual signals
    "bank_brand_reference"     : 0.52,
    "dangerous_permission"     : 0.50,
    "timestamp_anomaly"        : 0.50,
    "dangerous_api_medium"     : 0.42,
    "generic_cert_org"         : 0.40,
    "play_store_not_found"     : 0.35,
}


def compute_finding_confidence(finding_type: str,
                                corroborating_evidence: list[str] = None,
                                contradicting_evidence: list[str] = None) -> dict:
    """
    Compute Bayesian confidence for a single finding.

    Bayes update:
        P(malicious | evidence) = P(evidence | malicious) × P(malicious)
                                  / P(evidence)

    Simplified as likelihood-ratio product over independent evidence.

    Returns:
        confidence (float 0–1), label (str), reasoning (str)
    """
    base = EVIDENCE_WEIGHTS.get(finding_type, 0.50)
    corr = corroborating_evidence or []
    cont = contradicting_evidence or []

    # Bayesian update from corroborating evidence
    p = base
    for ev in corr:
        ev_weight = EVIDENCE_WEIGHTS.get(ev, 0.50)
        # Update: P = P × LR / (P × LR + (1-P) × (1-LR))
        lr = ev_weight / (1 - ev_weight + 1e-9)
        odds_new = (p / (1 - p + 1e-9)) * lr
        p = odds_new / (1 + odds_new)
        p = min(p, 0.999)

    # Bayesian update from contradicting evidence
    for ev in cont:
        ev_weight = EVIDENCE_WEIGHTS.get(ev, 0.50)
        # Contradicting reduces confidence
        lr_contra = (1 - ev_weight) / (ev_weight + 1e-9)
        odds_new  = (p / (1 - p + 1e-9)) * lr_contra
        p         = odds_new / (1 + odds_new)
        p         = max(p, 0.001)

    confidence = round(p, 3)

    if confidence >= 0.95:
        label = "DEFINITIVE"
    elif confidence >= 0.85:
        label = "HIGH"
    elif confidence >= 0.70:
        label = "MEDIUM"
    elif confidence >= 0.50:
        label = "LOW"
    else:
        label = "SPECULATIVE"

    corr_str = ", ".join(corr[:3]) if corr else "none"
    cont_str = ", ".join(cont[:2]) if cont else "none"
    reasoning = (
        f"Base: {finding_type} ({int(base*100)}%) | "
        f"Corroborating: {corr_str} | "
        f"Contradicting: {cont_str} | "
        f"Final: {int(confidence*100)}% ({label})"
    )

    return {
        "confidence"      : confidence,
        "confidence_pct"  : int(confidence * 100),
        "confidence_label": label,
        "reasoning"       : reasoning,
    }


class AnalysisConfidenceScorer:
    """
    Applies confidence scoring to every finding in a RAKSHAK analysis result.
    Enriches each finding with a confidence % that analysts and legal teams understand.
    """

    def enrich(self, analysis: dict) -> dict:
        """
        Walk every finding in the analysis result and attach confidence scores.
        Modifies analysis in-place and returns it.
        """
        # Collect all positive evidence types for Bayesian updates
        positive_evidence = self._collect_positive_evidence(analysis)
        negative_evidence = self._collect_negative_evidence(analysis)

        # Enrich static API findings
        sa = analysis.get("static_analysis", {})
        for finding in sa.get("api_analysis", {}).get("findings", []):
            sev_map = {
                "CRITICAL": "dangerous_api_critical",
                "HIGH"    : "dangerous_api_high",
                "MEDIUM"  : "dangerous_api_medium",
            }
            ft = sev_map.get(finding.get("severity", ""), "dangerous_api_medium")
            finding["confidence"] = compute_finding_confidence(
                ft, positive_evidence, negative_evidence
            )

        # Enrich vulnerability findings
        for vuln in sa.get("vulnerabilities", {}).get("findings", []):
            vuln["confidence"] = compute_finding_confidence(
                "dangerous_api_critical" if vuln.get("severity") == "CRITICAL"
                else "dangerous_api_high",
                positive_evidence, negative_evidence
            )

        # Enrich YARA matches
        ya = analysis.get("yara_analysis", {})
        for match in ya.get("matches", []):
            ft = "yara_apt_match" if "APT" in match.get("rule_id", "") \
                 else "yara_banking_match"
            match["confidence"] = compute_finding_confidence(
                ft, positive_evidence, negative_evidence
            )

        # Enrich banking threats
        bt = sa.get("banking_threats", {})
        if bt.get("otp_harvesting"):
            bt["otp_confidence"] = compute_finding_confidence(
                "otp_harvesting_confirmed", positive_evidence, negative_evidence
            )
        if bt.get("overlay_attack"):
            bt["overlay_confidence"] = compute_finding_confidence(
                "overlay_attack_confirmed", positive_evidence, negative_evidence
            )

        # Enrich network IOCs
        strings = analysis.get("strings", {})
        for url_entry in strings.get("urls", []):
            url_entry["confidence"] = compute_finding_confidence(
                "suspicious_url", positive_evidence, negative_evidence
            )
        for ip_entry in strings.get("ips", []):
            ip_entry["confidence"] = compute_finding_confidence(
                "hardcoded_ip", positive_evidence, negative_evidence
            )

        # Overall analysis confidence
        risk = analysis.get("risk_score", {})
        score = risk.get("final_score", 0)
        overall = compute_finding_confidence(
            "yara_banking_match" if score > 65 else "bank_brand_reference",
            positive_evidence, negative_evidence
        )
        analysis["overall_confidence"] = overall

        return analysis

    def _collect_positive_evidence(self, analysis: dict) -> list[str]:
        evidence = []
        strings  = analysis.get("strings", {})
        sa       = analysis.get("static_analysis", {})
        structure= analysis.get("structure", {})
        ya       = analysis.get("yara_analysis", {})
        certs    = analysis.get("certificates", {})
        bt       = sa.get("banking_threats", {})

        if strings.get("ips"):               evidence.append("hardcoded_ip")
        if strings.get("telegram_tokens"):   evidence.append("hardcoded_telegram_token")
        if strings.get("hardcoded_secrets"): evidence.append("hardcoded_credential")
        if structure.get("embedded_apks"):   evidence.append("embedded_apk_dropper")
        if structure.get("high_entropy_files"): evidence.append("high_entropy_asset")
        if strings.get("shell_commands"):    evidence.append("shell_command_present")
        if bt.get("otp_harvesting"):         evidence.append("otp_harvesting_confirmed")
        if bt.get("overlay_attack"):         evidence.append("overlay_attack_confirmed")
        if bt.get("accessibility_abuse"):    evidence.append("accessibility_abuse")
        if ya.get("apt_detected"):           evidence.append("yara_apt_match")
        if ya.get("malware_families"):       evidence.append("yara_banking_match")
        if certs.get("self_signed"):         evidence.append("debug_cert_release_apk")
        if sa.get("api_analysis", {}).get("obfuscation_signals"):
            evidence.append("obfuscation_detected")

        return list(set(evidence))

    def _collect_negative_evidence(self, analysis: dict) -> list[str]:
        evidence = []
        manifest = analysis.get("manifest", {})
        ya       = analysis.get("yara_analysis", {})
        certs    = analysis.get("certificates", {})

        # Things that suggest legitimacy
        if not ya.get("malware_families"):
            evidence.append("play_store_not_found")
        if not manifest.get("bank_impersonation_score", 0):
            evidence.append("play_store_not_found")

        return list(set(evidence))
