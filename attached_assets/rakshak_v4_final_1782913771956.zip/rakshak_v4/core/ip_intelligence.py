"""
RAKSHAK — IP Intelligence Engine
Geo-IP mapping · AbuseIPDB reputation · ASN analysis
Tor/VPN/datacenter detection · Bulletproof hosting identification
"""

import re, time, socket
from typing import Optional
import requests

# ── Known bulletproof ASNs ────────────────────────────────────────────────────
BULLETPROOF_ASNS = {
    "AS60068" : "Datacamp Limited (bulletproof hosting)",
    "AS209588": "Flyservers S.A. (bulletproof hosting)",
    "AS202425": "IP Volume inc (fraud infrastructure)",
    "AS49581" : "Ferdinand Zink (malware distribution)",
    "AS197414": "Aeza Group (Russian bulletproof)",
    "AS9009"  : "M247 Ltd (known C2 hosting)",
    "AS42926" : "Radore Hosting (botnet infrastructure)",
    "AS174"   : "Cogent Communications (abuse-heavy)",
    "AS3215"  : "Orange S.A.",
}

# ── Known Tor exit node ranges (sample — real implementation uses exit list) ──
TOR_INDICATORS = ["tor-exit", "tornode", "exit-node", "anonymizing"]

# ── Known VPN provider ASN keywords ──────────────────────────────────────────
VPN_KEYWORDS = [
    "nordvpn", "expressvpn", "protonvpn", "surfshark", "mullvad",
    "pia", "private internet", "cyberghost", "hidemyass", "vpn",
    "tunnel", "proxy", "anonymous",
]

# ── Country risk scores (DRDO perspective) ────────────────────────────────────
COUNTRY_RISK = {
    "China"       : 90, "Pakistan"     : 95, "North Korea"  : 95,
    "Russia"      : 85, "Iran"         : 85, "Ukraine"      : 60,
    "Vietnam"     : 55, "Romania"      : 50, "Brazil"       : 40,
    "Netherlands" : 35, "Germany"      : 20, "United States": 20,
    "India"       : 15, "United Kingdom": 15,
}


class IPIntelligenceEngine:
    """
    RAKSHAK IP Intelligence Engine
    Enriches every attacking IP with geo, reputation, ASN, and threat context
    """

    def __init__(self, timeout: int = 6,
                 abuseipdb_key: str = "",
                 virustotal_key: str = ""):
        self.timeout         = timeout
        self.abuseipdb_key   = abuseipdb_key
        self.virustotal_key  = virustotal_key
        self.session         = requests.Session()
        self.session.headers.update({"User-Agent": "RAKSHAK-IPIntel/3.1"})
        self._cache: dict    = {}

    def enrich_ip(self, ip: str) -> dict:
        """Full enrichment for a single IP address."""
        if ip in self._cache:
            return self._cache[ip]

        result = {
            "ip"                 : ip,
            "country"            : "Unknown",
            "country_code"       : "",
            "city"               : "Unknown",
            "region"             : "",
            "isp"                : "Unknown",
            "org"                : "Unknown",
            "asn"                : "",
            "asn_name"           : "",
            "latitude"           : 0.0,
            "longitude"          : 0.0,
            "is_tor"             : False,
            "is_vpn"             : False,
            "is_datacenter"      : False,
            "is_bulletproof"     : False,
            "bulletproof_detail" : "",
            "abuse_score"        : 0,
            "abuse_reports"      : 0,
            "vt_detections"      : 0,
            "hostname"           : "",
            "country_risk_score" : 0,
            "overall_threat_score": 0,
            "threat_tags"        : [],
            "intelligence_sources": [],
        }

        # Reverse DNS
        try:
            result["hostname"] = socket.gethostbyaddr(ip)[0]
        except Exception:
            pass

        # ip-api (free, includes geo + ASN + hosting flag)
        try:
            resp = self.session.get(
                f"http://ip-api.com/json/{ip}"
                "?fields=status,country,countryCode,city,regionName,"
                "org,as,isp,lat,lon,hosting,proxy,query",
                timeout=self.timeout
            )
            if resp.status_code == 200:
                d = resp.json()
                if d.get("status") == "success":
                    result["country"]       = d.get("country", "Unknown")
                    result["country_code"]  = d.get("countryCode", "")
                    result["city"]          = d.get("city", "Unknown")
                    result["region"]        = d.get("regionName", "")
                    result["isp"]           = d.get("isp", "Unknown")
                    result["org"]           = d.get("org", "Unknown")
                    result["asn"]           = d.get("as", "")
                    result["latitude"]      = d.get("lat", 0.0)
                    result["longitude"]     = d.get("lon", 0.0)
                    result["is_datacenter"] = d.get("hosting", False)
                    result["is_vpn"]        = d.get("proxy", False)
                    result["intelligence_sources"].append("ip-api")

                    # Country risk
                    result["country_risk_score"] = COUNTRY_RISK.get(
                        result["country"], 30
                    )

                    # Bulletproof ASN check
                    asn_str = result["asn"]
                    asn_code = asn_str.split(" ")[0] if asn_str else ""
                    if asn_code in BULLETPROOF_ASNS:
                        result["is_bulletproof"]     = True
                        result["bulletproof_detail"] = BULLETPROOF_ASNS[asn_code]
                        result["threat_tags"].append(
                            f"Bulletproof ASN: {BULLETPROOF_ASNS[asn_code]}"
                        )

                    # VPN keyword detection
                    combined = (result["isp"] + result["org"]).lower()
                    if any(kw in combined for kw in VPN_KEYWORDS):
                        result["is_vpn"] = True
                        result["threat_tags"].append("VPN/Proxy provider detected")

                    # Tor heuristic
                    hostname_lower = result["hostname"].lower()
                    if any(kw in hostname_lower for kw in TOR_INDICATORS):
                        result["is_tor"] = True
                        result["threat_tags"].append("Tor exit node (hostname heuristic)")

                    if result["is_datacenter"]:
                        result["threat_tags"].append("Datacenter IP — common C2/scanner hosting")

        except Exception:
            pass

        # AbuseIPDB enrichment
        if self.abuseipdb_key:
            try:
                resp = self.session.get(
                    "https://api.abuseipdb.com/api/v2/check",
                    headers={"Key": self.abuseipdb_key, "Accept": "application/json"},
                    params={"ipAddress": ip, "maxAgeInDays": 90, "verbose": True},
                    timeout=self.timeout
                )
                if resp.status_code == 200:
                    d = resp.json().get("data", {})
                    result["abuse_score"]   = d.get("abuseConfidenceScore", 0)
                    result["abuse_reports"] = d.get("totalReports", 0)
                    if d.get("isPublic") is False:
                        result["threat_tags"].append("Private/reserved IP")
                    if result["abuse_score"] > 50:
                        result["threat_tags"].append(
                            f"AbuseIPDB: {result['abuse_score']}% confidence malicious"
                        )
                    result["intelligence_sources"].append("AbuseIPDB")
            except Exception:
                pass

        # VirusTotal enrichment
        if self.virustotal_key:
            try:
                resp = self.session.get(
                    f"https://www.virustotal.com/api/v3/ip_addresses/{ip}",
                    headers={"x-apikey": self.virustotal_key},
                    timeout=self.timeout
                )
                if resp.status_code == 200:
                    stats = resp.json().get("data", {}).get(
                        "attributes", {}
                    ).get("last_analysis_stats", {})
                    result["vt_detections"] = stats.get("malicious", 0)
                    if result["vt_detections"] > 3:
                        result["threat_tags"].append(
                            f"VirusTotal: {result['vt_detections']} engines flagged"
                        )
                    result["intelligence_sources"].append("VirusTotal")
            except Exception:
                pass

        # Overall threat score
        score = 0
        score += result["country_risk_score"] * 0.25
        score += result["abuse_score"] * 0.35
        score += result["vt_detections"] * 5
        score += 30 if result["is_bulletproof"] else 0
        score += 20 if result["is_datacenter"] else 0
        score += 15 if result["is_vpn"] else 0
        score += 25 if result["is_tor"] else 0
        result["overall_threat_score"] = min(int(score), 100)

        self._cache[ip] = result
        return result

    def enrich_batch(self, ips: list[str],
                     delay: float = 0.5) -> list[dict]:
        """Enrich multiple IPs with rate limiting."""
        results = []
        seen    = set()
        for ip in ips:
            if ip in seen or not self._is_public(ip):
                continue
            seen.add(ip)
            results.append(self.enrich_ip(ip))
            time.sleep(delay)
        return sorted(results,
                      key=lambda x: x["overall_threat_score"],
                      reverse=True)

    def build_geo_map_data(self, enriched: list[dict]) -> list[dict]:
        """Format enrichment results for world map visualization."""
        return [
            {
                "ip"         : e["ip"],
                "lat"        : e["latitude"],
                "lng"        : e["longitude"],
                "country"    : e["country"],
                "city"       : e["city"],
                "isp"        : e["isp"],
                "threat"     : e["overall_threat_score"],
                "abuse"      : e["abuse_score"],
                "bulletproof": e["is_bulletproof"],
                "tor"        : e["is_tor"],
                "vpn"        : e["is_vpn"],
                "tags"       : e["threat_tags"][:3],
            }
            for e in enriched
            if e["latitude"] != 0 or e["longitude"] != 0
        ]

    @staticmethod
    def _is_public(ip: str) -> bool:
        try:
            parts = [int(p) for p in ip.split(".")]
            if len(parts) != 4:
                return False
            if parts[0] in (10, 127):
                return False
            if parts[0] == 172 and 16 <= parts[1] <= 31:
                return False
            if parts[0] == 192 and parts[1] == 168:
                return False
            return True
        except Exception:
            return False
