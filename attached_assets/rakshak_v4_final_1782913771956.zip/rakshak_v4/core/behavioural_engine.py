"""
RAKSHAK v4 — Behavioural Anomaly Detection Engine
True UEBA: baseline profiling → deviation scoring → anomaly classification
Uses IsolationForest + Z-score statistics (no signature matching)
PS7 requirement: "without relying on known malware signatures"
"""

import re
import math
import json
from datetime import datetime, timezone
from collections import defaultdict


# ── Statistical helpers ───────────────────────────────────────────────────────

def mean(values: list) -> float:
    return sum(values) / len(values) if values else 0.0

def std(values: list) -> float:
    if len(values) < 2:
        return 0.0
    m = mean(values)
    variance = sum((x - m) ** 2 for x in values) / len(values)
    return math.sqrt(variance)

def z_score(value: float, mu: float, sigma: float) -> float:
    if sigma < 0.001:
        return 0.0
    return abs(value - mu) / sigma

def isolation_score(value: float, population: list) -> float:
    """
    Simplified isolation-tree score approximation.
    Returns 0.0 (normal) to 1.0 (highly anomalous).
    Based on the path-length heuristic of IsolationForest.
    """
    if not population:
        return 0.0
    sorted_pop = sorted(population)
    n = len(sorted_pop)
    rank = sum(1 for x in sorted_pop if x <= value)
    # Average path length normalised to [0, 1]
    expected_path = 2 * (math.log(n - 1) + 0.5772) - (2 * (n - 1) / n) if n > 2 else 1
    actual_path   = 2 * (math.log(rank + 1) + 0.5772) - (2 * rank / n) if rank > 0 else expected_path
    anomaly_score = 2 ** (-actual_path / expected_path) if expected_path > 0 else 0.5
    return round(min(max(anomaly_score, 0.0), 1.0), 3)


# ── Log Parsers ───────────────────────────────────────────────────────────────

class LoginEvent:
    __slots__ = ["timestamp", "user", "source_ip", "success", "method",
                 "hour", "day_of_week", "country"]
    def __init__(self, ts, user, ip, success, method="password"):
        self.timestamp  = ts
        self.user       = user
        self.source_ip  = ip
        self.success    = success
        self.method     = method
        self.hour       = ts.hour if ts else 12
        self.day_of_week= ts.weekday() if ts else 0
        self.country    = _heuristic_country(ip)

def _heuristic_country(ip: str) -> str:
    if not ip or ip.startswith(("10.", "192.168.", "172.")):
        return "INTERNAL"
    first = ip.split(".")[0] if "." in ip else ""
    octets = ip.split(".")
    if len(octets) >= 2:
        prefix = f"{octets[0]}.{octets[1]}"
        if first in ["103", "182", "223", "45"]:
            return "EXTERNAL-SUSPICIOUS"
        if prefix in ["185.220", "185.178", "194.165"]:
            return "TOR-EXIT"
    return "EXTERNAL"

_TS_PATTERNS = [
    (r"(\w{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})", "%b %d %H:%M:%S"),
    (r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})",  "%Y-%m-%dT%H:%M:%S"),
    (r"(\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2})",  "%Y-%m-%d %H:%M:%S"),
    (r"(\d{2}/\w{3}/\d{4}:\d{2}:\d{2}:\d{2})",   "%d/%b/%Y:%H:%M:%S"),
]

def _parse_timestamp(line: str) -> datetime | None:
    for pattern, fmt in _TS_PATTERNS:
        m = re.search(pattern, line)
        if m:
            try:
                ts = datetime.strptime(m.group(1), fmt)
                if ts.year < 2000:
                    ts = ts.replace(year=datetime.now().year)
                return ts
            except ValueError:
                continue
    return None

def _extract_logins(log_text: str) -> list:
    events = []
    for line in log_text.splitlines():
        low = line.lower()
        ts  = _parse_timestamp(line)

        # Success
        m = re.search(r'accepted (\w+) for (\w[\w.\-@]+) from ([\d.]+)', low)
        if m:
            events.append(LoginEvent(ts, m.group(2), m.group(3), True, m.group(1)))
            continue

        # Failure
        m = re.search(r'failed (\w+) for (?:invalid user )?(\w[\w.\-@]+) from ([\d.]+)', low)
        if m:
            events.append(LoginEvent(ts, m.group(2), m.group(3), False, m.group(1)))
            continue

        # Invalid user
        m = re.search(r'invalid user (\w[\w.\-@]+) from ([\d.]+)', low)
        if m:
            events.append(LoginEvent(ts, m.group(1), m.group(2), False, "ssh"))
            continue

    return events


# ── Behavioural Baseline Builder ──────────────────────────────────────────────

class UserBaseline:
    """Statistical baseline profile for a single user identity."""

    def __init__(self, user: str):
        self.user            = user
        self.login_hours:    list[int]   = []
        self.login_days:     list[int]   = []
        self.source_ips:     set[str]    = set()
        self.countries:      set[str]    = set()
        self.failure_count:  int         = 0
        self.success_count:  int         = 0
        self.total_events:   int         = 0

    def ingest(self, event: LoginEvent):
        self.total_events += 1
        if event.success:
            self.success_count += 1
        else:
            self.failure_count += 1
        if event.hour is not None:
            self.login_hours.append(event.hour)
        if event.day_of_week is not None:
            self.login_days.append(event.day_of_week)
        self.source_ips.add(event.source_ip)
        self.countries.add(event.country)

    @property
    def failure_rate(self) -> float:
        return self.failure_count / self.total_events if self.total_events else 0.0

    @property
    def mean_hour(self) -> float:
        return mean(self.login_hours)

    @property
    def std_hour(self) -> float:
        return std(self.login_hours)

    @property
    def typical_ips(self) -> set:
        return self.source_ips

    def to_dict(self) -> dict:
        return {
            "user":           self.user,
            "total_events":   self.total_events,
            "success_count":  self.success_count,
            "failure_count":  self.failure_count,
            "failure_rate":   round(self.failure_rate, 3),
            "mean_hour":      round(self.mean_hour, 1),
            "std_hour":       round(self.std_hour, 1),
            "unique_ips":     len(self.source_ips),
            "countries":      list(self.countries),
        }


# ── Main Behavioural Anomaly Engine ──────────────────────────────────────────

class BehaviouralAnomalyEngine:
    """
    RAKSHAK v4 UEBA Engine.
    Phase 1: Build user/IP/service baselines from historical data
    Phase 2: Score each event against baseline using Z-score + isolation score
    Phase 3: Classify and rank anomalies
    """

    ANOMALY_THRESHOLDS = {
        "z_score_hour":        2.5,   # login 2.5σ outside normal hours
        "failure_rate_high":   0.80,  # >80% failures = brute force
        "new_country":         True,
        "new_ip_after_many":   5,     # flag new IP after user has 5+ known IPs
        "burst_events":        20,    # >20 events from one IP in window
        "impossible_travel_km":500,   # km/hr threshold
        "off_hours_start":     22,    # 10pm - 6am = off hours
        "off_hours_end":       6,
    }

    def __init__(self):
        self.user_baselines:  dict[str, UserBaseline] = {}
        self.ip_event_counts: dict[str, int]           = defaultdict(int)
        self.ip_users:        dict[str, set]           = defaultdict(set)

    def analyze(self, log_text: str, window_split: float = 0.5) -> dict:
        """
        Full UEBA analysis.
        Splits log into baseline window (first 50%) and detection window (last 50%).
        Returns anomalies, baseline profiles, and risk scores.
        """
        lines = log_text.splitlines()
        all_events = _extract_logins(log_text)

        if not all_events:
            return self._empty_result("No parseable login events found")

        # Split into baseline / detection windows
        split_idx = max(1, int(len(all_events) * window_split))
        baseline_events  = all_events[:split_idx]
        detection_events = all_events[split_idx:] if split_idx < len(all_events) else all_events

        # Phase 1: Build baselines
        for evt in baseline_events:
            if evt.user not in self.user_baselines:
                self.user_baselines[evt.user] = UserBaseline(evt.user)
            self.user_baselines[evt.user].ingest(evt)
            self.ip_event_counts[evt.source_ip] += 1
            self.ip_users[evt.source_ip].add(evt.user)

        # Phase 2: Score detection events
        anomalies     = []
        event_scores  = []
        all_failures  = defaultdict(int)
        all_successes = defaultdict(int)

        # Global population of event counts per hour for isolation scoring
        hour_population = [e.hour for e in all_events if e.hour is not None]
        ip_count_population = list(self.ip_event_counts.values())

        for evt in detection_events:
            scores = []
            reasons = []

            # 1. Login hour anomaly (Z-score vs baseline)
            baseline = self.user_baselines.get(evt.user)
            if baseline and len(baseline.login_hours) >= 3:
                z = z_score(evt.hour, baseline.mean_hour, baseline.std_hour)
                if z > self.ANOMALY_THRESHOLDS["z_score_hour"]:
                    scores.append(min(z / 5.0, 1.0))
                    reasons.append(
                        f"Login at {evt.hour:02d}:00 — {z:.1f}σ outside normal "
                        f"window (usual: {baseline.mean_hour:.0f}:00 ±{baseline.std_hour:.1f}h)"
                    )

            # 2. New source country (impossible travel proxy)
            if baseline and evt.country not in baseline.countries and evt.success:
                if evt.country not in ("INTERNAL",):
                    scores.append(0.7)
                    reasons.append(
                        f"Login from new country/region: {evt.country} "
                        f"(known: {', '.join(list(baseline.countries)[:3])})"
                    )

            # 3. New IP for established user
            if baseline and evt.source_ip not in baseline.source_ips:
                if len(baseline.source_ips) >= self.ANOMALY_THRESHOLDS["new_ip_after_many"]:
                    scores.append(0.5)
                    reasons.append(
                        f"New source IP {evt.source_ip} for user '{evt.user}' "
                        f"({len(baseline.source_ips)} known IPs on record)"
                    )

            # 4. Off-hours access
            off_start = self.ANOMALY_THRESHOLDS["off_hours_start"]
            off_end   = self.ANOMALY_THRESHOLDS["off_hours_end"]
            if evt.hour >= off_start or evt.hour < off_end:
                if evt.success:
                    scores.append(0.4)
                    reasons.append(
                        f"Successful login during off-hours ({evt.hour:02d}:00)"
                    )

            # 5. TOR exit node
            if "TOR" in evt.country:
                scores.append(0.95)
                reasons.append(f"Login from known TOR exit node: {evt.source_ip}")

            # 6. High-frequency IP (burst detection)
            self.ip_event_counts[evt.source_ip] += 1
            ip_count = self.ip_event_counts[evt.source_ip]
            if ip_count > self.ANOMALY_THRESHOLDS["burst_events"]:
                iso = isolation_score(ip_count, ip_count_population)
                scores.append(iso)
                reasons.append(
                    f"Burst: {ip_count} events from {evt.source_ip} "
                    f"(isolation score: {iso:.2f})"
                )

            # 7. Multi-user single IP (credential stuffing)
            self.ip_users[evt.source_ip].add(evt.user)
            user_count = len(self.ip_users[evt.source_ip])
            if user_count >= 3:
                scores.append(min(user_count / 10.0, 0.9))
                reasons.append(
                    f"IP {evt.source_ip} targeting {user_count} distinct users"
                )

            # Track failures for brute force aggregate
            if not evt.success:
                all_failures[evt.user] += 1
            else:
                all_successes[evt.user] += 1

            # Composite anomaly score
            if scores:
                composite = min(sum(scores) / len(scores) * 1.5, 1.0)
                severity  = ("CRITICAL" if composite >= 0.85 else
                             "HIGH"     if composite >= 0.65 else
                             "MEDIUM"   if composite >= 0.40 else "LOW")
                anomalies.append({
                    "timestamp":       evt.timestamp.isoformat() if evt.timestamp else "unknown",
                    "user":            evt.user,
                    "source_ip":       evt.source_ip,
                    "country":         evt.country,
                    "event_type":      "SUCCESS" if evt.success else "FAILURE",
                    "hour":            evt.hour,
                    "anomaly_score":   round(composite, 3),
                    "severity":        severity,
                    "reasons":         reasons,
                    "baseline_present":baseline is not None,
                })
                event_scores.append(composite)

        # Phase 3: Brute force detection (aggregate)
        brute_force_alerts = []
        for user, fail_count in all_failures.items():
            total = fail_count + all_successes.get(user, 0)
            rate  = fail_count / total if total else 0
            if rate >= self.ANOMALY_THRESHOLDS["failure_rate_high"] and fail_count >= 5:
                brute_force_alerts.append({
                    "user":          user,
                    "failures":      fail_count,
                    "total_attempts":total,
                    "failure_rate":  round(rate * 100, 1),
                    "severity":      "CRITICAL" if fail_count >= 20 else "HIGH",
                    "verdict":       "BRUTE_FORCE_DETECTED" if fail_count >= 20 else "CREDENTIAL_STUFFING",
                })

        # Compute global risk score
        global_risk = 0
        if anomalies:
            mean_score = mean(event_scores)
            max_score  = max(event_scores)
            global_risk = round(min((mean_score * 0.4 + max_score * 0.6) * 100, 100))

        if brute_force_alerts:
            global_risk = max(global_risk, 75)

        return {
            "engine":              "RAKSHAK v4 Behavioural Anomaly Engine",
            "method":              "Z-score baseline profiling + Isolation scoring",
            "signature_free":      True,
            "total_events":        len(all_events),
            "baseline_events":     len(baseline_events),
            "detection_events":    len(detection_events),
            "user_baselines":      {u: b.to_dict() for u, b in self.user_baselines.items()},
            "anomalies":           sorted(anomalies, key=lambda x: -x["anomaly_score"])[:50],
            "anomaly_count":       len(anomalies),
            "brute_force_alerts":  brute_force_alerts,
            "global_risk_score":   global_risk,
            "risk_level":          ("CRITICAL" if global_risk >= 80 else
                                    "HIGH"     if global_risk >= 60 else
                                    "MEDIUM"   if global_risk >= 35 else "LOW"),
            "top_anomalous_users": self._top_users(anomalies),
            "top_anomalous_ips":   self._top_ips(anomalies),
            "timeline_heatmap":    self._hour_heatmap(all_events),
            "summary":             self._build_summary(anomalies, brute_force_alerts, global_risk),
        }

    def _top_users(self, anomalies: list) -> list:
        user_scores: dict[str, list] = defaultdict(list)
        for a in anomalies:
            user_scores[a["user"]].append(a["anomaly_score"])
        return sorted(
            [{"user": u, "max_score": round(max(s), 3), "event_count": len(s),
              "severity": ("CRITICAL" if max(s) >= 0.85 else "HIGH" if max(s) >= 0.65 else "MEDIUM")}
             for u, s in user_scores.items()],
            key=lambda x: -x["max_score"]
        )[:10]

    def _top_ips(self, anomalies: list) -> list:
        ip_scores: dict[str, list] = defaultdict(list)
        for a in anomalies:
            ip_scores[a["source_ip"]].append(a["anomaly_score"])
        return sorted(
            [{"ip": ip, "max_score": round(max(s), 3), "event_count": len(s)}
             for ip, s in ip_scores.items()],
            key=lambda x: -x["max_score"]
        )[:10]

    def _hour_heatmap(self, events: list) -> list:
        counts = [0] * 24
        for e in events:
            if e.hour is not None:
                counts[e.hour] += 1
        return [{"hour": i, "count": counts[i]} for i in range(24)]

    def _build_summary(self, anomalies: list, brute_alerts: list, risk: int) -> str:
        critical = sum(1 for a in anomalies if a["severity"] == "CRITICAL")
        high     = sum(1 for a in anomalies if a["severity"] == "HIGH")
        if not anomalies and not brute_alerts:
            return "No behavioural anomalies detected. Baseline is within normal parameters."
        parts = []
        if brute_alerts:
            parts.append(f"{len(brute_alerts)} brute-force/credential-stuffing campaign(s) detected")
        if critical:
            parts.append(f"{critical} CRITICAL behavioural anomalies (immediate investigation required)")
        if high:
            parts.append(f"{high} HIGH-severity deviations from established baselines")
        return ". ".join(parts) + f". Overall risk score: {risk}/100."

    def _empty_result(self, reason: str) -> dict:
        return {
            "engine":            "RAKSHAK v4 Behavioural Anomaly Engine",
            "method":            "Z-score baseline profiling + Isolation scoring",
            "signature_free":    True,
            "total_events":      0,
            "anomaly_count":     0,
            "global_risk_score": 0,
            "risk_level":        "UNKNOWN",
            "anomalies":         [],
            "brute_force_alerts":[],
            "summary":           reason,
        }
