"""
RAKSHAK — Sigma Rule Auto-Generator
Converts every confirmed threat detection into a Sigma rule
that loads directly into Splunk, QRadar, Elastic SIEM, Microsoft Sentinel.
Other organisations immediately benefit from DRDO's threat intelligence.
"""

import re, uuid
from datetime import datetime


# ── Sigma rule templates for each detection category ─────────────────────────
SIGMA_TEMPLATES = {

    "brute_force": {
        "title"      : "RAKSHAK: SSH Brute Force Attack",
        "description": "Multiple failed SSH login attempts from single source — detected by RAKSHAK",
        "status"     : "stable",
        "level"      : "high",
        "tags"       : ["attack.credential_access", "attack.t1110"],
        "logsource"  : {"product": "linux", "service": "auth"},
        "detection"  : {
            "keywords": ["Failed password", "Invalid user", "authentication failure"],
            "condition": "keywords",
        },
        "falsepositives": ["Misconfigured automation scripts", "Legitimate admin typos"],
        "fields"     : ["src_ip", "user", "timestamp"],
    },

    "sql_injection": {
        "title"      : "RAKSHAK: SQL Injection Attempt",
        "description": "SQL injection pattern detected in database logs — detected by RAKSHAK",
        "status"     : "stable",
        "level"      : "critical",
        "tags"       : ["attack.initial_access", "attack.t1190"],
        "logsource"  : {"category": "database", "product": "mysql"},
        "detection"  : {
            "keywords": ["UNION SELECT", "' OR '1'='1", "SLEEP(", "xp_cmdshell",
                         "INFORMATION_SCHEMA", "LOAD_FILE("],
            "condition": "1 of keywords",
        },
        "falsepositives": ["Security testing", "WAF log analysis tools"],
        "fields"     : ["query", "src_ip", "user"],
    },

    "dns_tunneling": {
        "title"      : "RAKSHAK: DNS Tunneling — High-Entropy Subdomain",
        "description": "Abnormally long, high-entropy DNS subdomain detected — possible data exfiltration via DNS",
        "status"     : "experimental",
        "level"      : "critical",
        "tags"       : ["attack.exfiltration", "attack.t1071.004"],
        "logsource"  : {"product": "dns", "service": "named"},
        "detection"  : {
            "keywords" : ["query:", "IN A", "IN TXT"],
            "filter"   : {"domain": ["google.com", "microsoft.com", "amazonaws.com"]},
            "condition": "keywords and not filter",
        },
        "falsepositives": ["Legitimate long subdomains", "CDN routing records"],
        "fields"     : ["client_ip", "query_name", "query_type"],
    },

    "c2_beaconing": {
        "title"      : "RAKSHAK: C2 Beaconing — Periodic Outbound Connection",
        "description": "Statistically regular outbound connections detected — C2 malware heartbeat",
        "status"     : "stable",
        "level"      : "critical",
        "tags"       : ["attack.command_and_control", "attack.t1071"],
        "logsource"  : {"category": "proxy"},
        "detection"  : {
            "timeframe": "1h",
            "keywords" : ["GET", "POST"],
            "condition": "keywords | count() by c-ip, cs-host > 20",
        },
        "falsepositives": ["Monitoring agents", "Legitimate update checks"],
        "fields"     : ["src_ip", "dest_host", "timestamp", "bytes"],
    },

    "impossible_travel": {
        "title"      : "RAKSHAK: Impossible Travel — Credential Compromise",
        "description": "Same user logged in from two geographically distant locations within minutes",
        "status"     : "stable",
        "level"      : "critical",
        "tags"       : ["attack.lateral_movement", "attack.t1078"],
        "logsource"  : {"product": "linux", "service": "auth"},
        "detection"  : {
            "keywords" : ["Accepted publickey", "Accepted password", "session opened"],
            "condition": "keywords",
        },
        "falsepositives": ["VPN usage", "Proxy login", "NAT gateway"],
        "fields"     : ["user", "src_ip", "timestamp"],
    },

    "log_tampering": {
        "title"      : "RAKSHAK: Log Tampering — Anti-Forensics",
        "description": "Attacker attempting to erase evidence — log deletion or history clearing",
        "status"     : "stable",
        "level"      : "high",
        "tags"       : ["attack.defense_evasion", "attack.t1070"],
        "logsource"  : {"product": "linux", "service": "auditd"},
        "detection"  : {
            "keywords" : ["history -c", "rm /var/log", "truncate", "unset HISTFILE",
                         "HISTSIZE=0", "shred /var/log"],
            "condition": "1 of keywords",
        },
        "falsepositives": ["Automated log rotation scripts", "Legitimate admin housekeeping"],
        "fields"     : ["user", "command", "timestamp"],
    },

    "privilege_escalation": {
        "title"      : "RAKSHAK: Privilege Escalation Attempt",
        "description": "User attempting to gain elevated privileges — potential system compromise",
        "status"     : "stable",
        "level"      : "high",
        "tags"       : ["attack.privilege_escalation", "attack.t1548"],
        "logsource"  : {"product": "linux", "service": "auth"},
        "detection"  : {
            "keywords" : ["sudo: COMMAND", "su -", "sudo su", "chmod +s",
                         "chmod 4755", "chown root"],
            "condition": "1 of keywords",
        },
        "falsepositives": ["Legitimate admin operations"],
        "fields"     : ["user", "command", "terminal", "timestamp"],
    },

    "lateral_movement": {
        "title"      : "RAKSHAK: Lateral Movement — Internal Network Spread",
        "description": "Post-login internal host scanning or SMB/RDP spread detected",
        "status"     : "stable",
        "level"      : "critical",
        "tags"       : ["attack.lateral_movement", "attack.t1021"],
        "logsource"  : {"category": "firewall"},
        "detection"  : {
            "keywords"   : ["10.", "192.168.", "172.16."],
            "destination": ["445", "3389", "22", "5985"],
            "condition"  : "keywords and destination",
        },
        "falsepositives": ["Legitimate admin remote access", "Backup systems"],
        "fields"     : ["src_ip", "dst_ip", "dst_port", "timestamp"],
    },

    "data_exfiltration": {
        "title"      : "RAKSHAK: Data Exfiltration — Large Transfer to External Host",
        "description": "Unusually large data transfer to external destination — possible exfiltration",
        "status"     : "stable",
        "level"      : "high",
        "tags"       : ["attack.exfiltration", "attack.t1048"],
        "logsource"  : {"category": "proxy"},
        "detection"  : {
            "keywords"  : ["scp", "sftp", "rsync"],
            "filter_int": {"dst_ip": ["10.", "192.168.", "172."]},
            "condition" : "keywords and not filter_int",
        },
        "falsepositives": ["Authorised backup to cloud", "Sanctioned file sharing"],
        "fields"     : ["user", "dst_ip", "bytes_sent", "timestamp"],
    },

    "apt36_indicators": {
        "title"      : "RAKSHAK: APT36 (Transparent Tribe) Infrastructure Contact",
        "description": "Connection to known APT36/Transparent Tribe IP range (Pakistan intelligence)",
        "status"     : "stable",
        "level"      : "critical",
        "tags"       : ["attack.t1071", "apt.apt36", "drdo.critical"],
        "logsource"  : {"category": "firewall"},
        "detection"  : {
            "dst_ip_contains": ["103.59.144", "103.59.145", "103.255.6",
                                "182.176", "223.29.192"],
            "condition"      : "dst_ip_contains",
        },
        "falsepositives": ["None expected — these are confirmed APT36 ranges"],
        "fields"     : ["src_ip", "dst_ip", "protocol", "timestamp"],
    },
}


class SigmaGenerator:
    """
    RAKSHAK Sigma Rule Auto-Generator
    Every confirmed detection becomes a reusable SIEM detection rule.
    """

    def generate(self, analysis_results: dict) -> dict:
        """
        Take RAKSHAK analysis output and auto-generate relevant Sigma rules.
        Returns rules as YAML-formatted strings ready for SIEM import.
        """
        rules_generated = []
        triggered_types = self._identify_triggered_types(analysis_results)

        for rule_type in triggered_types:
            if rule_type in SIGMA_TEMPLATES:
                rule_yaml = self._render_rule(
                    rule_type,
                    SIGMA_TEMPLATES[rule_type],
                    analysis_results
                )
                rules_generated.append({
                    "type"     : rule_type,
                    "yaml"     : rule_yaml,
                    "siem_cmds": self._get_siem_import_commands(rule_type),
                })

        return {
            "rules_generated": rules_generated,
            "count"          : len(rules_generated),
            "sigma_version"  : "0.22",
            "generated_at"   : datetime.utcnow().isoformat() + "Z",
            "note"           : (
                "Import these rules into Splunk / QRadar / Elastic SIEM / "
                "Microsoft Sentinel to protect all connected organizations"
            ),
        }

    def _identify_triggered_types(self, results: dict) -> list:
        """Map analysis findings to Sigma rule types."""
        types = set()

        # Check brute force
        if results.get("brute_force_detected") or results.get("brute_force", {}).get("count", 0) > 5:
            types.add("brute_force")

        # Check SQL injection
        if results.get("sqli_attempts") or results.get("db_findings"):
            types.add("sql_injection")

        # Check DNS tunneling
        dns = results.get("dns_tunneling", [])
        if dns:
            types.add("dns_tunneling")

        # Check beaconing
        if results.get("beacons_detected"):
            types.add("c2_beaconing")

        # Check impossible travel
        if results.get("impossible_travel"):
            types.add("impossible_travel")

        # Check log tampering
        if results.get("log_tampering_detected"):
            types.add("log_tampering")

        # Check privilege escalation
        priv = results.get("privilege_escalation_detected") or results.get("privilege_creep")
        if priv:
            types.add("privilege_escalation")

        # Check lateral movement
        if results.get("lateral_movement_detected"):
            types.add("lateral_movement")

        # Check data exfiltration
        if results.get("unauthorized_dumps") or results.get("bulk_data_access"):
            types.add("data_exfiltration")

        # Check APT attribution
        apt = results.get("apt_attribution", [])
        if any("APT36" in a.get("apt_name", "") for a in apt):
            types.add("apt36_indicators")

        # Always include high-value types for DRDO context
        types.update(["log_tampering", "lateral_movement"])

        return list(types)

    def _render_rule(self, rule_type: str, template: dict, results: dict) -> str:
        """Render Sigma rule as YAML string."""
        rule_id   = str(uuid.uuid4())
        timestamp = datetime.utcnow().strftime("%Y/%m/%d")

        # Enrich with specific IOCs from analysis
        iocs_comment = ""
        top_ips = results.get("top_attacker_ips", [])
        if top_ips:
            iocs_comment = f"# Specific IPs observed: {', '.join(str(ip) for ip in top_ips[:3])}\n"

        tags_str = "\n".join(f"    - {t}" for t in template.get("tags", []))
        fields_str = "\n".join(f"    - {f}" for f in template.get("fields", []))
        fp_str = "\n".join(f"  - {fp}" for fp in template.get("falsepositives", []))

        detection = template.get("detection", {})
        det_lines = []
        for key, val in detection.items():
            if isinstance(val, list):
                det_lines.append(f"    {key}:")
                det_lines.extend(f"      - '{v}'" for v in val)
            elif isinstance(val, str):
                det_lines.append(f"    {key}: '{val}'")
            elif isinstance(val, int):
                det_lines.append(f"    {key}: {val}")
        detection_str = "\n".join(det_lines)

        yaml = f"""title: {template['title']}
id: {rule_id}
status: {template.get('status', 'experimental')}
description: |
  {template['description']}
  Source: RAKSHAK v3.1.1 Auto-Generated Rule | Case: {results.get('case_id', 'RAKSHAK-LIVE')}
  Generated: {timestamp}
references:
  - https://attack.mitre.org
  - https://github.com/SriRamkunamsetty/RAKSHAK
author: RAKSHAK — Mohan Sriram Kunamsetty (QIS College of Engineering, Ongole)
date: {timestamp}
modified: {timestamp}
tags:
{tags_str}
logsource:
  product: {template['logsource'].get('product', 'linux')}
  service: {template['logsource'].get('service', template['logsource'].get('category', 'syslog'))}
{iocs_comment}detection:
{detection_str}
falsepositives:
{fp_str}
level: {template.get('level', 'medium')}
fields:
{fields_str}
"""
        return yaml.strip()

    def _get_siem_import_commands(self, rule_type: str) -> dict:
        safe_type = rule_type.replace("_", "-")
        return {
            "splunk"   : f"| inputlookup sigma_rules | search rule_type={safe_type}",
            "elastic"  : f"PUT _security/detection_engine/rules (import YAML via Kibana)",
            "qradar"   : f"Custom Rule Wizard → Import Sigma → {safe_type}.yml",
            "sentinel" : f"Analytics → Import from file → {safe_type}.yaml",
        }
