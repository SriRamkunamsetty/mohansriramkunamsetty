"""
RAKSHAK — Multi-Log Correlation Engine
Correlates auth.log + Apache/Nginx + firewall + syslog simultaneously
Reveals full attack chains invisible in any single log source
"""

import re
from datetime import datetime, timezone
from collections import defaultdict
from typing import Optional


# ── Log source auto-detection ─────────────────────────────────────────────────
LOG_SOURCE_PATTERNS = {
    "auth"    : [r"sshd\[\d+\]", r"Failed password", r"Accepted password",
                 r"pam_unix.*auth", r"sudo.*authentication"],
    "apache"  : [r'"GET |"POST |"PUT |"DELETE ', r'HTTP/1\.[01]"\s+\d{3}',
                 r"\[error\].*client", r"mod_security"],
    "nginx"   : [r'nginx/\d', r'"GET .*HTTP.*"\s+\d{3}', r'\[warn\]|\[crit\]'],
    "firewall": [r"DROP IN=|REJECT IN=|BLOCK IN=", r"SRC=\d+\.\d+",
                 r"iptables|nftables|ufw"],
    "syslog"  : [r"kernel:", r"systemd\[\d+\]", r"cron\[\d+\]", r"CRON\[\d+\]"],
    "audit"   : [r"type=EXECVE|type=SYSCALL|type=PATH", r"audit\[\d+\]"],
    "windows" : [r"EventID:|Event ID:", r"Logon Failure|Logon Success",
                 r"Security|Application|System.*Event"],
}

# ── Attack phase transition rules ─────────────────────────────────────────────
PHASE_TRANSITIONS = [
    # Phase 1→2: Recon leading to exploitation
    ("RECONNAISSANCE", "EXPLOITATION",
     "Port scan followed by targeted exploit attempt"),
    # Phase 2→3: Exploitation leading to privilege escalation
    ("EXPLOITATION", "PRIVILEGE_ESCALATION",
     "Successful login followed by sudo/su"),
    # Phase 3→4: Priv esc leading to lateral movement
    ("PRIVILEGE_ESCALATION", "LATERAL_MOVEMENT",
     "Root access followed by internal network scan"),
    # Phase 4→5: Lateral movement leading to exfiltration
    ("LATERAL_MOVEMENT", "EXFILTRATION",
     "Internal access followed by data transfer"),
]


class MultiLogCorrelator:
    """
    RAKSHAK Multi-Log Correlation Engine
    
    Accepts multiple log files simultaneously and correlates events
    across sources by IP address and timestamp proximity.
    
    Reveals: Full kill chains, pivoting attacks, coordinated campaigns
    """

    def correlate(self, log_sources: dict[str, str],
                  time_window_sec: int = 300) -> dict:
        """
        Correlate multiple log sources.
        
        Args:
            log_sources: dict of {source_name: log_content}
                e.g. {"auth": "...", "apache": "...", "firewall": "..."}
            time_window_sec: events within this window are correlated
        
        Returns:
            Unified correlation report with full attack chains
        """
        # ── 1. Auto-detect and parse all sources ──────────────────────
        parsed_events: list[dict] = []
        detected_sources = {}

        for source_name, content in log_sources.items():
            detected_type = self._detect_log_type(content) or source_name
            detected_sources[source_name] = detected_type
            events = self._parse_log(content, detected_type, source_name)
            parsed_events.extend(events)

        # ── 2. Group events by attacker IP ─────────────────────────────
        ip_events: dict[str, list] = defaultdict(list)
        for event in parsed_events:
            if event.get("ip"):
                ip_events[event["ip"]].append(event)

        # ── 3. Build attack chains per IP ──────────────────────────────
        attack_chains = []
        for ip, events in ip_events.items():
            if len(events) < 2:
                continue
            events_sorted = sorted(events, key=lambda x: x.get("seq", 0))
            chain = self._build_chain(ip, events_sorted, time_window_sec)
            if chain:
                attack_chains.append(chain)

        # ── 4. Detect multi-source correlations ────────────────────────
        multi_source = [
            c for c in attack_chains
            if len(set(e["source"] for e in c["events"])) > 1
        ]

        # ── 5. Sort by severity ────────────────────────────────────────
        attack_chains.sort(
            key=lambda x: x["chain_risk_score"], reverse=True
        )

        return {
            "sources_analysed"   : detected_sources,
            "total_events"       : len(parsed_events),
            "unique_attacker_ips": len(ip_events),
            "attack_chains"      : attack_chains[:20],
            "multi_source_attacks": multi_source[:10],
            "unified_timeline"   : self._build_unified_timeline(parsed_events),
            "cross_source_ips"   : [
                ip for ip, evs in ip_events.items()
                if len(set(e["source"] for e in evs)) > 1
            ][:10],
            "correlation_findings": self._correlation_findings(
                attack_chains, multi_source
            ),
        }

    def _detect_log_type(self, content: str) -> Optional[str]:
        """Auto-detect log format from content."""
        sample = content[:3000]
        scores = {}
        for log_type, patterns in LOG_SOURCE_PATTERNS.items():
            scores[log_type] = sum(
                1 for p in patterns
                if re.search(p, sample, re.IGNORECASE)
            )
        if not scores:
            return None
        best = max(scores, key=scores.get)
        return best if scores[best] > 0 else None

    def _parse_log(self, content: str, log_type: str,
                   source_name: str) -> list[dict]:
        """Parse a single log source into normalised event dicts."""
        events = []
        lines  = content.splitlines()

        for seq, line in enumerate(lines):
            event = self._parse_line(line, log_type, source_name, seq)
            if event:
                events.append(event)

        return events

    def _parse_line(self, line: str, log_type: str,
                    source: str, seq: int) -> Optional[dict]:
        """Extract normalised event from a single log line."""
        event = {
            "source"    : source,
            "log_type"  : log_type,
            "raw"       : line[:200],
            "seq"       : seq,
            "ip"        : None,
            "user"      : None,
            "action"    : None,
            "phase"     : None,
            "severity"  : "INFO",
            "timestamp" : "",
            "port"      : None,
            "path"      : None,
        }

        # Extract IP
        ip_match = re.search(r'(?:from|src|SRC=|client)\s*([\d.]+)', line, re.I)
        if not ip_match:
            ip_match = re.search(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b', line)
        if ip_match:
            event["ip"] = ip_match.group(1)

        # Skip private IPs
        if event["ip"] and self._is_private(event["ip"]):
            event["ip"] = None

        # Extract timestamp
        ts_patterns = [
            r'(\w{3}\s+\d+\s+[\d:]+)',
            r'(\d{4}-\d{2}-\d{2}[T\s][\d:]+)',
            r'\[(\d{2}/\w+/\d{4}:[\d:]+)',
        ]
        for tp in ts_patterns:
            m = re.search(tp, line)
            if m:
                event["timestamp"] = m.group(1)
                break

        # Classify action and phase
        if log_type == "auth":
            if "Failed password" in line or "Invalid user" in line:
                event["action"]   = "SSH_FAIL"
                event["phase"]    = "INITIAL_ACCESS"
                event["severity"] = "MEDIUM"
            elif "Accepted" in line:
                event["action"]   = "SSH_SUCCESS"
                event["phase"]    = "INITIAL_ACCESS_SUCCESS"
                event["severity"] = "HIGH"
            elif "sudo" in line.lower():
                event["action"]   = "SUDO"
                event["phase"]    = "PRIVILEGE_ESCALATION"
                event["severity"] = "HIGH"
            else:
                return None

        elif log_type in ("apache", "nginx"):
            m = re.search(r'"(?:GET|POST|PUT|DELETE) ([^\s"]+)', line)
            if m:
                path = m.group(1)
                event["path"] = path[:100]
                # Classify web activity
                scan_kw = ["wp-admin", ".env", "passwd", "phpMyAdmin",
                           "../", "cmd.exe", "shell", ".git", "backup"]
                exploit_kw = ["eval(", "base64_decode", "system(", "<script",
                              "UNION SELECT", "' OR '1'='1"]
                if any(k in path for k in exploit_kw):
                    event["action"]   = "WEB_EXPLOIT"
                    event["phase"]    = "EXPLOITATION"
                    event["severity"] = "CRITICAL"
                elif any(k.lower() in path.lower() for k in scan_kw):
                    event["action"]   = "WEB_SCAN"
                    event["phase"]    = "RECONNAISSANCE"
                    event["severity"] = "HIGH"
                else:
                    event["action"]   = "HTTP_REQUEST"
                    event["phase"]    = "RECONNAISSANCE"
                    event["severity"] = "LOW"
            else:
                return None

        elif log_type == "firewall":
            m = re.search(r'DPT=(\d+)', line)
            if m:
                event["port"]   = int(m.group(1))
                event["action"] = "PORT_DROP"
                event["phase"]  = "RECONNAISSANCE"
                # Many distinct ports = port scan
                event["severity"] = "HIGH"
            else:
                return None

        elif log_type == "audit":
            if "EXECVE" in line:
                cmd_m = re.search(r'a0="([^"]+)"', line)
                if cmd_m:
                    event["action"]   = "COMMAND_EXEC"
                    event["path"]     = cmd_m.group(1)[:80]
                    event["phase"]    = "POST_EXPLOIT"
                    event["severity"] = "HIGH"
                else:
                    return None
            else:
                return None

        elif log_type == "syslog":
            if "cron" in line.lower() and ("CMD" in line or "CRON" in line):
                event["action"]   = "CRON_EXEC"
                event["phase"]    = "PERSISTENCE"
                event["severity"] = "MEDIUM"
            else:
                return None
        else:
            return None

        return event if event["ip"] or event["action"] else None

    def _build_chain(self, ip: str, events: list,
                     window: int) -> Optional[dict]:
        """Build an attack chain for a single IP."""
        phases  = list(dict.fromkeys(
            e["phase"] for e in events if e.get("phase")
        ))
        sources = list(set(e["source"] for e in events))

        # Risk score
        score = 0
        phase_scores = {
            "INITIAL_ACCESS"         : 10,
            "INITIAL_ACCESS_SUCCESS" : 30,
            "RECONNAISSANCE"         : 15,
            "EXPLOITATION"           : 35,
            "PRIVILEGE_ESCALATION"   : 30,
            "POST_EXPLOIT"           : 25,
            "LATERAL_MOVEMENT"       : 30,
            "PERSISTENCE"            : 30,
            "EXFILTRATION"           : 40,
        }
        for phase in phases:
            score += phase_scores.get(phase, 5)
        # Bonus for multi-source
        score += len(sources) * 10
        score  = min(score, 100)

        # Kill chain description
        kill_chain_desc = " → ".join(phases) if phases else "Unknown"

        return {
            "attacker_ip"      : ip,
            "events"           : events[:30],
            "event_count"      : len(events),
            "phases_observed"  : phases,
            "kill_chain"       : kill_chain_desc,
            "sources_involved" : sources,
            "chain_risk_score" : score,
            "severity"         : "CRITICAL" if score >= 70
                                  else "HIGH" if score >= 45
                                  else "MEDIUM",
            "multi_source"     : len(sources) > 1,
            "is_apt_behaviour" : len(phases) >= 3 and len(sources) > 1,
        }

    def _build_unified_timeline(self, events: list) -> list:
        """Merge all events into a single sorted timeline."""
        timeline = [
            {
                "timestamp": e.get("timestamp",""),
                "source"   : e.get("source",""),
                "ip"       : e.get("ip",""),
                "action"   : e.get("action",""),
                "phase"    : e.get("phase",""),
                "severity" : e.get("severity","INFO"),
                "detail"   : e.get("path","") or e.get("raw","")[:60],
            }
            for e in events
            if e.get("action") and e.get("severity") in ("HIGH","CRITICAL","MEDIUM")
        ]
        return sorted(timeline, key=lambda x: x["timestamp"])[:50]

    def _correlation_findings(self, chains: list,
                               multi_source: list) -> list:
        """Generate human-readable correlation findings."""
        findings = []
        if multi_source:
            findings.append({
                "severity"   : "CRITICAL",
                "type"       : "MULTI_SOURCE_ATTACK",
                "description": f"{len(multi_source)} attacker(s) visible across multiple "
                               f"log sources — full kill chain reconstructed",
                "detail"     : f"IPs: {', '.join(c['attacker_ip'] for c in multi_source[:3])}",
            })
        apt_chains = [c for c in chains if c.get("is_apt_behaviour")]
        if apt_chains:
            findings.append({
                "severity"   : "CRITICAL",
                "type"       : "APT_BEHAVIOUR",
                "description": f"{len(apt_chains)} attacker(s) exhibit multi-phase APT behaviour",
                "detail"     : f"Phases: {apt_chains[0]['kill_chain'] if apt_chains else ''}",
            })
        if not findings:
            findings.append({
                "severity"   : "INFO",
                "type"       : "NO_CORRELATION",
                "description": "No cross-source attack chains detected",
                "detail"     : "Provide multiple log files for correlation analysis",
            })
        return findings

    @staticmethod
    def _is_private(ip: str) -> bool:
        try:
            parts = [int(p) for p in ip.split(".")]
            return (parts[0] == 10 or parts[0] == 127 or
                    (parts[0] == 172 and 16 <= parts[1] <= 31) or
                    (parts[0] == 192 and parts[1] == 168))
        except Exception:
            return False
