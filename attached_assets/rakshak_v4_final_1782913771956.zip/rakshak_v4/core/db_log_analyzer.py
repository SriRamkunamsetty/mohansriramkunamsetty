"""
RAKSHAK — Database Audit Log Analyzer
MySQL · PostgreSQL · Oracle · MSSQL audit log analysis
Detects SQL injection, unauthorized dumps, privilege escalation inside DB layer
"""

import re
from collections import defaultdict, Counter
from datetime import datetime


# ── Dangerous SQL patterns ────────────────────────────────────────────────────
SQLI_PATTERNS = [
    (r"('\s*OR\s*'1'\s*=\s*'1|'\s*OR\s*1\s*=\s*1)", "Classic OR-based SQLi"),
    (r"(UNION\s+(?:ALL\s+)?SELECT)", "UNION-based SQLi"),
    (r"(;\s*DROP\s+TABLE|;\s*DROP\s+DATABASE)", "Destructive DROP injection"),
    (r"(SLEEP\s*\(\d+\)|WAITFOR\s+DELAY|BENCHMARK\s*\()", "Time-based blind SQLi"),
    (r"(LOAD_FILE\s*\(|INTO\s+OUTFILE|INTO\s+DUMPFILE)", "File read/write SQLi"),
    (r"(xp_cmdshell|sp_executesql|exec\s+master)", "MSSQL command execution"),
    (r"(INFORMATION_SCHEMA|sys\.tables|pg_catalog)", "Schema enumeration"),
    (r"(0x[0-9a-fA-F]{8,})", "Hex-encoded payload"),
    (r"(CHAR\s*\(\d+\)\s*\+\s*CHAR\s*\(\d+\))", "CHAR() concatenation obfuscation"),
    (r"(/\*.*?\*/|--\s*$)", "SQL comment stripping"),
]

# ── Sensitive tables commonly targeted ────────────────────────────────────────
SENSITIVE_TABLES = {
    "users", "user", "accounts", "passwords", "credentials",
    "employees", "salary", "personnel", "secrets", "tokens",
    "sessions", "auth", "admin", "roles", "permissions",
    "payment", "credit_card", "ssn", "classified", "restricted",
}

# ── MySQL error log / general log patterns ────────────────────────────────────
MYSQL_QUERY_PAT  = re.compile(
    r'(?P<ts>\d{4}-\d{2}-\d{2}T[\d:.]+).*?(?:Query|Execute)\s+(?P<query>.+)',
    re.IGNORECASE
)
MYSQL_LOGIN_PAT  = re.compile(
    r'(?P<ts>[\d\-T:.]+).*?(?P<user>\w+)\[(?P<host>[\w.]+)\].*?(?P<action>Connect|Quit|Failed)',
    re.IGNORECASE
)
MYSQL_ERROR_PAT  = re.compile(
    r'Access denied for user \'(?P<user>[^\']+)\'@\'(?P<host>[^\']+)\'',
    re.IGNORECASE
)

# ── PostgreSQL log patterns ────────────────────────────────────────────────────
PG_QUERY_PAT     = re.compile(
    r'(?P<ts>\d{4}-\d{2}-\d{2}\s+[\d:]+\.\d+).*?(?:LOG|STATEMENT):\s+(?P<query>.+)',
    re.IGNORECASE
)
PG_AUTH_PAT      = re.compile(
    r'(?:FATAL|ERROR).*?(?:password authentication failed|no pg_hba.conf entry)'
    r'.*?user "(?P<user>[^"]+)"',
    re.IGNORECASE
)
PG_PRIV_PAT      = re.compile(
    r'(?:GRANT|REVOKE).*?(?P<priv>ALL|SUPERUSER|CREATEDB|CREATEROLE)',
    re.IGNORECASE
)

# ── Oracle audit patterns ─────────────────────────────────────────────────────
ORA_AUDIT_PAT    = re.compile(
    r'ACTION\s*:\s*(?P<action>[^\n]+).*?'
    r'(?:DB User|USERID)\s*:\s*(?P<user>[^\s]+)',
    re.IGNORECASE | re.DOTALL
)
ORA_LOGON_PAT    = re.compile(
    r'LOGON\s+FAILED.*?USER:\s*(?P<user>\w+).*?IP:\s*(?P<ip>[\d.]+)',
    re.IGNORECASE
)


class DatabaseLogAnalyzer:
    """
    RAKSHAK Database Audit Log Analyzer
    Parses MySQL, PostgreSQL, Oracle audit logs to detect
    SQL injection, data exfiltration, privilege abuse.
    """

    def analyze(self, log_text: str, db_type: str = "auto") -> dict:
        lines = log_text.splitlines()

        if db_type == "auto":
            db_type = self._detect_db_type(log_text)

        result = {
            "db_type"               : db_type,
            "total_lines"           : len(lines),
            "sqli_attempts"         : self._detect_sqli(lines),
            "unauthorized_dumps"    : self._detect_dumps(lines),
            "privilege_escalation"  : self._detect_priv_esc(lines),
            "failed_auth"           : self._detect_failed_auth(lines, db_type),
            "sensitive_table_access": self._detect_sensitive_access(lines),
            "schema_enumeration"    : self._detect_schema_enum(lines),
            "db_risk_score"         : 0,
            "db_findings"           : [],
        }

        # Compute DB risk score
        score = 0
        score += min(len(result["sqli_attempts"])         * 30, 40)
        score += min(len(result["unauthorized_dumps"])    * 25, 30)
        score += min(len(result["privilege_escalation"])  * 20, 25)
        score += min(result["failed_auth"]["count"]       * 5,  20)
        score += min(len(result["sensitive_table_access"])* 8,  15)
        result["db_risk_score"] = min(score, 100)
        result["db_findings"]   = self._build_findings(result)
        return result

    def _detect_db_type(self, text: str) -> str:
        if re.search(r'mysqld|InnoDB|binlog', text, re.IGNORECASE):
            return "MySQL"
        if re.search(r'postgresql|pg_hba|postmaster', text, re.IGNORECASE):
            return "PostgreSQL"
        if re.search(r'ORACLE|ORA-\d+|SYS\.AUD\$', text, re.IGNORECASE):
            return "Oracle"
        if re.search(r'MSSQL|SQL Server|xp_cmdshell', text, re.IGNORECASE):
            return "MSSQL"
        return "Generic"

    def _detect_sqli(self, lines: list) -> list:
        detections = []
        for line in lines:
            for pattern, sqli_type in SQLI_PATTERNS:
                if re.search(pattern, line, re.IGNORECASE):
                    detections.append({
                        "sqli_type"  : sqli_type,
                        "raw_snippet": line[:150].strip(),
                        "severity"   : "CRITICAL",
                        "mitre"      : "T1190 — Exploit Public-Facing Application",
                    })
                    break   # one finding per line
        return detections[:30]

    def _detect_dumps(self, lines: list) -> list:
        dump_patterns = [
            (r'SELECT\s+\*\s+FROM', "Full table SELECT *"),
            (r'mysqldump|pg_dump|expdp', "Database dump utility"),
            (r'INTO\s+OUTFILE|INTO\s+DUMPFILE', "SQL file export"),
            (r'BACKUP\s+DATABASE|RESTORE\s+DATABASE', "DB backup command"),
            (r'SELECT.*INTO\s+@', "Variable data extraction"),
            (r'COPY\s+\w+\s+TO\s+STDOUT', "PostgreSQL COPY TO STDOUT"),
        ]
        detections = []
        for line in lines:
            for pattern, dump_type in dump_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    detections.append({
                        "dump_type"  : dump_type,
                        "raw_snippet": line[:150].strip(),
                        "severity"   : "HIGH",
                        "mitre"      : "T1005 — Data from Local System",
                    })
                    break
        return detections[:20]

    def _detect_priv_esc(self, lines: list) -> list:
        priv_patterns = [
            (r'GRANT\s+ALL', "GRANT ALL privileges"),
            (r'GRANT\s+.*\s+WITH\s+GRANT\s+OPTION', "GRANT WITH GRANT OPTION"),
            (r'CREATE\s+USER.*IDENTIFIED', "New user creation"),
            (r'ALTER\s+USER.*IDENTIFIED\s+BY', "Password change"),
            (r'EXEC\s+sp_addsrvrolemember', "MSSQL sysadmin grant"),
            (r'ALTER\s+ROLE.*SUPERUSER', "PostgreSQL SUPERUSER grant"),
            (r'xp_cmdshell', "OS command execution from DB"),
            (r'LOAD\s+DATA\s+INFILE', "File system access via MySQL"),
        ]
        detections = []
        for line in lines:
            for pattern, priv_type in priv_patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    detections.append({
                        "priv_type"  : priv_type,
                        "raw_snippet": line[:150].strip(),
                        "severity"   : "CRITICAL",
                        "mitre"      : "T1078 — Valid Accounts / Privilege Abuse",
                    })
                    break
        return detections[:20]

    def _detect_failed_auth(self, lines: list, db_type: str) -> dict:
        count   = 0
        sources = Counter()
        for line in lines:
            if re.search(
                r'access denied|authentication failed|login failed|'
                r'ORA-01017|28P01|18456',
                line, re.IGNORECASE
            ):
                count += 1
                ip = re.search(r'@\'?([\d.]+)\'?', line)
                if ip:
                    sources[ip.group(1)] += 1
        return {
            "count"      : count,
            "top_sources": sources.most_common(5),
            "brute_force": count >= 10,
        }

    def _detect_sensitive_access(self, lines: list) -> list:
        detections = []
        for line in lines:
            for table in SENSITIVE_TABLES:
                pattern = rf'\b{table}\b'
                if re.search(pattern, line, re.IGNORECASE):
                    if re.search(r'SELECT|INSERT|UPDATE|DELETE|TRUNCATE',
                                 line, re.IGNORECASE):
                        detections.append({
                            "table"      : table,
                            "raw_snippet": line[:120].strip(),
                            "severity"   : "HIGH",
                        })
                        break
        return detections[:20]

    def _detect_schema_enum(self, lines: list) -> list:
        enum_patterns = [
            r'INFORMATION_SCHEMA\.TABLES',
            r'INFORMATION_SCHEMA\.COLUMNS',
            r'pg_catalog\.pg_tables',
            r'sys\.all_tables',
            r'DBA_TABLES',
            r'SHOW\s+DATABASES',
            r'SHOW\s+TABLES',
            r'\\dt|\\l\b',   # psql meta-commands
        ]
        detections = []
        for line in lines:
            for pat in enum_patterns:
                if re.search(pat, line, re.IGNORECASE):
                    detections.append({
                        "pattern"    : pat,
                        "raw_snippet": line[:120].strip(),
                        "severity"   : "MEDIUM",
                        "description": "Database schema enumeration — attacker mapping DB structure",
                    })
                    break
        return detections[:10]

    def _build_findings(self, result: dict) -> list:
        findings = []
        if result["sqli_attempts"]:
            findings.append({
                "severity"   : "CRITICAL",
                "category"   : "SQL Injection",
                "description": f"{len(result['sqli_attempts'])} SQL injection attempts "
                               f"detected — database may be compromised",
                "action"     : "Patch application immediately + WAF rule deployment",
            })
        if result["unauthorized_dumps"]:
            findings.append({
                "severity"   : "CRITICAL",
                "category"   : "Data Exfiltration via Database",
                "description": f"{len(result['unauthorized_dumps'])} database dump "
                               f"operations detected — possible mass data theft",
                "action"     : "Audit what data was accessed + notify DPO + IT Act Section 43",
            })
        if result["privilege_escalation"]:
            findings.append({
                "severity"   : "CRITICAL",
                "category"   : "DB Privilege Escalation",
                "description": f"{len(result['privilege_escalation'])} privilege "
                               f"escalation events — attacker gaining database control",
                "action"     : "Revoke privileges + rotate all DB credentials",
            })
        if result["failed_auth"]["brute_force"]:
            findings.append({
                "severity"   : "HIGH",
                "category"   : "Database Brute Force",
                "description": f"{result['failed_auth']['count']} failed DB authentication "
                               f"attempts — credential attack on database layer",
                "action"     : "Block source IPs + enable account lockout policy",
            })
        return findings
