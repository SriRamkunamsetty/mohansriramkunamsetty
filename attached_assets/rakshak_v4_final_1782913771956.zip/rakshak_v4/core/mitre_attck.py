"""
RAKSHAK v4 — MITRE ATT&CK Enterprise Mapping Engine
Maps log events and APK indicators → ATT&CK Tactics → Techniques → Sub-techniques
Generates ATT&CK Navigator heatmaps and next-stage prediction
"""

import re
from datetime import datetime, timezone

# ── Full ATT&CK Technique Registry (Enterprise + Mobile) ─────────────────────
TECHNIQUE_DB = {
    # INITIAL ACCESS
    "T1566":   {"name": "Phishing",                   "tactic": "Initial Access",      "severity": "HIGH"},
    "T1566.001":{"name": "Spearphishing Attachment",  "tactic": "Initial Access",      "severity": "HIGH"},
    "T1566.002":{"name": "Spearphishing Link",        "tactic": "Initial Access",      "severity": "HIGH"},
    "T1190":   {"name": "Exploit Public-Facing App",  "tactic": "Initial Access",      "severity": "CRITICAL"},
    "T1078":   {"name": "Valid Accounts",              "tactic": "Initial Access",      "severity": "HIGH"},
    "T1133":   {"name": "External Remote Services",   "tactic": "Initial Access",      "severity": "MEDIUM"},
    "T1195":   {"name": "Supply Chain Compromise",    "tactic": "Initial Access",      "severity": "CRITICAL"},

    # EXECUTION
    "T1059":   {"name": "Command & Scripting Interpreter","tactic": "Execution",       "severity": "HIGH"},
    "T1059.001":{"name": "PowerShell",                "tactic": "Execution",           "severity": "HIGH"},
    "T1059.003":{"name": "Windows Command Shell",     "tactic": "Execution",           "severity": "HIGH"},
    "T1059.004":{"name": "Unix Shell",                "tactic": "Execution",           "severity": "HIGH"},
    "T1053":   {"name": "Scheduled Task/Job",         "tactic": "Execution",           "severity": "MEDIUM"},
    "T1569":   {"name": "System Services",            "tactic": "Execution",           "severity": "MEDIUM"},
    "T1204":   {"name": "User Execution",             "tactic": "Execution",           "severity": "MEDIUM"},

    # PERSISTENCE
    "T1547":   {"name": "Boot/Logon Autostart",       "tactic": "Persistence",         "severity": "HIGH"},
    "T1543":   {"name": "Create/Modify System Process","tactic": "Persistence",        "severity": "HIGH"},
    "T1136":   {"name": "Create Account",             "tactic": "Persistence",         "severity": "HIGH"},
    "T1098":   {"name": "Account Manipulation",       "tactic": "Persistence",         "severity": "HIGH"},
    "T1505":   {"name": "Server Software Component",  "tactic": "Persistence",         "severity": "CRITICAL"},

    # PRIVILEGE ESCALATION
    "T1068":   {"name": "Exploitation for Privilege Escalation","tactic":"Privilege Escalation","severity":"CRITICAL"},
    "T1548":   {"name": "Abuse Elevation Control",    "tactic": "Privilege Escalation","severity": "HIGH"},
    "T1134":   {"name": "Access Token Manipulation",  "tactic": "Privilege Escalation","severity": "HIGH"},

    # DEFENSE EVASION
    "T1070":   {"name": "Indicator Removal",          "tactic": "Defense Evasion",     "severity": "HIGH"},
    "T1070.001":{"name": "Clear Windows Event Logs",  "tactic": "Defense Evasion",     "severity": "HIGH"},
    "T1070.002":{"name": "Clear Linux/Mac System Logs","tactic":"Defense Evasion",     "severity": "HIGH"},
    "T1562":   {"name": "Impair Defenses",            "tactic": "Defense Evasion",     "severity": "HIGH"},
    "T1036":   {"name": "Masquerading",               "tactic": "Defense Evasion",     "severity": "MEDIUM"},
    "T1027":   {"name": "Obfuscated Files/Info",      "tactic": "Defense Evasion",     "severity": "MEDIUM"},
    "T1218":   {"name": "Living-off-the-Land Binaries","tactic":"Defense Evasion",     "severity": "HIGH"},

    # CREDENTIAL ACCESS
    "T1003":   {"name": "OS Credential Dumping",      "tactic": "Credential Access",   "severity": "CRITICAL"},
    "T1003.001":{"name": "LSASS Memory",              "tactic": "Credential Access",   "severity": "CRITICAL"},
    "T1110":   {"name": "Brute Force",                "tactic": "Credential Access",   "severity": "HIGH"},
    "T1110.001":{"name": "Password Guessing",         "tactic": "Credential Access",   "severity": "HIGH"},
    "T1110.003":{"name": "Password Spraying",         "tactic": "Credential Access",   "severity": "HIGH"},
    "T1555":   {"name": "Credentials from Password Stores","tactic":"Credential Access","severity":"HIGH"},
    "T1056":   {"name": "Input Capture (Keylogging)", "tactic": "Credential Access",   "severity": "CRITICAL"},

    # DISCOVERY
    "T1046":   {"name": "Network Service Discovery",  "tactic": "Discovery",           "severity": "MEDIUM"},
    "T1082":   {"name": "System Information Discovery","tactic":"Discovery",            "severity": "LOW"},
    "T1057":   {"name": "Process Discovery",          "tactic": "Discovery",           "severity": "LOW"},
    "T1083":   {"name": "File and Directory Discovery","tactic":"Discovery",            "severity": "LOW"},
    "T1087":   {"name": "Account Discovery",          "tactic": "Discovery",           "severity": "MEDIUM"},

    # LATERAL MOVEMENT
    "T1021":   {"name": "Remote Services",            "tactic": "Lateral Movement",    "severity": "HIGH"},
    "T1021.001":{"name": "Remote Desktop Protocol",   "tactic": "Lateral Movement",    "severity": "HIGH"},
    "T1021.002":{"name": "SMB/Windows Admin Shares",  "tactic": "Lateral Movement",    "severity": "HIGH"},
    "T1021.004":{"name": "SSH",                       "tactic": "Lateral Movement",    "severity": "HIGH"},
    "T1570":   {"name": "Lateral Tool Transfer",      "tactic": "Lateral Movement",    "severity": "HIGH"},

    # COLLECTION
    "T1074":   {"name": "Data Staged",                "tactic": "Collection",          "severity": "HIGH"},
    "T1560":   {"name": "Archive Collected Data",     "tactic": "Collection",          "severity": "MEDIUM"},
    "T1213":   {"name": "Data from Info Repositories","tactic":"Collection",           "severity": "HIGH"},
    "T1005":   {"name": "Data from Local System",     "tactic": "Collection",          "severity": "MEDIUM"},

    # COMMAND & CONTROL
    "T1071":   {"name": "Application Layer Protocol", "tactic": "Command and Control", "severity": "HIGH"},
    "T1071.001":{"name": "Web Protocols (HTTP/S)",    "tactic": "Command and Control", "severity": "HIGH"},
    "T1071.004":{"name": "DNS",                       "tactic": "Command and Control", "severity": "HIGH"},
    "T1095":   {"name": "Non-Application Layer Proto","tactic":"Command and Control",  "severity": "HIGH"},
    "T1132":   {"name": "Data Encoding",              "tactic": "Command and Control", "severity": "MEDIUM"},
    "T1573":   {"name": "Encrypted Channel",          "tactic": "Command and Control", "severity": "HIGH"},

    # EXFILTRATION
    "T1041":   {"name": "Exfiltration Over C2 Channel","tactic":"Exfiltration",        "severity": "CRITICAL"},
    "T1048":   {"name": "Exfiltration Over Alt Protocol","tactic":"Exfiltration",      "severity": "CRITICAL"},
    "T1048.003":{"name": "Exfiltration Over Unencrypted","tactic":"Exfiltration",      "severity": "HIGH"},
    "T1567":   {"name": "Exfiltration Over Web Service","tactic":"Exfiltration",       "severity": "CRITICAL"},

    # IMPACT
    "T1486":   {"name": "Data Encrypted for Impact (Ransomware)","tactic":"Impact",   "severity": "CRITICAL"},
    "T1490":   {"name": "Inhibit System Recovery",    "tactic": "Impact",              "severity": "CRITICAL"},
    "T1499":   {"name": "Endpoint Denial of Service", "tactic": "Impact",              "severity": "HIGH"},
    "T1485":   {"name": "Data Destruction",           "tactic": "Impact",              "severity": "CRITICAL"},

    # MOBILE (for APK)
    "T1437":   {"name": "Application Layer Protocol (Mobile)","tactic":"Command and Control","severity":"HIGH"},
    "T1411":   {"name": "User Interface Spoofing",    "tactic": "Collection",          "severity": "HIGH"},
    "T1432":   {"name": "Access Contact List",        "tactic": "Collection",          "severity": "HIGH"},
    "T1412":   {"name": "Capture SMS Messages",       "tactic": "Collection",          "severity": "CRITICAL"},
    "T1414":   {"name": "Capture Clipboard Data",     "tactic": "Collection",          "severity": "HIGH"},
    "T1418":   {"name": "Software Discovery (Mobile)","tactic":"Discovery",            "severity": "MEDIUM"},
    "T1429":   {"name": "Capture Audio",              "tactic": "Collection",          "severity": "HIGH"},
    "T1512":   {"name": "Video Capture",              "tactic": "Collection",          "severity": "HIGH"},
    "T1430":   {"name": "Location Tracking",          "tactic": "Collection",          "severity": "HIGH"},
    "T1406":   {"name": "Obfuscated Files (Mobile)",  "tactic": "Defense Evasion",     "severity": "MEDIUM"},
    "T1508":   {"name": "Suppress Application Icon",  "tactic": "Defense Evasion",     "severity": "HIGH"},
}

# ── Log Event → ATT&CK Technique Pattern Map ──────────────────────────────────
# Each tuple: (regex_pattern, [technique_ids], description)
# Patterns are intentionally broad to catch varied log formats.
# The engine applies ALL matching patterns per line (no break).
LOG_PATTERN_MAP = [
    # ── Initial Access ────────────────────────────────────────────────────────
    (r'failed password|authentication failure|invalid user|login failed|logon failure',
     ["T1110", "T1110.001"], "Failed authentication — brute-force attempt"),
    (r'failed password.{0,60}(root|admin|administrator|drdo|oracle|postgres)',
     ["T1110", "T1078"], "Privileged account brute-force targeting"),
    (r'pam_unix.*auth.*failure|su.*failed|authentication.*failed',
     ["T1110", "T1548"], "PAM/system authentication failure"),
    (r'(get|post|put).{0,80}(\.php\?|\.asp\?|union.*select|or.*1=1|\.\.\/\.\.\/|<script)',
     ["T1190"], "Web application exploit attempt (SQL/XSS/path traversal)"),
    (r'sqlmap|havij|acunetix|nikto.*scan',
     ["T1190"], "Web application attack tool detected"),

    # ── Execution ─────────────────────────────────────────────────────────────
    (r'cmd\s*=|command=/bin/bash|command=/bin/sh|user=root.*command|sudo.*user=root',
     ["T1059", "T1548"], "Privileged command execution via sudo"),
    (r'/tmp/.*\.(sh|py|pl|elf|bin|exe)|chmod.*\+x.*/tmp|bash.*/tmp|sh\s+/tmp',
     ["T1059", "T1204"], "Malicious script execution from /tmp"),
    (r'powershell.*(-enc|-nop|-w hidden|-exec bypass)|cmd\.exe.*/c\s',
     ["T1059.001", "T1059.003"], "PowerShell/cmd suspicious execution"),
    (r'nc\s+-[el]|ncat\s+-[el]|/dev/tcp/|mkfifo\s+/tmp|bash -i',
     ["T1059", "T1071"], "Reverse shell or backdoor command"),
    (r'python.*-c.*import|perl.*-e|ruby.*-e|php.*-r',
     ["T1059"], "Scripting language one-liner execution"),

    # ── Persistence ───────────────────────────────────────────────────────────
    (r'crontab\s+-[el]|cron\.d|/etc/cron|at\s+-f|cron.*cmd',
     ["T1053", "T1547"], "Scheduled task / cron persistence"),
    (r'systemctl\s+(enable|daemon-reload|start).*\.(service|timer)|created symlink.*systemd',
     ["T1543"], "Systemd service creation / persistence"),
    (r'rc\.local|/etc/init\.d/|update-rc\.d|chkconfig.*on',
     ["T1547"], "Init script persistence mechanism"),
    (r'net user.*add|useradd|adduser|passwd.*-u\s|user.*created',
     ["T1136", "T1098"], "New user account creation"),
    (r'reg add.*run|hklm.*software.*microsoft.*windows.*currentversion.*run',
     ["T1547"], "Windows registry persistence (Run key)"),

    # ── Privilege Escalation ──────────────────────────────────────────────────
    (r'sudo.*user=root|su\s+root|su\s+-\s+root|successful su|uid=0',
     ["T1548", "T1134"], "Privilege escalation to root"),
    (r'sudo.*all.*nopasswd|visudo|/etc/sudoers',
     ["T1548"], "Sudoers file modification"),
    (r'suid|setuid|chmod.*\+s|chmod.*4[0-9]{3}',
     ["T1548"], "SUID binary / setuid permission abuse"),
    (r'capability.*cap_setuid|cap_net_admin|prctl.*pr_set_dumpable',
     ["T1548"], "Linux capability escalation"),

    # ── Defense Evasion ───────────────────────────────────────────────────────
    (r'rm\s+.*\.log|truncate.*log|>\s*/var/log|shred.*log|nametype=delete.*log',
     ["T1070", "T1070.002"], "Log file deletion / evidence destruction"),
    (r'iptables.*-f\s*$|iptables.*-p.*drop|ufw.*disable|systemctl.*stop.*(firewall|ufw|iptables)|setenforce\s+0',
     ["T1562"], "Firewall / security tool disablement"),
    (r'base64\s*-d|echo.*\|\s*base64|openssl.*base64|certutil.*decode',
     ["T1027"], "Base64 encoded content decode (obfuscation)"),
    (r'echo.*\|\s*(bash|sh|perl|python)|eval\s*\$|eval\s*`',
     ["T1027", "T1059"], "Obfuscated command pipeline execution"),
    (r'history\s+-c|unset\s+histfile|export\s+histsize=0|set\s+\+o\s+history',
     ["T1070"], "Shell history deletion / evasion"),
    (r'kill\s+.*auditd|service\s+auditd\s+stop|systemctl.*stop.*audit',
     ["T1562"], "Audit daemon killed — detection evasion"),

    # ── Credential Access ─────────────────────────────────────────────────────
    (r'/etc/shadow|/etc/passwd|/etc/security/opasswd|cat.*shadow',
     ["T1003", "T1555"], "Shadow/passwd file access — credential harvesting"),
    (r'mimikatz|lsass.*dump|procdump.*lsass|comsvcs.*minidump',
     ["T1003", "T1003.001"], "LSASS credential dumping tool"),
    (r'secretsdump|ntds\.dit|sam.*dump|fgdump|pwdump',
     ["T1003"], "Windows credential database dumping"),
    (r'accepted password.*from.*185\.|accepted password.*from.*194\.|accepted.*from.*tor',
     ["T1078"], "Suspicious source — successful login from flagged IP range"),
    (r'keylogger|xinput\s+test|/dev/input/event|logkeys',
     ["T1056"], "Keylogger activity detected"),
    (r'accepted\s+password\s+for',
     ["T1078"], "Successful authentication (track all valid logins)"),

    # ── Discovery ─────────────────────────────────────────────────────────────
    (r'nmap|masscan|zmap|rustscan|unicornscan|arp-scan',
     ["T1046"], "Network port/host scanning tool"),
    (r'netstat\s+-|ss\s+-tulpn|ss\s+-an|lsof\s+-i|sockstat',
     ["T1046", "T1082"], "Network connection enumeration"),
    (r'ifconfig|ip\s+addr|ip\s+route|route\s+-n|arp\s+-a',
     ["T1082"], "Network interface / route discovery"),
    (r'getent\s+passwd|cat\s+/etc/passwd|id\s*;|who\s*;|w\s*;|last\s',
     ["T1087"], "User account / login history enumeration"),
    (r'ps\s+aux|ps\s+-ef|tasklist|Get-Process|/proc/[0-9]+/comm',
     ["T1057"], "Running process enumeration"),
    (r'uname\s+-a|cat\s+/etc/\*-release|systeminfo|Get-ComputerInfo',
     ["T1082"], "OS/system information discovery"),
    (r'find\s+/\s+-name|locate\s+.*\.(conf|key|pem|pass|cred)',
     ["T1083", "T1083"], "Sensitive file search / discovery"),

    # ── Lateral Movement ──────────────────────────────────────────────────────
    (r'accepted.*publickey|accepted.*from.*internal|ssh.*from.*10\.|ssh.*from.*192\.168\.',
     ["T1021.004"], "SSH lateral movement from internal host"),
    (r'psexec|wmic.*(process|call|exec)|schtasks.*/create.*\\\\\\\\',
     ["T1021", "T1570"], "Remote execution / lateral movement (PsExec/WMI)"),
    (r'net\s+use\s+\\\\|smbclient|mount.*cifs|mount.*smb',
     ["T1021.002"], "SMB share mounting / lateral movement"),
    (r'rdp|mstsc|xfreerdp|remmina.*rdp|3389',
     ["T1021.001"], "Remote Desktop Protocol (RDP) lateral movement"),
    (r'accepted.*from.*\d+\.\d+\.\d+\.\d+.*port\s+22',
     ["T1021.004"], "SSH inbound connection accepted"),

    # ── Collection / Staging ──────────────────────────────────────────────────
    (r'tar\s+.*czf|zip\s+-r|7z\s+a\s+/tmp|rar\s+a\s+/tmp|gzip.*/tmp',
     ["T1560", "T1074"], "Data archiving / staging in temp directory"),
    (r'find.*-name.*\.(docx?|xlsx?|pdf|db|sql|mdb|kdbx|pem|key|p12)',
     ["T1005", "T1213"], "Sensitive document / credential file search"),
    (r'rsync.*(185\.|194\.|91\.)|scp.*@.*185\.|scp.*@.*194\.',
     ["T1074", "T1041"], "Data staging via rsync/scp to external host"),
    (r'sqlite.*select|mysqldump|pg_dump|mongodump',
     ["T1005", "T1213"], "Database content extraction"),

    # ── Command and Control ───────────────────────────────────────────────────
    (r'dns.*query|named.*query|nslookup\s|dig\s+.*\.(ru|cn|ir|kp|pk)|dnscat|iodine',
     ["T1071.004"], "DNS query / possible DNS C2 channel"),
    (r'post\s+.*/\s+(update|sync|ping|beacon|collect|upload)|curl.*-x\s+post|wget.*--post',
     ["T1071.001", "T1041"], "HTTP POST data transmission / C2 beacon"),
    (r'curl\s+.*-s|wget\s+.*-q|curl\s+.*http|wget\s+.*http',
     ["T1071.001"], "HTTP/HTTPS request (possible C2 or download)"),
    (r'connect.*:443|connect.*:8080|connect.*:4444|connect.*:1337',
     ["T1071", "T1573"], "Outbound connection to suspicious port (C2 pattern)"),
    (r'ssh.*-r\s|ssh.*-l\s.*tunnel|autossh|ssh.*-d\s+\d+',
     ["T1021.004", "T1572"], "SSH port forwarding / tunnel (C2 evasion)"),

    # ── Exfiltration ──────────────────────────────────────────────────────────
    (r'curl.*post.*http.*upload|wget.*post.*http|curl.*-f\s|curl.*-T\s',
     ["T1041", "T1567"], "HTTP-based data upload / exfiltration"),
    (r'ftp.*put|lftp.*put|ncftp.*put|sftp.*put',
     ["T1048"], "FTP-based data exfiltration"),
    (r'bytes.*out|sent\s+\d{5,}|transferred.*\d{5,}|data.*\d{5,}.*bytes',
     ["T1041"], "Large data volume transmission (possible exfiltration)"),
    (r'pastebin|paste\.ee|hastebin|ghostbin|termbin',
     ["T1567"], "Data exfiltration via paste service"),

    # ── Impact ────────────────────────────────────────────────────────────────
    (r'encrypted|\.encrypted|\.locked|\.ransom|readme.*ransom|decrypt.*instruction',
     ["T1486"], "Ransomware encryption / ransom note detected"),
    (r'dd\s+if=|wipe\s+|shred\s+-u|rm\s+-rf\s+/|mkfs\.',
     ["T1485"], "Data destruction / disk wipe command"),
    (r'vssadmin.*delete|bcdedit.*recoveryenabled.*no|wbadmin.*delete',
     ["T1490"], "Shadow copy / backup deletion (ransomware preparation)"),
    (r'iptables.*drop\s*$|iptables.*reject|route.*blackhole|null.route',
     ["T1499"], "Network DoS / traffic blocking"),

    # ── Attack tooling catch-all ──────────────────────────────────────────────
    (r'metasploit|msfconsole|msfvenom|cobaltstrike|cobalt strike|beacon\.dll',
     ["T1190", "T1059"], "Known offensive framework / C2 tool detected"),
    (r'hydra\s+|medusa\s+|john\s+--wordlist|hashcat\s+|aircrack',
     ["T1110"], "Password cracking / attack tool detected"),
    (r'burpsuite|burp\s+proxy|zaproxy|zap\s+proxy',
     ["T1190"], "Web proxy / intercept tool detected"),
]

# ── APK Permission → ATT&CK Mobile Technique Map ─────────────────────────────
APK_PERMISSION_MAP = {
    "READ_SMS":              ["T1412"],
    "RECEIVE_SMS":           ["T1412"],
    "SEND_SMS":              ["T1412"],
    "READ_CONTACTS":         ["T1432"],
    "RECORD_AUDIO":          ["T1429"],
    "CAMERA":                ["T1512"],
    "ACCESS_FINE_LOCATION":  ["T1430"],
    "ACCESS_COARSE_LOCATION":["T1430"],
    "READ_CALL_LOG":         ["T1432"],
    "PROCESS_OUTGOING_CALLS":["T1412"],
    "BIND_ACCESSIBILITY_SERVICE": ["T1411"],
    "SYSTEM_ALERT_WINDOW":   ["T1411"],
    "READ_CLIPBOARD":        ["T1414"],
    "WRITE_CLIPBOARD":       ["T1414"],
    "RECEIVE_BOOT_COMPLETED":["T1547"],
    "FOREGROUND_SERVICE":    ["T1508"],
    "HIDE_OVERLAY_WINDOWS":  ["T1411", "T1508"],
}

# ── APT Next-Stage Chain (tactic → likely next tactics) ──────────────────────
NEXT_TACTIC_CHAIN = {
    "Initial Access":      ["Execution", "Persistence", "Discovery"],
    "Execution":           ["Persistence", "Privilege Escalation", "Defense Evasion"],
    "Persistence":         ["Privilege Escalation", "Defense Evasion", "Discovery"],
    "Privilege Escalation":["Defense Evasion", "Credential Access", "Lateral Movement"],
    "Defense Evasion":     ["Credential Access", "Discovery", "Lateral Movement"],
    "Credential Access":   ["Discovery", "Lateral Movement", "Collection"],
    "Discovery":           ["Lateral Movement", "Collection", "Command and Control"],
    "Lateral Movement":    ["Collection", "Command and Control", "Exfiltration"],
    "Collection":          ["Command and Control", "Exfiltration"],
    "Command and Control": ["Exfiltration", "Impact"],
    "Exfiltration":        ["Impact"],
    "Impact":              [],
}

# Defensive recommendation per tactic
TACTIC_DEFENSES = {
    "Initial Access":       ["Enable MFA on all external services", "Deploy email filtering with sandboxing", "Patch all public-facing services immediately"],
    "Execution":            ["Restrict PowerShell execution policy", "Deploy application whitelisting (AppLocker)", "Monitor /tmp execution"],
    "Persistence":          ["Audit scheduled tasks and cron jobs", "Monitor new service creation", "Review autoruns with Sysinternals"],
    "Privilege Escalation": ["Enforce least-privilege principle", "Audit sudo rules", "Deploy PAM monitoring"],
    "Defense Evasion":      ["Enable audit logging for log deletion events", "Monitor firewall rule changes", "Hash-verify critical binaries"],
    "Credential Access":    ["Deploy LAPS for local admin passwords", "Enable Credential Guard", "Alert on /etc/shadow access"],
    "Discovery":            ["Alert on excessive enumeration commands", "Network segmentation to limit discovery scope", "Honeypot accounts"],
    "Lateral Movement":     ["Network micro-segmentation", "Privileged Access Workstations (PAWs)", "Monitor SMB and RDP anomalies"],
    "Collection":           ["DLP on sensitive file access patterns", "Monitor archive creation in temp dirs", "Alert on bulk file reads"],
    "Command and Control":  ["DNS filtering and DoH inspection", "Proxy with TLS inspection", "Beacon detection (JA3 hashing)"],
    "Exfiltration":         ["DLP on large outbound transfers", "Block direct internet from servers", "Alert on off-hours data movement"],
    "Impact":               ["Immutable backups (3-2-1 rule)", "Disable Volume Shadow Copy protections", "Ransomware honeypot files"],
}


class MITREMapper:
    """
    Maps log events and APK indicators to MITRE ATT&CK techniques.
    Generates heatmaps, predicts next attacker steps, and recommends defenses.
    """

    def map_logs(self, log_text: str, existing_findings: list = None) -> dict:
        """Primary method: map log content to ATT&CK techniques."""
        lines = log_text.splitlines()
        matched_techniques: dict[str, dict] = {}
        evidence_trail: list[dict] = []

        for i, line in enumerate(lines):
            line_lower = line.lower()
            line_matched_tids = set()  # avoid duplicate technique hits for same line
            for pattern, tech_ids, description in LOG_PATTERN_MAP:
                if re.search(pattern, line_lower):
                    for tid in tech_ids:
                        if tid in line_matched_tids:
                            continue  # don't double-count same technique from same line
                        line_matched_tids.add(tid)
                        if tid not in matched_techniques:
                            tech = TECHNIQUE_DB.get(tid, {})
                            matched_techniques[tid] = {
                                "technique_id":   tid,
                                "technique_name": tech.get("name", "Unknown"),
                                "tactic":         tech.get("tactic", "Unknown"),
                                "severity":       tech.get("severity", "MEDIUM"),
                                "hit_count":      0,
                                "evidence":       [],
                                "first_seen":     None,
                                "last_seen":      None,
                            }
                        matched_techniques[tid]["hit_count"] += 1
                        evidence_trail.append({
                            "line_no":     i + 1,
                            "technique":   tid,
                            "description": description,
                            "log_excerpt": line[:120],
                        })
                        if len(matched_techniques[tid]["evidence"]) < 3:
                            matched_techniques[tid]["evidence"].append(line[:120])
                    # No break — allow multiple patterns to match per line

        # Build tactic summary
        tactic_map: dict[str, list] = {}
        for tid, tech in matched_techniques.items():
            tactic = tech["tactic"]
            tactic_map.setdefault(tactic, []).append(tid)

        # Predict next steps
        active_tactics = list(tactic_map.keys())
        next_predicted  = self._predict_next(active_tactics)
        defenses        = self._recommend_defenses(active_tactics)

        return {
            "matched_techniques": list(matched_techniques.values()),
            "tactic_coverage":    tactic_map,
            "technique_count":    len(matched_techniques),
            "evidence_trail":     evidence_trail[:50],
            "attack_progression": self._build_kill_chain(tactic_map),
            "predicted_next_tactics": next_predicted,
            "defensive_priorities":   defenses,
            "navigator_heatmap":      self._build_navigator_data(matched_techniques),
            "highest_severity":       self._max_severity(matched_techniques),
        }

    def map_apk(self, permissions: list, strings_data: dict = None,
                static_data: dict = None) -> dict:
        """Map APK indicators to ATT&CK Mobile techniques."""
        matched_techniques: dict[str, dict] = {}

        # Map permissions
        for perm in permissions:
            perm_short = perm.replace("android.permission.", "").upper()
            for key, tech_ids in APK_PERMISSION_MAP.items():
                if key in perm_short:
                    for tid in tech_ids:
                        if tid not in matched_techniques:
                            tech = TECHNIQUE_DB.get(tid, {})
                            matched_techniques[tid] = {
                                "technique_id":   tid,
                                "technique_name": tech.get("name", "Unknown"),
                                "tactic":         tech.get("tactic", "Unknown"),
                                "severity":       tech.get("severity", "MEDIUM"),
                                "evidence":       [f"Permission: {perm}"],
                                "hit_count":      0,
                            }
                        matched_techniques[tid]["hit_count"] += 1
                        if len(matched_techniques[tid]["evidence"]) < 5:
                            matched_techniques[tid]["evidence"].append(f"Permission: {perm}")

        # Map obfuscation / anti-analysis
        if static_data:
            if static_data.get("vulnerabilities", {}).get("obfuscation_detected"):
                t = "T1406"
                if t not in matched_techniques:
                    tech = TECHNIQUE_DB.get(t, {})
                    matched_techniques[t] = {
                        "technique_id": t, "technique_name": tech.get("name",""),
                        "tactic": tech.get("tactic",""), "severity": "MEDIUM",
                        "evidence": ["Code obfuscation detected in DEX"], "hit_count": 1,
                    }

        tactic_map: dict[str, list] = {}
        for tid, tech in matched_techniques.items():
            tactic_map.setdefault(tech["tactic"], []).append(tid)

        return {
            "matched_techniques":     list(matched_techniques.values()),
            "tactic_coverage":        tactic_map,
            "technique_count":        len(matched_techniques),
            "navigator_heatmap":      self._build_navigator_data(matched_techniques),
            "highest_severity":       self._max_severity(matched_techniques),
            "predicted_next_tactics": self._predict_next(list(tactic_map.keys())),
            "defensive_priorities":   self._recommend_defenses(list(tactic_map.keys())),
        }

    def _predict_next(self, active_tactics: list) -> list:
        """Predict the attacker's next likely tactics based on kill chain."""
        next_tactics: set = set()
        for tactic in active_tactics:
            for nxt in NEXT_TACTIC_CHAIN.get(tactic, []):
                if nxt not in active_tactics:
                    next_tactics.add(nxt)
        return list(next_tactics)[:4]

    def _recommend_defenses(self, active_tactics: list) -> list:
        """Return prioritised defensive actions for active tactics."""
        defenses = []
        seen = set()
        priority_order = ["Credential Access","Privilege Escalation","Exfiltration",
                          "Lateral Movement","Initial Access","Execution","Impact"]
        sorted_tactics = sorted(active_tactics,
                                key=lambda t: priority_order.index(t)
                                if t in priority_order else 99)
        for tactic in sorted_tactics[:4]:
            for rec in TACTIC_DEFENSES.get(tactic, []):
                if rec not in seen:
                    seen.add(rec)
                    defenses.append({"tactic": tactic, "action": rec})
        return defenses[:8]

    def _build_kill_chain(self, tactic_map: dict) -> list:
        """Order detected tactics by ATT&CK kill chain progression."""
        chain_order = [
            "Initial Access","Execution","Persistence","Privilege Escalation",
            "Defense Evasion","Credential Access","Discovery","Lateral Movement",
            "Collection","Command and Control","Exfiltration","Impact"
        ]
        return [t for t in chain_order if t in tactic_map]

    def _build_navigator_data(self, techniques: dict) -> list:
        """Build ATT&CK Navigator-compatible layer data."""
        return [
            {
                "techniqueID": tid,
                "score": min(tech["hit_count"] * 20, 100),
                "color": ("#ff4444" if tech["severity"] == "CRITICAL" else
                          "#ff8800" if tech["severity"] == "HIGH" else
                          "#ffcc00" if tech["severity"] == "MEDIUM" else "#44aaff"),
                "comment": tech["technique_name"],
                "enabled": True,
            }
            for tid, tech in techniques.items()
        ]

    def _max_severity(self, techniques: dict) -> str:
        order = ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
        for sev in order:
            if any(t["severity"] == sev for t in techniques.values()):
                return sev
        return "LOW"

    def get_technique(self, technique_id: str) -> dict:
        """Look up a technique by ID."""
        return TECHNIQUE_DB.get(technique_id, {})

    def get_all_tactics(self) -> list:
        tactics = []
        seen = set()
        chain_order = [
            "Initial Access","Execution","Persistence","Privilege Escalation",
            "Defense Evasion","Credential Access","Discovery","Lateral Movement",
            "Collection","Command and Control","Exfiltration","Impact"
        ]
        for t in chain_order:
            if t not in seen:
                tactics.append(t)
                seen.add(t)
        return tactics
