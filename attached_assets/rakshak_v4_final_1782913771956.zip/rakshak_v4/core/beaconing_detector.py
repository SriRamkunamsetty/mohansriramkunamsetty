"""
RAKSHAK — C2 Beaconing Detector
Statistical analysis of connection intervals to detect malware heartbeats.
Fourier-transform inspired periodicity detection — catches APT C2 channels
invisible to signature-based tools.
"""

import re, math, statistics
from collections import defaultdict
from datetime import datetime
from typing import Optional


# ── Tuning ────────────────────────────────────────────────────────────────────
MIN_BEACON_EVENTS     = 5        # Need at least 5 events to be statistical
MAX_JITTER_PERCENT    = 15       # Beacons allow ≤15% timing jitter
BEACON_INTERVAL_RANGE = (10, 86400)  # 10 sec to 24 hours
SUSPICIOUS_USER_AGENTS = [
    "curl", "wget", "python-requests", "go-http-client",
    "libwww-perl", "okhttp", "java/", "zgrab", "masscan",
]

# ── Log patterns for web/proxy/firewall logs ──────────────────────────────────
PROXY_PAT = re.compile(
    r'(?P<ts>[\d\-/:T.+ ]+?)\s+'
    r'(?:(?P<client>[\d.]+)\s+)?'
    r'(?:GET|POST|PUT|HEAD|CONNECT)\s+'
    r'(?P<url>https?://[^\s]+|[^\s]+)\s+'
    r'(?:HTTP/[\d.]+\s+)?(?P<status>\d{3})?'
    r'(?:.*?(?P<bytes>\d+))?',
    re.IGNORECASE
)
FIREWALL_CONN_PAT = re.compile(
    r'(?P<ts>[\d\-/: ]+)\s+.*?'
    r'(?:SRC|src|source)=(?P<src>[\d.]+).*?'
    r'(?:DST|dst|dest)=(?P<dst>[\d.]+).*?'
    r'(?:DPT|dpt|dport)=(?P<port>\d+)',
    re.IGNORECASE
)
NETSTAT_PAT = re.compile(
    r'(?P<ts>[\d\-T:.]+).*?ESTABLISHED.*?'
    r'(?P<src>[\d.]+):(?P<sport>\d+).*?'
    r'(?P<dst>[\d.]+):(?P<dport>\d+)',
    re.IGNORECASE
)


class BeaconingDetector:
    """
    RAKSHAK Beaconing Detector
    Applies periodicity analysis to outbound connection logs.
    A C2 beacon calls home every N seconds ± small jitter.
    We detect that rhythm even when the individual connections look innocent.
    """

    def analyze(self, log_text: str) -> dict:
        lines       = log_text.splitlines()
        connections = self._parse_connections(lines)

        if len(connections) < MIN_BEACON_EVENTS:
            return {
                "beacons_detected": [],
                "beacon_risk_score": 0,
                "beacon_findings"  : [],
                "total_connections": len(connections),
                "note": "Insufficient connection data for statistical analysis",
            }

        # Group by destination
        by_dest = defaultdict(list)
        for conn in connections:
            if conn["ts"]:
                by_dest[conn["dst"]].append(conn)

        beacons  = []
        for dst, events in by_dest.items():
            beacon = self._analyze_periodicity(dst, events)
            if beacon:
                beacons.append(beacon)

        # Sort by confidence
        beacons.sort(key=lambda b: b["confidence"], reverse=True)

        risk_score = 0
        for b in beacons:
            if b["confidence"] >= 90:
                risk_score += 35
            elif b["confidence"] >= 75:
                risk_score += 20
            else:
                risk_score += 10
        risk_score = min(risk_score, 100)

        return {
            "beacons_detected" : beacons[:10],
            "beacon_risk_score": risk_score,
            "total_connections": len(connections),
            "unique_dests"     : len(by_dest),
            "beacon_findings"  : self._build_findings(beacons),
        }

    def _parse_connections(self, lines: list) -> list:
        connections = []
        for line in lines:
            # Try proxy log
            m = PROXY_PAT.search(line)
            if m:
                ts  = self._parse_ts(m.group("ts"))
                url = m.group("url") or ""
                dst = re.search(r'https?://([^/:\s]+)', url)
                connections.append({
                    "ts"  : ts,
                    "dst" : dst.group(1) if dst else url[:40],
                    "src" : m.group("client") or "",
                    "raw" : line[:100],
                })
                continue

            # Try firewall connection log
            m = FIREWALL_CONN_PAT.search(line)
            if m:
                connections.append({
                    "ts"  : self._parse_ts(m.group("ts")),
                    "src" : m.group("src"),
                    "dst" : f"{m.group('dst')}:{m.group('port')}",
                    "raw" : line[:100],
                })
                continue

            # Try netstat-style
            m = NETSTAT_PAT.search(line)
            if m:
                dst_ip = m.group("dst")
                # Skip private IPs (internal traffic)
                if not dst_ip.startswith(("10.", "192.168.", "172.")):
                    connections.append({
                        "ts"  : self._parse_ts(m.group("ts")),
                        "src" : m.group("src"),
                        "dst" : f"{dst_ip}:{m.group('dport')}",
                        "raw" : line[:100],
                    })

        return [c for c in connections if c["ts"] is not None]

    def _analyze_periodicity(self, dst: str, events: list) -> Optional[dict]:
        """
        Core periodicity algorithm:
        1. Sort events by timestamp
        2. Compute inter-arrival intervals
        3. Calculate mean and coefficient of variation (CV)
        4. Low CV = regular intervals = beaconing
        5. Estimate confidence from CV and event count
        """
        if len(events) < MIN_BEACON_EVENTS:
            return None

        events.sort(key=lambda e: e["ts"])
        timestamps = [e["ts"].timestamp() for e in events]
        intervals  = [timestamps[i+1] - timestamps[i]
                      for i in range(len(timestamps) - 1)]

        if not intervals:
            return None

        # Filter out huge gaps (> 1 hour) which break periodicity analysis
        intervals = [iv for iv in intervals if iv < 3600]
        if len(intervals) < MIN_BEACON_EVENTS - 1:
            return None

        mean_iv = statistics.mean(intervals)
        if not (BEACON_INTERVAL_RANGE[0] <= mean_iv <= BEACON_INTERVAL_RANGE[1]):
            return None

        try:
            stdev_iv = statistics.stdev(intervals) if len(intervals) > 1 else 0
        except statistics.StatisticsError:
            stdev_iv = 0

        # Coefficient of Variation: lower = more regular = more suspicious
        cv = (stdev_iv / mean_iv * 100) if mean_iv > 0 else 100

        if cv > MAX_JITTER_PERCENT:
            return None  # Too irregular to be a beacon

        # Confidence score (higher regularity = higher confidence)
        confidence = max(0, min(100, int(100 - cv * 4 + min(len(events) * 2, 20))))

        # Format interval nicely
        if mean_iv < 60:
            interval_str = f"{mean_iv:.1f} seconds"
        elif mean_iv < 3600:
            interval_str = f"{mean_iv/60:.1f} minutes"
        else:
            interval_str = f"{mean_iv/3600:.1f} hours"

        severity = "CRITICAL" if confidence >= 90 else "HIGH" if confidence >= 75 else "MEDIUM"

        return {
            "destination"    : dst,
            "event_count"    : len(events),
            "interval"       : round(mean_iv, 2),
            "interval_str"   : interval_str,
            "jitter_percent" : round(cv, 2),
            "confidence"     : confidence,
            "severity"       : severity,
            "first_seen"     : events[0]["ts"].isoformat(),
            "last_seen"      : events[-1]["ts"].isoformat(),
            "description"    : (
                f"BEACON DETECTED → {dst}\n"
                f"  Interval: {interval_str} ± {cv:.1f}% jitter\n"
                f"  Events: {len(events)} calls over "
                f"{(events[-1]['ts'] - events[0]['ts']).total_seconds()/3600:.1f}h\n"
                f"  Confidence: {confidence}% — {severity}"
            ),
            "mitre"          : "T1071 — Application Layer Protocol (C2 Beaconing)",
            "action"         : (
                f"Block {dst} immediately + analyse all data sent/received + "
                "check for malware on source host + isolate from network"
            ),
        }

    def _parse_ts(self, ts_str: str) -> Optional[datetime]:
        if not ts_str:
            return None
        ts_str = ts_str.strip()
        for fmt in [
            "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M:%S.%f", "%d/%b/%Y:%H:%M:%S %z",
            "%d/%b/%Y:%H:%M:%S", "%Y/%m/%d %H:%M:%S",
            "%b %d %H:%M:%S",
        ]:
            try:
                dt = datetime.strptime(ts_str[:len(fmt)+4].strip(), fmt)
                return dt.replace(tzinfo=None)
            except ValueError:
                continue
        # Try epoch
        try:
            return datetime.fromtimestamp(float(ts_str))
        except (ValueError, OSError):
            return None

    def _build_findings(self, beacons: list) -> list:
        if not beacons:
            return []
        critical = [b for b in beacons if b["severity"] == "CRITICAL"]
        high     = [b for b in beacons if b["severity"] == "HIGH"]

        findings = []
        if critical:
            findings.append({
                "severity"   : "CRITICAL",
                "category"   : "C2 Beaconing",
                "description": (
                    f"{len(critical)} CRITICAL beacon(s) detected with >90% confidence. "
                    f"Malware is actively communicating with command-and-control servers. "
                    f"Top: {critical[0]['destination']} every {critical[0]['interval_str']}"
                ),
                "action"     : "IMMEDIATE network isolation + malware removal + IR team activation",
            })
        if high:
            findings.append({
                "severity"   : "HIGH",
                "category"   : "Suspicious Periodic Connections",
                "description": f"{len(high)} high-confidence periodic connection pattern(s) — "
                               f"possible C2 beaconing",
                "action"     : "Investigate destination IPs + capture traffic for analysis",
            })
        return findings
