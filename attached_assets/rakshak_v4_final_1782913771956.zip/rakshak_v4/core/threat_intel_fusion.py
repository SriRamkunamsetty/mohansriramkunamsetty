"""
RAKSHAK — Threat Intelligence Fusion Engine
APT playbook matching · Multi-feed IOC correlation · Dark web credential check
Identifies WHICH threat actor is attacking and WHAT they will do next
"""

import re, hashlib
from collections import defaultdict


# ── APT Playbook Library ──────────────────────────────────────────────────────
# Each playbook is a sequence of TTPs that characterise a known APT group.
# When RAKSHAK observes the same TTP sequence, it matches the actor.
APT_PLAYBOOKS = {
    "APT36 / Transparent Tribe (Pakistan)": {
        "aliases"     : ["Transparent Tribe", "PROJECTM", "C-Major", "Operation Sharpshooter"],
        "targets"     : ["DRDO", "Indian Army", "IAF", "MHA", "MEA", "Indian Universities"],
        "country"     : "Pakistan",
        "confidence"  : 0,
        "ttp_sequence": [
            "spear-phishing",
            "malicious-document",
            "powershell-execution",
            "credential-dumping",
            "ssh-from-pakistan-ip",
            "dns-tunneling",
            "data-staged",
            "scp-exfiltration",
            "log-deletion",
        ],
        "signature_ips": [
            "103.59.144.", "103.59.145.", "103.255.6.", "182.176.",
            "223.29.192.", "45.32.", "45.33.",
        ],
        "signature_domains": [
            "crm.gov-pk.org", "mfa-gov.org", "military-drive.com",
            "drdo-india.org",  "nic-gov.in.com",
        ],
        "mitre_techniques": ["T1566", "T1059", "T1003", "T1071.004", "T1074", "T1041"],
        "drdo_risk"   : "EXTREME — Primary threat to DRDO networks",
    },

    "SideWinder / APT-C-17 (South Asia)": {
        "aliases"     : ["RattleSnake", "T-APT-04", "APT-C-17"],
        "targets"     : ["Pakistani Military", "Sri Lanka", "Bangladesh", "Maldives"],
        "country"     : "India (disputed)",
        "confidence"  : 0,
        "ttp_sequence": [
            "spear-phishing",
            "rtf-exploit",
            "powershell-execution",
            "privilege-escalation",
            "registry-persistence",
            "https-c2",
        ],
        "signature_domains": ["govpk.org", "mil-pk.net"],
        "mitre_techniques" : ["T1566", "T1059.001", "T1078", "T1547"],
        "drdo_risk"        : "HIGH — Counterintelligence interest",
    },

    "Lazarus Group / APT38 (North Korea)": {
        "aliases"     : ["Hidden Cobra", "Guardians of Peace", "APT38"],
        "targets"     : ["Banks", "Crypto", "Defence contractors", "SWIFT network"],
        "country"     : "North Korea",
        "confidence"  : 0,
        "ttp_sequence": [
            "spear-phishing",
            "powershell-execution",
            "living-off-the-land",
            "lateral-movement-smb",
            "credential-dumping",
            "data-staged",
            "ftp-exfiltration",
        ],
        "signature_domains": ["star-power.net", "celasllc.com"],
        "mitre_techniques" : ["T1566", "T1059", "T1570", "T1003", "T1048"],
        "drdo_risk"        : "HIGH — Defence procurement targeting",
    },

    "Volt Typhoon (China / Critical Infrastructure)": {
        "aliases"     : ["Bronze Silhouette", "Vanguard Panda"],
        "targets"     : ["Critical infrastructure", "Power grids", "Telecom", "Military"],
        "country"     : "China",
        "confidence"  : 0,
        "ttp_sequence": [
            "living-off-the-land",
            "netsh-tunnel",
            "wmic-execution",
            "credential-dumping",
            "dns-tunneling",
            "slow-exfiltration",
        ],
        "mitre_techniques" : ["T1218", "T1003", "T1071.004", "T1048.003"],
        "drdo_risk"        : "HIGH — Critical infrastructure targeting",
    },
}

# ── TTP keyword → playbook stage mapping ─────────────────────────────────────
TTP_KEYWORDS = {
    "spear-phishing"       : [r'phishing', r'malicious.*email', r'attachment.*opened'],
    "malicious-document"   : [r'\.docm|\.xlsm|\.rtf.*exec', r'macro.*enabled'],
    "powershell-execution" : [r'powershell|pwsh|\-enc\s', r'cmd\.exe.*-c\s'],
    "credential-dumping"   : [r'lsass|mimikatz|sekurlsa|hashdump|ntds\.dit'],
    "dns-tunneling"        : [r'dns.*tunnel|iodine|dnscat|high.*entropy.*subdomain'],
    "ssh-from-pakistan-ip" : [r'(?:103\.59\.|182\.176\.|45\.33\.).*ssh'],
    "data-staged"          : [r'tar.*(?:/home|/etc|/var)|archive.*created|zip.*sensitive'],
    "scp-exfiltration"     : [r'scp\s.*\d+\.\d+\.\d+\.\d+', r'sftp.*external'],
    "log-deletion"         : [r'history\s+-c|rm.*\.log|shred|truncate.*log'],
    "rtf-exploit"          : [r'\.rtf.*execution|rtf.*exploit'],
    "privilege-escalation" : [r'sudo\s+su|chmod\s+777|setuid|suid.*exploit'],
    "registry-persistence" : [r'reg\s+add|HKCU.*run|registry.*persistence'],
    "https-c2"             : [r'HTTPS.*beacon|POST.*[/]{2,}', r'ssl.*c2|encrypted.*callback'],
    "living-off-the-land"  : [r'wmic|netsh|mshta|regsvr32|rundll32|certutil'],
    "lateral-movement-smb" : [r'smb.*\d+\.\d+|psexec|wmiexec|pass-the-hash'],
    "ftp-exfiltration"     : [r'ftp.*external|\bftp\b.*\d+\.\d+'],
    "netsh-tunnel"         : [r'netsh.*portproxy|netsh.*interface'],
    "wmic-execution"       : [r'wmic\s+.*process\s+call\s+create'],
    "slow-exfiltration"    : [r'very\s+slow.*transfer|\bthrottle\b.*transfer'],
}

# ── Known malicious IP ranges for attribution ─────────────────────────────────
KNOWN_THREAT_ACTOR_RANGES = {
    "APT36 / Transparent Tribe (Pakistan)": [
        "103.59.144", "103.59.145", "103.255.6", "182.176",
        "223.29.192", "45.32",
    ],
    "Lazarus Group / APT38 (North Korea)": [
        "175.45.176", "175.45.177", "175.45.178", "175.45.179",
    ],
    "Volt Typhoon (China / Critical Infrastructure)": [
        "58.246", "61.152", "103.235",
    ],
}

# ── IOC threat feeds (simulated — in production, query live MISP/OTX APIs) ────
KNOWN_MALICIOUS_IOC_PATTERNS = [
    (r'185\.220\.\d+\.\d+',     "Tor exit node — anonymised attack traffic"),
    (r'195\.123\.\d+\.\d+',     "Known bulletproof hosting — cybercrime infrastructure"),
    (r'91\.108\.\d+\.\d+',      "Telegram API range — C2 via Telegram bot"),
    (r'103\.59\.14[4-9]\.',      "APT36 known infrastructure (CERT-In advisory)"),
    (r'(?:ngrok\.io|serveo\.net|localhost\.run)', "Tunnel relay — evasion of egress filtering"),
    (r'bit\.ly|tinyurl\.com|t\.co', "URL shortener — phishing delivery"),
    (r'pastebin\.com|hastebin', "Paste site — configuration delivery for malware"),
]


class ThreatIntelFusion:
    """
    RAKSHAK Threat Intelligence Fusion
    Correlates observed evidence against APT playbooks and IOC feeds.
    Answers: WHO is attacking and what will they do NEXT?
    """

    def analyze(self, log_text: str, iocs: list = None) -> dict:
        iocs   = iocs or []
        lines  = log_text.splitlines()
        text   = log_text.lower()

        matched_ttps      = self._match_ttps(text)
        apt_matches       = self._match_apt_playbooks(matched_ttps, lines, iocs)
        ioc_hits          = self._correlate_iocs(lines, iocs)
        dark_web_hits     = self._check_dark_web(lines)
        next_step_predict = self._predict_next_step(apt_matches, matched_ttps)

        result = {
            "matched_ttps"          : matched_ttps,
            "apt_attribution"       : apt_matches,
            "ioc_correlation"       : ioc_hits,
            "dark_web_credentials"  : dark_web_hits,
            "predicted_next_steps"  : next_step_predict,
            "ti_risk_score"         : 0,
            "ti_findings"           : [],
        }

        score = 0
        score += min(len(apt_matches) * 30, 50)
        score += min(len(ioc_hits)    * 10, 30)
        score += 25 if dark_web_hits  else 0
        score += min(len(matched_ttps)* 5,  20)
        result["ti_risk_score"] = min(score, 100)
        result["ti_findings"]   = self._build_findings(result)
        return result

    def _match_ttps(self, text: str) -> list:
        matched = []
        for ttp, patterns in TTP_KEYWORDS.items():
            for pattern in patterns:
                if re.search(pattern, text, re.IGNORECASE):
                    matched.append(ttp)
                    break
        return matched

    def _match_apt_playbooks(self, observed_ttps: list, lines: list, iocs: list) -> list:
        matches = []
        full_text = " ".join(lines).lower()

        for apt_name, playbook in APT_PLAYBOOKS.items():
            score = 0
            reasons = []

            # TTP sequence matching
            matched_ttps = [t for t in playbook["ttp_sequence"] if t in observed_ttps]
            if matched_ttps:
                coverage = len(matched_ttps) / len(playbook["ttp_sequence"])
                score   += int(coverage * 60)
                reasons.append(
                    f"{len(matched_ttps)}/{len(playbook['ttp_sequence'])} TTPs matched: "
                    f"{', '.join(matched_ttps[:4])}"
                )

            # Signature IP ranges
            for ip_range in playbook.get("signature_ips", []):
                if ip_range in full_text:
                    score += 25
                    reasons.append(f"Signature IP range: {ip_range}*")
                    break

            # Signature domains
            for domain in playbook.get("signature_domains", []):
                if domain.lower() in full_text:
                    score += 30
                    reasons.append(f"Signature domain: {domain}")
                    break

            # IOC matching
            for ioc in iocs:
                for actor_range in KNOWN_THREAT_ACTOR_RANGES.get(apt_name, []):
                    if actor_range in str(ioc):
                        score += 20
                        reasons.append(f"IOC matches known {apt_name} infrastructure")
                        break

            if score >= 25:
                confidence = min(score, 99)
                matches.append({
                    "apt_name"     : apt_name,
                    "confidence"   : confidence,
                    "reasons"      : reasons,
                    "drdo_risk"    : playbook.get("drdo_risk", "UNKNOWN"),
                    "mitre"        : playbook.get("mitre_techniques", []),
                    "next_ttps"    : [t for t in playbook["ttp_sequence"]
                                      if t not in observed_ttps][:3],
                    "severity"     : "CRITICAL" if confidence >= 70 else "HIGH",
                })

        return sorted(matches, key=lambda m: m["confidence"], reverse=True)

    def _correlate_iocs(self, lines: list, extracted_iocs: list) -> list:
        hits = []
        all_text = "\n".join(lines)

        for pattern, description in KNOWN_MALICIOUS_IOC_PATTERNS:
            m = re.search(pattern, all_text, re.IGNORECASE)
            if m:
                hits.append({
                    "ioc"        : m.group(0),
                    "feed"       : "RAKSHAK Threat Intel Feed v2026.06",
                    "description": description,
                    "severity"   : "HIGH",
                    "matched_in" : "log content",
                })

        # Check user-supplied IOCs against known threat actor infra
        for ioc in extracted_iocs:
            ioc_str = str(ioc)
            for actor, ranges in KNOWN_THREAT_ACTOR_RANGES.items():
                for r in ranges:
                    if r in ioc_str:
                        hits.append({
                            "ioc"        : ioc_str,
                            "feed"       : "RAKSHAK APT Infrastructure DB",
                            "description": f"Known {actor} infrastructure",
                            "severity"   : "CRITICAL",
                        })

        return hits[:20]

    def _check_dark_web(self, lines: list) -> list:
        """
        Simulate dark web credential check.
        In production: query HaveIBeenPwned API + DeHashed API.
        """
        hits       = []
        users_seen = set()

        # Known breached credential patterns (simulation)
        BREACH_SIGNALS = [
            (r'drdo[\._\-]?\w+', "DRDO credential pattern — check against breach databases"),
            (r'admin@|root@|sysadmin@', "Privileged account — frequently in breach databases"),
            (r'password(?:123|@123|_123|2023|2024|2025|!)', "Common weak password pattern detected"),
        ]

        for line in lines:
            for pattern, note in BREACH_SIGNALS:
                m = re.search(pattern, line, re.IGNORECASE)
                if m and m.group(0) not in users_seen:
                    users_seen.add(m.group(0))
                    # Hash for privacy
                    hashed = hashlib.sha256(m.group(0).encode()).hexdigest()[:16]
                    hits.append({
                        "credential_hint": m.group(0)[:20] + "***",
                        "sha256_prefix"  : hashed,
                        "note"           : note,
                        "action"         : "Verify against HaveIBeenPwned API + DeHashed",
                        "severity"       : "HIGH",
                    })
        return hits[:5]

    def _predict_next_step(self, apt_matches: list, observed_ttps: list) -> list:
        if not apt_matches:
            return []
        top_apt    = apt_matches[0]
        next_ttps  = top_apt.get("next_ttps", [])
        predictions = []
        for ttp in next_ttps:
            predictions.append({
                "predicted_ttp" : ttp,
                "apt"           : top_apt["apt_name"],
                "probability"   : f"{top_apt['confidence'] - 10}%",
                "defend_now"    : self._get_defence(ttp),
            })
        return predictions

    def _get_defence(self, ttp: str) -> str:
        defences = {
            "credential-dumping" : "Enable Credential Guard + restrict LSASS access",
            "lateral-movement-smb": "Disable SMB v1 + segment network + monitor 445/TCP",
            "data-staged"        : "DLP alerts on archive creation + monitor /tmp",
            "scp-exfiltration"   : "Block outbound 22/TCP to non-approved hosts",
            "log-deletion"       : "Ship logs to remote SIEM immediately (immutable)",
            "dns-tunneling"      : "Deploy DNS firewall + block recursive resolution",
            "persistence"        : "Monitor cron, authorized_keys, systemd units",
        }
        return defences.get(ttp, f"Monitor and block indicators for {ttp}")

    def _build_findings(self, result: dict) -> list:
        findings = []
        if result["apt_attribution"]:
            top = result["apt_attribution"][0]
            findings.append({
                "severity"   : top["severity"],
                "category"   : "APT Attribution",
                "description": (
                    f"Attack matches {top['apt_name']} playbook with "
                    f"{top['confidence']}% confidence. {top['drdo_risk']}. "
                    f"Evidence: {'; '.join(top['reasons'][:2])}"
                ),
                "action"     : (
                    "Alert NTRO + CERT-In + DRDO NOC immediately. "
                    f"Predicted next steps: {', '.join(top.get('next_ttps', []))}"
                ),
            })
        if result["dark_web_credentials"]:
            findings.append({
                "severity"   : "HIGH",
                "category"   : "Compromised Credentials on Dark Web",
                "description": f"{len(result['dark_web_credentials'])} credential(s) "
                               f"may appear in known breach databases",
                "action"     : "Force password reset for all flagged accounts immediately",
            })
        return findings
