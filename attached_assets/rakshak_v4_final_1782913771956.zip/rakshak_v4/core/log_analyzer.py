"""
RAKSHAK — Security Incident Log Analyzer
Multi-format log ingestion · Threat pattern detection · Risk scoring
Supports: auth.log · syslog · Apache/Nginx · Windows Event · Custom
DRDO SOC grade — production ready
"""

import re, json, io, os
from core.ip_intelligence       import IPIntelligenceEngine
from core.session_reconstructor import SessionReconstructor
from core.multi_log_correlator  import MultiLogCorrelator
from core.advanced_log_detector import (
    AttackFingerprintEngine, AnomalyDetector,
    LateralMovementDetector, LogTamperingDetector,
    CredentialStuffingDetector, CampaignTracker
)
# ── Advanced Modules v3.2 ─────────────────────────────────────────────────────
from core.dns_analyzer          import DNSAnalyzer
from core.db_log_analyzer       import DatabaseLogAnalyzer
from core.uba_engine            import UBAEngine
from core.beaconing_detector    import BeaconingDetector
from core.threat_intel_fusion   import ThreatIntelFusion
from core.sigma_generator       import SigmaGenerator
from core.cert_in_reporter      import CERTInReporter, ForensicTimeline
from core.email_log_analyzer    import EmailLogAnalyzer
from core.cloud_trail_analyzer  import CloudTrailAnalyzer
from collections import defaultdict, Counter
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional
from core.event_bus import emit, EventType


# ── Threat detection thresholds ───────────────────────────────────────────────
THRESHOLDS = {
    "brute_force_attempts"   : 5,    # Failed logins from same IP = brute force
    "port_scan_ports"        : 10,   # Distinct ports from same IP = port scan
    "rapid_requests_per_min" : 100,  # HTTP requests/min = DDoS candidate
    "privilege_escalation"   : 1,    # Any sudo failure = alert
    "critical_file_access"   : 1,    # /etc/passwd, /etc/shadow access
}

# ── Log format patterns ───────────────────────────────────────────────────────
LOG_PATTERNS = {
    # SSH / Linux auth.log
    "ssh_failed": re.compile(
        r'(?P<timestamp>\w+\s+\d+\s+[\d:]+).*Failed password for (?:invalid user )?'
        r'(?P<user>\S+) from (?P<ip>[\d.]+) port (?P<port>\d+)'
    ),
    "ssh_accepted": re.compile(
        r'(?P<timestamp>\w+\s+\d+\s+[\d:]+).*Accepted (?:password|publickey) for '
        r'(?P<user>\S+) from (?P<ip>[\d.]+)'
    ),
    "ssh_invalid_user": re.compile(
        r'(?P<timestamp>\w+\s+\d+\s+[\d:]+).*Invalid user (?P<user>\S+) from (?P<ip>[\d.]+)'
    ),
    "sudo_failure": re.compile(
        r'(?P<timestamp>\w+\s+\d+\s+[\d:]+).*sudo.*authentication failure.*user=(?P<user>\S+)'
    ),
    "sudo_success": re.compile(
        r'(?P<timestamp>\w+\s+\d+\s+[\d:]+).*sudo.*(?P<user>\S+).*COMMAND=(?P<cmd>.+)'
    ),

    # Apache / Nginx access log
    "http_request": re.compile(
        r'(?P<ip>[\d.]+).*\[(?P<timestamp>[^\]]+)\] "(?P<method>\w+) (?P<path>[^\s"]+)'
        r'[^"]*" (?P<status>\d+) (?P<bytes>\d+)'
    ),
    "http_error": re.compile(
        r'\[(?P<timestamp>[^\]]+)\] \[error\].*client (?P<ip>[\d.]+).*?(?P<message>.+)'
    ),

    # Windows Event Log (exported text)
    "win_failed_logon": re.compile(
        r'(?P<timestamp>\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}).*'
        r'(?:Logon Failure|Failed logon).*Account Name:\s*(?P<user>\S+).*'
        r'Source Network Address:\s*(?P<ip>[\d.]+)',
        re.DOTALL
    ),

    # Generic failed login
    "generic_failed": re.compile(
        r'(?P<timestamp>[\d\-:T\s]+).*(?:FAILED|failed|FAILURE|failure|invalid|Invalid)'
        r'.*(?:login|password|auth).*?(?P<ip>\d+\.\d+\.\d+\.\d+)?',
        re.IGNORECASE
    ),

    # File access (sensitive)
    "sensitive_file": re.compile(
        r'(?P<timestamp>\w+\s+\d+\s+[\d:]+).*(?P<path>/etc/(?:passwd|shadow|sudoers)|'
        r'/root/\.ssh|/proc/self|/var/log/auth)',
    ),

    # Port scan (firewall / iptables drops)
    "port_drop": re.compile(
        r'(?P<timestamp>\w+\s+\d+\s+[\d:]+).*(?:DROP|REJECT|BLOCK).*'
        r'SRC=(?P<ip>[\d.]+).*DPT=(?P<port>\d+)'
    ),
}

# ── Known malicious IP ranges (simplified) ────────────────────────────────────
KNOWN_MALICIOUS_ASNS = ["AS60068", "AS209588", "AS202425", "AS49581"]


class SecurityLogAnalyzer:
    """
    RAKSHAK Advanced Security Log Analyzer v2
    14 detection modules running in parallel
    """

    def __init__(self, abuseipdb_key: str = "", virustotal_key: str = ""):
        import os
        self.ip_intel    = IPIntelligenceEngine(
            abuseipdb_key  = abuseipdb_key or os.getenv("ABUSEIPDB_API_KEY",""),
            virustotal_key = virustotal_key or os.getenv("VIRUSTOTAL_API_KEY",""),
        )
        self.session_rec   = SessionReconstructor()
        self.correlator    = MultiLogCorrelator()
        self.fingerprint   = AttackFingerprintEngine()
        self.anomaly       = AnomalyDetector()
        self.lateral       = LateralMovementDetector()
        self.tampering     = LogTamperingDetector()
        self.stuffing      = CredentialStuffingDetector()
        self.campaigns     = CampaignTracker()
        # Advanced modules v3.2
        self.dns_analyzer  = DNSAnalyzer()
        self.db_analyzer   = DatabaseLogAnalyzer()
        self.uba_engine    = UBAEngine()
        self.beaconing     = BeaconingDetector()
        self.threat_intel  = ThreatIntelFusion()
        self.sigma_gen     = SigmaGenerator()
        self.cert_in       = CERTInReporter()
        self.forensic_tl   = ForensicTimeline()
        self.email_analyzer= EmailLogAnalyzer()
        self.cloud_analyzer= CloudTrailAnalyzer()

    """
    RAKSHAK Security Incident Log Analyzer
    Parses system logs and produces DRDO-grade threat intelligence report
    """

    def analyze(self, log_content: str, source_name: str = "log",
                case_id: str = "") -> dict:

        lines  = log_content.splitlines()
        result = self._fresh_result(source_name, len(lines))

        # ── Parse every line ────────────────────────────────────────────
        for line_no, line in enumerate(lines, 1):
            self._parse_line(line, result)

        # ── Post-processing analysis ────────────────────────────────────
        result["brute_force"]          = self._detect_brute_force(result)
        result["top_attacking_ips"]    = self._top_attackers(result)
        result["suspicious_accounts"]  = self._suspicious_accounts(result)
        result["attack_timeline"]      = self._build_timeline(result)
        result["port_scan_suspects"]   = self._detect_port_scans(result)
        result["risk_level"]           = self._compute_risk(result)
        result["risk_score"]           = self._compute_risk_score(result)
        result["findings"]             = self._build_findings(result)
        result["recommendations"]      = self._generate_recommendations(result)
        result["executive_summary"]    = self._executive_summary(result)
        result["geographic_origins"]   = self._geolocate_ips(result)

        # ── ADVANCED MODULES ────────────────────────────────────────────
        # 1. IP Intelligence enrichment
        attacking_ips = list({
            b["ip"] for b in result["brute_force"]
        } | {
            p["ip"] for p in result.get("port_scan_suspects",[])
        })
        if attacking_ips:
            result["ip_intelligence"] = self.ip_intel.enrich_batch(
                attacking_ips[:8], delay=0.3
            )
            result["geo_map_data"] = self.ip_intel.build_geo_map_data(
                result["ip_intelligence"]
            )
        else:
            result["ip_intelligence"] = []
            result["geo_map_data"]    = []

        # 2. Attack tool fingerprinting
        result["attack_fingerprint"] = self.fingerprint.fingerprint_all(
            result["raw"]["ip_failed_counts"],
            result["raw"]["failed_logins"],
            result["raw"]["port_drops"],
        )

        # 3. Anomaly detection
        result["anomalies"] = self.anomaly.detect(
            result["raw"]["failed_logins"],
            result["raw"]["successful_logins"],
        )

        # 4. Lateral movement detection
        result["lateral_movement"] = self.lateral.detect(
            log_content,
            result["raw"]["successful_logins"],
        )

        # 5. Log tampering detection
        result["tampering"] = self.tampering.detect(log_content)

        # 6. Credential stuffing detection
        result["credential_stuffing"] = self.stuffing.detect(
            result["raw"]["failed_logins"]
        )

        # 7. Session reconstruction
        result["sessions"] = self.session_rec.reconstruct(
            log_content,
            result["raw"]["successful_logins"],
        )

        # 8. Campaign tracking
        result["campaigns"] = self.campaigns.track(
            [b["ip"] for b in result["brute_force"]],
            result["top_attacking_ips"],
            source_name,
        )

        # 9. Heatmap data (hour-of-day attack frequency)
        result["heatmap_data"] = self._build_heatmap(
            result["raw"]["failed_logins"]
        )

        # ── ADVANCED MODULES v3.2 ──────────────────────────────────────
        # 10. DNS Analysis
        try:
            result["dns_analysis"] = self.dns_analyzer.analyze(log_content)
        except Exception:
            result["dns_analysis"] = {}

        # 11. Database Log Analysis
        try:
            result["db_analysis"] = self.db_analyzer.analyze(log_content)
        except Exception:
            result["db_analysis"] = {}

        # 12. User Behaviour Analytics + Impossible Travel + Insider Threat
        try:
            result["uba_analysis"] = self.uba_engine.analyze(log_content)
        except Exception:
            result["uba_analysis"] = {}

        # 13. C2 Beaconing Detection
        try:
            result["beaconing"] = self.beaconing.analyze(log_content)
        except Exception:
            result["beaconing"] = {}

        # 14. Threat Intelligence Fusion + APT Attribution
        try:
            extracted_iocs = [b["ip"] for b in result.get("brute_force", [])]
            result["threat_intel"] = self.threat_intel.analyze(log_content, extracted_iocs)
        except Exception:
            result["threat_intel"] = {}

        # 15. Email Log Analysis
        try:
            result["email_analysis"] = self.email_analyzer.analyze(log_content)
        except Exception:
            result["email_analysis"] = {}

        # 16. Cloud Trail Analysis
        try:
            result["cloud_analysis"] = self.cloud_analyzer.analyze(log_content)
        except Exception:
            result["cloud_analysis"] = {}

        # 17. Sigma Rule Auto-Generation
        try:
            sigma_input = {
                "brute_force_detected"      : bool(result.get("brute_force")),
                "lateral_movement_detected" : result.get("lateral_movement", {}).get("lateral_movement_detected"),
                "log_tampering_detected"    : result.get("tampering", {}).get("tampering_detected"),
                "dns_tunneling"             : result.get("dns_analysis", {}).get("dns_tunneling"),
                "beacons_detected"          : result.get("beaconing", {}).get("beacons_detected"),
                "sqli_attempts"             : result.get("db_analysis", {}).get("sqli_attempts"),
                "impossible_travel"         : result.get("uba_analysis", {}).get("impossible_travel"),
                "apt_attribution"           : result.get("threat_intel", {}).get("apt_attribution"),
                "unauthorized_dumps"        : result.get("db_analysis", {}).get("unauthorized_dumps"),
                "privilege_creep"           : result.get("uba_analysis", {}).get("privilege_creep"),
                "top_attacker_ips"          : [b["ip"] for b in result.get("brute_force", [])[:3]],
                "case_id"                   : case_id,
            }
            result["sigma_rules"] = self.sigma_gen.generate(sigma_input)
        except Exception:
            result["sigma_rules"] = {}

        # 18. CERT-In Form IR-1 Auto-Generation (triggered at risk >= 65)
        try:
            combined = {**result, **sigma_input}
            result["cert_in_report"] = self.cert_in.generate(combined)
        except Exception:
            result["cert_in_report"] = {}

        # 19. Forensic Timeline
        try:
            result["forensic_timeline"] = self.forensic_tl.build(log_content)
        except Exception:
            result["forensic_timeline"] = {}

        # Re-compute final risk with advanced signals
        extra = 0
        if result["lateral_movement"]["lateral_movement_detected"]: extra += 20
        if result["tampering"]["tampering_detected"]:                extra += 15
        if result["credential_stuffing"]["credential_stuffing_detected"]: extra += 10
        if result["sessions"]["post_compromise_detected"]:           extra += 25
        if result.get("dns_analysis", {}).get("dns_risk_score", 0) > 50: extra += 15
        if result.get("beaconing", {}).get("beacons_detected"):       extra += 20
        if result.get("uba_analysis", {}).get("impossible_travel"):   extra += 25
        if result.get("threat_intel", {}).get("apt_attribution"):     extra += 30
        if result.get("cloud_analysis", {}).get("cloud_risk_score", 0) > 50: extra += 15
        if result.get("db_analysis", {}).get("sqli_attempts"):        extra += 20
        if result.get("email_analysis", {}).get("silent_forwarding"): extra += 25
        result["risk_score"] = min(result["risk_score"] + extra, 100)
        result["risk_level"] = self._compute_risk(result)

        # ── Emit real-time events ───────────────────────────────────────
        if case_id:
            self._emit_events(result, case_id)

        return result

    # ── Parser ───────────────────────────────────────────────────────────────
    def _parse_line(self, line: str, result: dict):
        r = result["raw"]

        # SSH failed login
        m = LOG_PATTERNS["ssh_failed"].search(line)
        if m:
            ip   = m.group("ip")
            user = m.group("user")
            r["failed_logins"].append({
                "ip": ip, "user": user,
                "timestamp": m.group("timestamp"),
                "type": "SSH_FAILED_PASSWORD"
            })
            r["ip_failed_counts"][ip]    += 1
            r["failed_users"][user]      += 1
            r["total_events"]            += 1
            return

        # SSH invalid user
        m = LOG_PATTERNS["ssh_invalid_user"].search(line)
        if m:
            ip   = m.group("ip")
            user = m.group("user")
            r["failed_logins"].append({
                "ip": ip, "user": user,
                "timestamp": m.group("timestamp"),
                "type": "SSH_INVALID_USER"
            })
            r["ip_failed_counts"][ip] += 1
            r["failed_users"][user]   += 1
            r["total_events"]         += 1
            return

        # SSH accepted (successful login)
        m = LOG_PATTERNS["ssh_accepted"].search(line)
        if m:
            r["successful_logins"].append({
                "ip": m.group("ip"), "user": m.group("user"),
                "timestamp": m.group("timestamp"),
                "type": "SSH_ACCEPTED"
            })
            r["total_events"] += 1
            return

        # Sudo failure (privilege escalation attempt)
        m = LOG_PATTERNS["sudo_failure"].search(line)
        if m:
            r["privilege_escalations"].append({
                "user": m.group("user"),
                "timestamp": m.group("timestamp"),
                "type": "SUDO_FAILURE",
                "severity": "HIGH"
            })
            r["total_events"] += 1
            return

        # Sudo success
        m = LOG_PATTERNS["sudo_success"].search(line)
        if m:
            r["privilege_escalations"].append({
                "user": m.group("user"),
                "command": m.group("cmd")[:80],
                "timestamp": m.group("timestamp"),
                "type": "SUDO_SUCCESS",
                "severity": "INFO"
            })
            r["total_events"] += 1
            return

        # HTTP request
        m = LOG_PATTERNS["http_request"].search(line)
        if m:
            ip     = m.group("ip")
            status = m.group("status")
            path   = m.group("path")
            r["http_requests"].append({
                "ip": ip, "status": status, "path": path[:100],
                "method": m.group("method"),
                "timestamp": m.group("timestamp"),
            })
            r["ip_request_counts"][ip] += 1
            # Flag scanning patterns
            if any(kw in path.lower() for kw in [
                "../", "passwd", "wp-admin", "phpMyAdmin", ".env",
                "shell", "cmd", "exec", "eval", "config", ".git",
                "admin", "login", "xmlrpc", "backup", "sql"
            ]):
                r["web_scans"].append({"ip": ip, "path": path[:80], "status": status})
            if status in ("401", "403", "404"):
                r["ip_failed_counts"][ip] += 1
            r["total_events"] += 1
            return

        # Port drop (firewall)
        m = LOG_PATTERNS["port_drop"].search(line)
        if m:
            ip   = m.group("ip")
            port = int(m.group("port"))
            r["port_drops"].append({"ip": ip, "port": port})
            r["ip_port_counts"][ip].add(port)
            r["total_events"] += 1
            return

        # Sensitive file access
        m = LOG_PATTERNS["sensitive_file"].search(line)
        if m:
            r["sensitive_accesses"].append({
                "path"     : m.group("path"),
                "timestamp": m.group("timestamp"),
                "severity" : "CRITICAL"
            })
            r["total_events"] += 1
            return

        # Generic failed login (catch-all)
        m = LOG_PATTERNS["generic_failed"].search(line)
        if m:
            ip = m.group("ip") if m.lastgroup == "ip" and m.group("ip") else "unknown"
            r["failed_logins"].append({
                "ip": ip, "user": "unknown",
                "timestamp": "",
                "type": "GENERIC_FAILED"
            })
            if ip != "unknown":
                r["ip_failed_counts"][ip] += 1
            r["total_events"] += 1

    # ── Threat detectors ─────────────────────────────────────────────────────
    def _detect_brute_force(self, result: dict) -> list[dict]:
        attacks = []
        threshold = THRESHOLDS["brute_force_attempts"]
        for ip, count in result["raw"]["ip_failed_counts"].items():
            if count >= threshold:
                # Get usernames tried from this IP
                users_tried = list({
                    e["user"] for e in result["raw"]["failed_logins"]
                    if e.get("ip") == ip
                })
                attacks.append({
                    "ip"         : ip,
                    "attempts"   : count,
                    "users_tried": users_tried[:10],
                    "severity"   : "CRITICAL" if count >= 20 else "HIGH",
                    "threat_type": "BRUTE_FORCE_ATTACK",
                    "description": f"{count} failed login attempts from {ip}",
                })
        return sorted(attacks, key=lambda x: x["attempts"], reverse=True)

    def _detect_port_scans(self, result: dict) -> list[dict]:
        scans = []
        threshold = THRESHOLDS["port_scan_ports"]
        for ip, ports in result["raw"]["ip_port_counts"].items():
            if len(ports) >= threshold:
                scans.append({
                    "ip"         : ip,
                    "ports_hit"  : sorted(ports)[:20],
                    "port_count" : len(ports),
                    "severity"   : "HIGH",
                    "threat_type": "PORT_SCAN",
                    "description": f"Port scan detected — {len(ports)} ports probed from {ip}",
                })
        return sorted(scans, key=lambda x: x["port_count"], reverse=True)

    def _top_attackers(self, result: dict) -> list[dict]:
        raw = result["raw"]
        top = []
        all_ips = set(raw["ip_failed_counts"].keys()) | \
                  {e["ip"] for e in raw["web_scans"] if e.get("ip")}
        for ip in sorted(all_ips,
                         key=lambda x: raw["ip_failed_counts"].get(x, 0),
                         reverse=True)[:10]:
            top.append({
                "ip"            : ip,
                "failed_logins" : raw["ip_failed_counts"].get(ip, 0),
                "web_scans"     : sum(1 for e in raw["web_scans"] if e.get("ip") == ip),
                "port_drops"    : len(raw["ip_port_counts"].get(ip, set())),
                "threat_level"  : self._ip_threat_level(raw["ip_failed_counts"].get(ip, 0)),
            })
        return top

    def _suspicious_accounts(self, result: dict) -> list[dict]:
        accounts = []
        for user, count in result["raw"]["failed_users"].most_common(10):
            if count >= 2:
                accounts.append({
                    "username"   : user,
                    "failed_attempts": count,
                    "severity"   : "HIGH" if count >= 5 else "MEDIUM",
                    "note"       : "Account under attack" if count >= 5 else "Suspicious activity",
                })
        return accounts

    def _build_timeline(self, result: dict) -> list[dict]:
        events = []
        for e in result["raw"]["failed_logins"][-20:]:
            if e.get("timestamp"):
                events.append({
                    "time"   : e["timestamp"],
                    "type"   : e["type"],
                    "ip"     : e.get("ip",""),
                    "user"   : e.get("user",""),
                    "severity":"HIGH",
                })
        for e in result["raw"]["privilege_escalations"][-5:]:
            events.append({
                "time"    : e.get("timestamp",""),
                "type"    : e["type"],
                "user"    : e.get("user",""),
                "severity": e["severity"],
            })
        for e in result["raw"]["sensitive_accesses"]:
            events.append({
                "time"    : e.get("timestamp",""),
                "type"    : "SENSITIVE_FILE_ACCESS",
                "path"    : e.get("path",""),
                "severity": "CRITICAL",
            })
        return events[:30]

    def _compute_risk(self, result: dict) -> str:
        score = self._compute_risk_score(result)
        if score >= 75: return "CRITICAL"
        if score >= 50: return "HIGH"
        if score >= 25: return "MEDIUM"
        return "LOW"

    def _compute_risk_score(self, result: dict) -> int:
        score = 0
        raw   = result["raw"]
        total_failed = len(raw["failed_logins"])
        bf    = result.get("brute_force", [])

        score += min(total_failed * 3, 30)     # Failed login volume
        score += len(bf) * 15                  # Brute force attacks
        score += len(result.get("port_scan_suspects",[])) * 15
        score += len(raw["privilege_escalations"]) * 10
        score += len(raw["sensitive_accesses"]) * 20
        score += min(len(raw["web_scans"]) * 2, 20)

        return min(score, 100)

    def _build_findings(self, result: dict) -> list[dict]:
        findings = []
        raw = result["raw"]

        if result.get("brute_force"):
            top_bf = result["brute_force"][0]
            findings.append({
                "severity"   : "CRITICAL",
                "category"   : "Brute Force Attack",
                "description": f"Multiple failed login attempts detected from {len(result['brute_force'])} unique IP(s). "
                               f"Top attacker: {top_bf['ip']} with {top_bf['attempts']} attempts.",
                "count"      : sum(b["attempts"] for b in result["brute_force"]),
                "action"     : "Block attacking IPs immediately via firewall rules",
            })

        if result.get("port_scan_suspects"):
            findings.append({
                "severity"   : "HIGH",
                "category"   : "Port Scan Detected",
                "description": f"{len(result['port_scan_suspects'])} IP(s) probing multiple ports. "
                               f"Reconnaissance activity suspected.",
                "count"      : len(result["port_scan_suspects"]),
                "action"     : "Enable IDS/IPS rules, check exposed services",
            })

        priv_failures = [e for e in raw["privilege_escalations"] if e["type"]=="SUDO_FAILURE"]
        if priv_failures:
            findings.append({
                "severity"   : "HIGH",
                "category"   : "Privilege Escalation Attempt",
                "description": f"{len(priv_failures)} sudo authentication failure(s) detected. "
                               f"Insider threat or compromised account activity.",
                "count"      : len(priv_failures),
                "action"     : "Audit sudo access, review user privileges",
            })

        if raw["sensitive_accesses"]:
            findings.append({
                "severity"   : "CRITICAL",
                "category"   : "Sensitive File Access",
                "description": f"Access to critical system files detected: "
                               f"{', '.join(list(set(s['path'] for s in raw['sensitive_accesses']))[:3])}",
                "count"      : len(raw["sensitive_accesses"]),
                "action"     : "Investigate immediately — possible data exfiltration",
            })

        if raw["web_scans"]:
            paths = list(set(w["path"] for w in raw["web_scans"]))[:3]
            findings.append({
                "severity"   : "MEDIUM",
                "category"   : "Web Application Scanning",
                "description": f"Suspicious web requests targeting: {', '.join(paths)}",
                "count"      : len(raw["web_scans"]),
                "action"     : "Enable WAF rules, block scanning IPs",
            })

        if not findings:
            findings.append({
                "severity"   : "INFO",
                "category"   : "No Critical Threats",
                "description": "No significant threats detected in the provided log file.",
                "count"      : 0,
                "action"     : "Continue routine monitoring",
            })

        return findings

    def _generate_recommendations(self, result: dict) -> list[dict]:
        recs  = []
        raw   = result["raw"]
        score = result.get("risk_score", 0)

        if result.get("brute_force"):
            recs.append({
                "priority": "CRITICAL",
                "action"  : "Enable Multi-Factor Authentication (MFA)",
                "detail"  : "MFA prevents credential-based attacks even when passwords are compromised",
                "timeline": "Immediate (within 24 hours)",
            })
            recs.append({
                "priority": "CRITICAL",
                "action"  : "Implement IP-based rate limiting and account lockout",
                "detail"  : "Lock accounts after 5 failed attempts; block IPs after 10",
                "timeline": "Immediate",
            })
            recs.append({
                "priority": "HIGH",
                "action"  : f"Block top attacking IPs via firewall",
                "detail"  : f"IPs: {', '.join(b['ip'] for b in result['brute_force'][:5])}",
                "timeline": "Within 1 hour",
            })

        if raw["failed_users"]:
            common_users = [u for u, c in raw["failed_users"].most_common(3)]
            recs.append({
                "priority": "HIGH",
                "action"  : "Enforce strong password policy",
                "detail"  : f"Frequently targeted accounts: {', '.join(common_users)}. "
                            f"Require 12+ chars, mixed case, symbols.",
                "timeline": "Within 48 hours",
            })

        if raw["privilege_escalations"]:
            recs.append({
                "priority": "HIGH",
                "action"  : "Audit and restrict sudo privileges",
                "detail"  : "Apply principle of least privilege — remove unnecessary sudo access",
                "timeline": "Within 24 hours",
            })

        if result.get("port_scan_suspects"):
            recs.append({
                "priority": "HIGH",
                "action"  : "Enable Intrusion Detection System (IDS)",
                "detail"  : "Deploy Snort or Suricata rules to detect and alert on port scans",
                "timeline": "Within 72 hours",
            })

        recs.append({
            "priority": "MEDIUM",
            "action"  : "Monitor user activity with SIEM integration",
            "detail"  : "Forward all logs to SIEM (Splunk/ELK) for correlation and alerting",
            "timeline": "Within 1 week",
        })
        recs.append({
            "priority": "MEDIUM",
            "action"  : "Enable SSH key-based authentication only",
            "detail"  : "Disable password-based SSH login — use RSA/Ed25519 keys only",
            "timeline": "Within 48 hours",
        })
        recs.append({
            "priority": "LOW",
            "action"  : "Schedule regular log review",
            "detail"  : "Daily automated analysis with weekly manual review by SOC analyst",
            "timeline": "Ongoing",
        })

        return recs

    def _executive_summary(self, result: dict) -> str:
        raw   = result["raw"]
        risk  = result.get("risk_level","LOW")
        score = result.get("risk_score",0)
        bf    = result.get("brute_force",[])
        total = raw["total_events"]
        failed= len(raw["failed_logins"])

        summary = (
            f"Analysis of {result['source_name']} containing {total} security events "
            f"reveals a {risk} risk posture (score: {score}/100). "
        )
        if bf:
            summary += (
                f"CRITICAL: {len(bf)} brute-force attack source(s) identified, "
                f"with {failed} total failed authentication attempts. "
                f"Top attacker: {bf[0]['ip']} ({bf[0]['attempts']} attempts). "
            )
        if raw["sensitive_accesses"]:
            summary += (
                f"CRITICAL: {len(raw['sensitive_accesses'])} sensitive file access event(s) detected — "
                f"possible data exfiltration or privilege escalation. "
            )
        if raw["privilege_escalations"]:
            priv_fail = [e for e in raw["privilege_escalations"] if e["type"]=="SUDO_FAILURE"]
            if priv_fail:
                summary += f"{len(priv_fail)} privilege escalation attempt(s) logged. "

        summary += "Immediate remediation recommended as per findings below."
        return summary

    def _geolocate_ips(self, result: dict) -> list[dict]:
        """Best-effort geolocation of top attacking IPs (no external API needed)."""
        # Simplified heuristic geolocation based on known ranges
        geo = []
        top_ips = {b["ip"] for b in result.get("brute_force",[])} | \
                  {p["ip"] for p in result.get("port_scan_suspects",[])}
        for ip in list(top_ips)[:5]:
            geo.append({
                "ip"     : ip,
                "country": self._heuristic_country(ip),
                "risk"   : "HIGH",
            })
        return geo

    def _heuristic_country(self, ip: str) -> str:
        """Heuristic IP-to-country mapping for well-known ranges."""
        try:
            parts = [int(p) for p in ip.split(".")]
            if parts[0] == 10 or (parts[0]==192 and parts[1]==168) or parts[0]==172:
                return "Internal Network"
            if parts[0] == 185: return "Russia/Netherlands"
            if parts[0] == 45:  return "USA/Europe"
            if parts[0] == 103: return "Asia"
            if parts[0] == 119: return "China"
            if parts[0] == 202: return "Asia-Pacific"
            if parts[0] == 49:  return "India"
        except Exception:
            pass
        return "Unknown"

    def _emit_events(self, result: dict, case_id: str):
        if result.get("brute_force"):
            emit(EventType.BANKING_THREAT, case_id, {
                "type"  : "BRUTE_FORCE",
                "count" : len(result["brute_force"]),
                "top_ip": result["brute_force"][0]["ip"],
            }, severity="CRITICAL")
        if result.get("risk_level") in ("CRITICAL","HIGH"):
            emit(EventType.SCORE_FINAL, case_id, {
                "final_score": result["risk_score"],
                "severity"   : result["risk_level"],
                "source"     : "LOG_ANALYSIS",
            })

    @staticmethod
    def _ip_threat_level(failed: int) -> str:
        if failed >= 20: return "CRITICAL"
        if failed >= 10: return "HIGH"
        if failed >= 5 : return "MEDIUM"
        return "LOW"

    def _build_heatmap(self, failed_logins: list) -> list:
        """Build hour-of-day attack frequency for heatmap visualization."""
        hour_counts = [0] * 24
        ts_pattern  = re.compile(r'(\d{2}):\d{2}:\d{2}')
        for entry in failed_logins:
            m = ts_pattern.search(entry.get("timestamp",""))
            if m:
                hour = int(m.group(1))
                hour_counts[hour] += 1
        return [
            {"hour": h, "label": f"{h:02d}:00", "count": hour_counts[h],
             "severity": "CRITICAL" if hour_counts[h] >= 20
                         else "HIGH" if hour_counts[h] >= 10
                         else "MEDIUM" if hour_counts[h] >= 3
                         else "LOW"}
            for h in range(24)
        ]

    @staticmethod
    def _fresh_result(source_name: str, line_count: int) -> dict:
        return {
            "source_name"      : source_name,
            "line_count"       : line_count,
            "analysis_time"    : datetime.now(timezone.utc).isoformat(),
            "raw": {
                "total_events"          : 0,
                "failed_logins"         : [],
                "successful_logins"     : [],
                "privilege_escalations" : [],
                "http_requests"         : [],
                "web_scans"             : [],
                "port_drops"            : [],
                "sensitive_accesses"    : [],
                "ip_failed_counts"      : defaultdict(int),
                "ip_request_counts"     : defaultdict(int),
                "ip_port_counts"        : defaultdict(set),
                "failed_users"          : Counter(),
            },
            "brute_force"          : [],
            "port_scan_suspects"   : [],
            "top_attacking_ips"    : [],
            "suspicious_accounts"  : [],
            "attack_timeline"      : [],
            "risk_level"           : "LOW",
            "risk_score"           : 0,
            "findings"             : [],
            "recommendations"      : [],
            "executive_summary"    : "",
            "geographic_origins"   : [],
            "ip_intelligence"      : [],
            "geo_map_data"         : [],
            "attack_fingerprint"   : [],
            "anomalies"            : {},
            "lateral_movement"     : {},
            "tampering"            : {},
            "credential_stuffing"  : {},
            "sessions"             : {},
            "campaigns"            : {},
            "heatmap_data"         : [],
        }
