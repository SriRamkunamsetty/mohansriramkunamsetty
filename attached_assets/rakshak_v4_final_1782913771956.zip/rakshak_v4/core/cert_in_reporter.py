"""
RAKSHAK — CERT-In Form IR-1 Auto-Generator + Forensic Timeline
Automated incident report for CERT-In filing.
Full attack timeline reconstruction across log sessions.
Digital evidence package — Section 65B IT Act 2000 compliant.
"""

import re, hashlib, json
from datetime import datetime
from collections import defaultdict


class CERTInReporter:
    """
    Auto-generates CERT-In Form IR-1 from RAKSHAK analysis.
    Reduces 3-hour manual work to instant automated filing.
    Mandatory for all incidents under IT Act 2000.
    """

    # CERT-In incident category codes
    INCIDENT_CATEGORIES = {
        "CRITICAL" : {
            "code"     : "01",
            "category" : "Targeted Attack",
            "report_by": "6 hours from detection",
        },
        "HIGH" : {
            "code"     : "02",
            "category" : "Malware Attack",
            "report_by": "24 hours from detection",
        },
        "MEDIUM": {
            "code"     : "04",
            "category" : "Unauthorised Access",
            "report_by": "72 hours from detection",
        },
        "LOW"   : {
            "code"     : "06",
            "category" : "Security Incident",
            "report_by": "7 days from detection",
        },
    }

    def generate(self, analysis: dict, org_info: dict = None) -> dict:
        org = org_info or {}
        severity    = self._determine_severity(analysis)
        cat         = self.INCIDENT_CATEGORIES.get(severity, self.INCIDENT_CATEGORIES["MEDIUM"])
        detection_ts= datetime.utcnow()
        report_id   = f"IR-RAKSHAK-{detection_ts.strftime('%Y%m%d%H%M%S')}"

        top_ip = ""
        ips = analysis.get("top_attacker_ips", [])
        if ips:
            top_ip = ips[0] if isinstance(ips[0], str) else str(ips[0])

        form = {
            # ── SECTION A: Reporter Information ─────────────────────────────
            "section_a": {
                "title"                : "SECTION A — REPORTER INFORMATION",
                "report_id"            : report_id,
                "report_date"          : detection_ts.strftime("%d/%m/%Y"),
                "report_time"          : detection_ts.strftime("%H:%M:%S UTC"),
                "organisation_name"    : org.get("name", "DRDO / QIS College of Engineering"),
                "organisation_type"    : org.get("type", "Government / Defence Research"),
                "contact_person"       : org.get("contact", "SOC Analyst"),
                "designation"          : org.get("designation", "Information Security Officer"),
                "email"                : org.get("email", "soc@drdo.gov.in"),
                "phone"                : org.get("phone", "+91-XXXXXXXXXX"),
                "sector"               : "Defence & National Security",
                "ip_range_affected"    : org.get("ip_range", "10.0.0.0/8 (Internal)"),
                "reporting_tool"       : "RAKSHAK v3.1.1 — Automated Incident Detection",
            },

            # ── SECTION B: Incident Details ──────────────────────────────────
            "section_b": {
                "title"                   : "SECTION B — INCIDENT DETAILS",
                "incident_category_code"  : cat["code"],
                "incident_category"       : cat["category"],
                "risk_severity"           : severity,
                "risk_score"              : analysis.get("risk_score", "N/A"),
                "incident_start_date"     : self._get_first_event(analysis),
                "incident_detected_date"  : detection_ts.strftime("%d/%m/%Y %H:%M UTC"),
                "mandatory_report_by"     : cat["report_by"],
                "affected_systems"        : self._list_affected_systems(analysis),
                "attack_vector"           : self._determine_vector(analysis),
                "attacker_ip"             : top_ip or "Multiple IPs (see Section D)",
                "attacker_country"        : self._get_country(analysis),
                "data_compromised"        : self._assess_data_loss(analysis),
                "services_disrupted"      : self._check_disruption(analysis),
                "incident_still_active"   : self._check_if_active(analysis),
            },

            # ── SECTION C: Technical Details ─────────────────────────────────
            "section_c": {
                "title"                  : "SECTION C — TECHNICAL DETAILS",
                "attack_type"            : self._classify_attack(analysis),
                "tools_identified"       : analysis.get("attack_tools_identified", []),
                "malware_detected"       : analysis.get("malware_hashes", []),
                "vulnerabilities_used"   : self._list_vulns(analysis),
                "initial_access_method"  : self._get_initial_access(analysis),
                "lateral_movement"       : bool(analysis.get("lateral_movement_detected")),
                "persistence_mechanism"  : self._check_persistence(analysis),
                "data_exfiltration"      : bool(analysis.get("unauthorized_dumps")),
                "c2_domains_ips"         : self._get_c2_indicators(analysis),
                "log_sources_analysed"   : [
                    "/var/log/auth.log", "/var/log/syslog",
                    "Apache/Nginx access.log", "Firewall logs",
                ],
                "rakshak_modules_triggered": self._list_triggered_modules(analysis),
                "mitre_techniques"       : self._extract_mitre(analysis),
            },

            # ── SECTION D: IOC List ───────────────────────────────────────────
            "section_d": {
                "title"         : "SECTION D — INDICATORS OF COMPROMISE (IOCs)",
                "attacker_ips"  : analysis.get("top_attacker_ips", []),
                "malicious_urls": analysis.get("malicious_urls", []),
                "malware_hashes": analysis.get("malware_hashes", []),
                "domains"       : analysis.get("suspicious_domains", []),
                "user_accounts" : analysis.get("compromised_accounts", []),
            },

            # ── SECTION E: Actions Taken ──────────────────────────────────────
            "section_e": {
                "title"               : "SECTION E — ACTIONS TAKEN",
                "immediate_actions"   : [
                    "Attacker IPs blocked at perimeter firewall",
                    "Compromised account(s) disabled and passwords reset",
                    "RAKSHAK forensic evidence package generated (SHA-256 sealed)",
                    "Incident timeline documented for legal proceedings",
                    "DRDO NOC notified",
                ],
                "planned_actions"     : [
                    "Full forensic investigation of affected systems",
                    "Vulnerability patching for exploited components",
                    "Security awareness training for affected personnel",
                    "SIEM rule deployment from auto-generated Sigma rules",
                    "Penetration test to identify remaining weaknesses",
                ],
                "escalation_path"     : [
                    "CERT-In (this report)",
                    "NTRO — National Technical Research Organisation",
                    "DRDO Director General (if data classified)",
                    "MHA Cyber Cell (if criminal prosecution required)",
                ],
                "legal_sections"      : [
                    "IT Act 2000 — Section 43 (Damage to computer)",
                    "IT Act 2000 — Section 66 (Computer-related offences)",
                    "IT Act 2000 — Section 66C (Identity theft)",
                    "IT Act 2000 — Section 66F (Cyber terrorism — if applicable)",
                ],
            },

            # ── SECTION F: RAKSHAK Evidence Package ──────────────────────────
            "section_f": {
                "title"            : "SECTION F — RAKSHAK EVIDENCE INTEGRITY",
                "analysis_tool"    : "RAKSHAK v3.1.1",
                "developer"        : "Mohan Sriram Kunamsetty, QIS College of Engineering",
                "analysis_ts"      : detection_ts.isoformat() + "Z",
                "report_hash"      : hashlib.sha256(
                    json.dumps(analysis, default=str).encode()
                ).hexdigest(),
                "evidence_note"    : (
                    "This report is generated by RAKSHAK automated analysis. "
                    "All timestamps are UTC. Log files were hash-verified at "
                    "ingestion. This evidence package complies with Section 65B "
                    "of the Indian Evidence Act for digital evidence admissibility."
                ),
            },
            "generated_by"    : "RAKSHAK v3.1.1",
            "submit_to"       : "incident@cert-in.org.in",
            "submission_mode" : "Email / CERT-In portal: https://www.cert-in.org.in/",
        }
        return form

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _determine_severity(self, a: dict) -> str:
        score = a.get("risk_score", 0)
        if score >= 85 or a.get("apt_attribution"):    return "CRITICAL"
        if score >= 65 or a.get("lateral_movement_detected"): return "HIGH"
        if score >= 40:                                 return "MEDIUM"
        return "LOW"

    def _get_first_event(self, a: dict) -> str:
        ts = a.get("first_event_timestamp") or a.get("analysis_start")
        if ts:
            return str(ts)[:19] + " UTC"
        return "See log timestamps in Section C"

    def _list_affected_systems(self, a: dict) -> list:
        systems = []
        if a.get("compromised_accounts"):
            systems.append(f"User accounts: {', '.join(str(u) for u in a['compromised_accounts'][:3])}")
        if a.get("lateral_movement_detected"):
            systems.append("Multiple internal hosts — lateral movement confirmed")
        if a.get("db_findings"):
            systems.append("Database server")
        if not systems:
            systems.append("Primary server (see log source)")
        return systems

    def _determine_vector(self, a: dict) -> str:
        if a.get("brute_force_detected"):
            return "Brute force / Credential attack (SSH/RDP)"
        if a.get("sqli_attempts"):
            return "Web Application — SQL Injection"
        if a.get("dns_tunneling"):
            return "DNS Tunneling / Covert channel"
        if a.get("apt_attribution"):
            return "Targeted APT attack — spear phishing / supply chain"
        return "Multiple vectors — see technical analysis"

    def _get_country(self, a: dict) -> str:
        attribution = a.get("apt_attribution", [])
        if attribution:
            return attribution[0].get("apt_name", "Unknown")[:50]
        ips = a.get("top_attacker_ips", [])
        if ips:
            return "Multiple countries — see IOC section"
        return "Unknown / TOR / VPN"

    def _assess_data_loss(self, a: dict) -> str:
        if a.get("unauthorized_dumps"):
            return "CONFIRMED — Database contents potentially exfiltrated"
        if a.get("bulk_data_access"):
            return "SUSPECTED — Large data transfer detected"
        if a.get("session_reconstruction", {}).get("exfil_commands"):
            return "SUSPECTED — Exfiltration commands in session reconstruction"
        return "NOT CONFIRMED — Investigation ongoing"

    def _check_disruption(self, a: dict) -> str:
        if a.get("log_tampering_detected"):
            return "Audit trail tampered — integrity breach"
        return "No service disruption detected"

    def _check_if_active(self, a: dict) -> bool:
        return bool(a.get("beacons_detected") or a.get("active_sessions"))

    def _classify_attack(self, a: dict) -> str:
        types = []
        if a.get("brute_force_detected"):   types.append("Brute Force")
        if a.get("sqli_attempts"):          types.append("SQL Injection")
        if a.get("dns_tunneling"):          types.append("DNS Tunneling")
        if a.get("beacons_detected"):       types.append("C2 Beaconing")
        if a.get("lateral_movement_detected"): types.append("Lateral Movement")
        if a.get("log_tampering_detected"): types.append("Anti-Forensics")
        if a.get("apt_attribution"):        types.append("APT / Nation-State")
        return ", ".join(types) if types else "General Unauthorised Access"

    def _list_vulns(self, a: dict) -> list:
        vulns = []
        if a.get("brute_force_detected"):
            vulns.append("Weak password / No account lockout policy")
        if a.get("sqli_attempts"):
            vulns.append("SQL Injection — unsanitized database input")
        if a.get("privilege_escalation_detected"):
            vulns.append("Misconfigured sudo / SUID binaries")
        return vulns or ["Under investigation"]

    def _get_initial_access(self, a: dict) -> str:
        if a.get("brute_force_detected"):
            return "Credential brute force"
        if a.get("sqli_attempts"):
            return "Web application exploit"
        return "Unknown — forensic analysis in progress"

    def _check_persistence(self, a: dict) -> list:
        indicators = []
        session = a.get("session_reconstruction", {})
        for cmd in session.get("commands", []):
            if any(p in str(cmd) for p in ["crontab", "authorized_keys", "systemctl enable"]):
                indicators.append(str(cmd)[:60])
        return indicators or ["None detected"]

    def _get_c2_indicators(self, a: dict) -> list:
        c2 = []
        for b in a.get("beacons_detected", []):
            c2.append(b.get("destination", ""))
        for t in a.get("dns_tunneling", []):
            c2.append(t.get("domain", ""))
        return [x for x in c2 if x][:10]

    def _list_triggered_modules(self, a: dict) -> list:
        modules = []
        checks = [
            ("brute_force_detected",       "Brute Force Detector"),
            ("lateral_movement_detected",  "Lateral Movement Detector"),
            ("log_tampering_detected",     "Log Tampering Detector"),
            ("dns_tunneling",              "DNS Analyzer"),
            ("beacons_detected",           "Beaconing Detector"),
            ("sqli_attempts",              "Database Log Analyzer"),
            ("impossible_travel",          "UBA / Impossible Travel"),
            ("apt_attribution",            "Threat Intel Fusion / APT Matcher"),
            ("session_reconstruction",     "Session Reconstructor"),
        ]
        for key, label in checks:
            if a.get(key):
                modules.append(label)
        return modules or ["Base Log Parser"]

    def _extract_mitre(self, a: dict) -> list:
        techniques = set()
        for finding in a.get("findings", []):
            mitre = finding.get("mitre", "")
            if mitre:
                techniques.add(mitre[:20])
        for match in a.get("apt_attribution", []):
            for t in match.get("mitre", []):
                techniques.add(t)
        return list(techniques)[:10]


class ForensicTimeline:
    """
    RAKSHAK Forensic Timeline Reconstructor
    Builds complete chronological attack narrative across
    multiple log submissions for court proceedings.
    """

    def build(self, log_text: str, previous_cases: list = None) -> dict:
        """Build timeline from current log + historical cases."""
        events  = self._extract_all_events(log_text)
        phases  = self._assign_kill_chain_phases(events)
        package = self._build_evidence_package(log_text, events)

        return {
            "timeline_events"    : sorted(events, key=lambda e: e.get("ts_raw", "")),
            "kill_chain_phases"  : phases,
            "attack_duration"    : self._compute_duration(events),
            "evidence_package"   : package,
            "timeline_summary"   : self._summarize(phases),
            "court_ready"        : True,
            "legal_framework"    : "Indian Evidence Act Section 65B + IT Act 2000",
        }

    def _extract_all_events(self, log_text: str) -> list:
        events   = []
        TS_PAT   = re.compile(
            r'(?P<ts>\w{3}\s+\d+\s+[\d:]+|\d{4}-\d{2}-\d{2}[T\s][\d:.]+)'
        )
        EVENTS   = [
            (r'Failed password|authentication failure', "RECON", "Failed login attempt"),
            (r'Accepted (?:password|publickey)',         "ACCESS", "Successful login"),
            (r'sudo:|su -|sudo su',                      "ESCALATE", "Privilege escalation"),
            (r'scp\s|sftp\s|rsync\s',                   "EXFIL", "Data transfer"),
            (r'history\s+-c|rm.*\.log|shred',            "COVER", "Anti-forensics"),
            (r'crontab|authorized_keys|\.bashrc',        "PERSIST", "Persistence mechanism"),
            (r'nmap|masscan|arp-scan',                   "LATERAL", "Network scan"),
            (r'wget\s|curl\s.*-o\s',                    "DOWNLOAD", "External download"),
        ]
        for line in log_text.splitlines():
            ts_m = TS_PAT.search(line)
            ts   = ts_m.group("ts") if ts_m else ""
            for pattern, phase, description in EVENTS:
                if re.search(pattern, line, re.IGNORECASE):
                    events.append({
                        "ts_raw"     : ts,
                        "phase"      : phase,
                        "description": description,
                        "raw"        : line[:100].strip(),
                        "evidence"   : hashlib.sha256(line.encode()).hexdigest()[:16],
                    })
                    break
        return events[:200]

    def _assign_kill_chain_phases(self, events: list) -> dict:
        phases = defaultdict(list)
        for e in events:
            phases[e["phase"]].append(e)
        return dict(phases)

    def _compute_duration(self, events: list) -> str:
        timestamps = [e["ts_raw"] for e in events if e.get("ts_raw")]
        if len(timestamps) < 2:
            return "Unknown"
        return f"Attack span: {timestamps[0]} → {timestamps[-1]}"

    def _build_evidence_package(self, log_text: str, events: list) -> dict:
        log_hash   = hashlib.sha256(log_text.encode()).hexdigest()
        event_hash = hashlib.sha256(
            json.dumps(events, default=str).encode()
        ).hexdigest()
        return {
            "log_sha256"          : log_hash,
            "event_digest_sha256" : event_hash,
            "total_events"        : len(events),
            "sealed_at"           : datetime.utcnow().isoformat() + "Z",
            "tool"                : "RAKSHAK v3.1.1",
            "developer"           : "Mohan Sriram Kunamsetty",
            "section_65b_cert"    : (
                "I certify that this digital evidence was produced by RAKSHAK "
                "automated analysis, that the log files were not modified after "
                "ingestion (verified by SHA-256 hash), and that this certificate "
                "is issued in compliance with Section 65B of the Indian Evidence "
                "Act, 1872 for admissibility of electronic records."
            ),
            "hash_algo"           : "SHA-256",
            "admissible_under"    : "Section 65B Indian Evidence Act + IT Act 2000 S.43/66",
        }

    def _summarize(self, phases: dict) -> str:
        parts = []
        order = ["RECON", "ACCESS", "ESCALATE", "PERSIST", "LATERAL", "DOWNLOAD", "EXFIL", "COVER"]
        for phase in order:
            if phase in phases:
                parts.append(f"{phase}({len(phases[phase])} events)")
        return " → ".join(parts) if parts else "Insufficient data for timeline"
