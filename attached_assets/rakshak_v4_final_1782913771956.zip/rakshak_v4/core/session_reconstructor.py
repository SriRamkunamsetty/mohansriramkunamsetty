"""
RAKSHAK — Attacker Session Reconstructor
Most critical forensic module: What did the attacker DO after they got in?
Traces post-compromise activity from auth, syslog, bash_history, audit logs
"""

import re
from datetime import datetime, timezone
from collections import defaultdict


# ── High-risk command patterns ────────────────────────────────────────────────
COMMAND_RISK = {
    # Privilege escalation
    r'\bsudo\b'                    : ("PRIV_ESC",   "CRITICAL", "Privilege escalation attempt"),
    r'\bsu\s+-'                    : ("PRIV_ESC",   "CRITICAL", "User switch to root"),
    r'\bchmod\s+[0-7]*7[0-7]*'    : ("PRIV_ESC",   "HIGH",     "World-writable permission set"),
    r'\bchown\s+root'              : ("PRIV_ESC",   "HIGH",     "Changed ownership to root"),

    # Persistence mechanisms
    r'crontab\s+-e'                : ("PERSISTENCE","CRITICAL", "Cron job modification"),
    r'/etc/rc\.|/etc/init\.d'      : ("PERSISTENCE","CRITICAL", "Startup script modification"),
    r'\.bashrc|\.bash_profile|\.profile': ("PERSISTENCE","HIGH","Shell profile modification"),
    r'authorized_keys'             : ("PERSISTENCE","CRITICAL", "SSH key backdoor planted"),
    r'systemctl\s+enable'          : ("PERSISTENCE","HIGH",     "Service enabled for persistence"),

    # Data exfiltration
    r'\bcurl\b.*http'              : ("EXFIL",      "HIGH",     "HTTP data transfer"),
    r'\bwget\b.*http'              : ("EXFIL",      "HIGH",     "HTTP file download"),
    r'\bscp\b'                     : ("EXFIL",      "CRITICAL", "Secure copy — possible data theft"),
    r'\brsync\b'                   : ("EXFIL",      "HIGH",     "Remote sync — possible exfiltration"),
    r'\bbase64\b'                  : ("EXFIL",      "HIGH",     "Base64 encoding — data obfuscation"),
    r'\bnc\b|\bnetcat\b'           : ("EXFIL",      "CRITICAL", "Netcat — covert channel"),
    r'\btar\b.*\.tar'              : ("EXFIL",      "MEDIUM",   "Archive creation — staging for exfil"),

    # Reconnaissance
    r'\bwhoami\b|\bid\b'           : ("RECON",      "HIGH",     "Identity discovery"),
    r'\buname\s+-a'                : ("RECON",      "HIGH",     "System information gathering"),
    r'\bcat\s+/etc/passwd'         : ("RECON",      "CRITICAL", "Password file read"),
    r'\bcat\s+/etc/shadow'         : ("RECON",      "CRITICAL", "Shadow password file read"),
    r'\bnetstat\b|\bss\s+-'        : ("RECON",      "MEDIUM",   "Network connection enumeration"),
    r'\bps\s+(aux|ef|-ef)'         : ("RECON",      "MEDIUM",   "Process enumeration"),
    r'\bfind\s+/\s+'               : ("RECON",      "MEDIUM",   "Filesystem search"),
    r'\bls\s+-la\s+/root'          : ("RECON",      "HIGH",     "Root directory enumeration"),
    r'\benv\b|\bprintenv\b'        : ("RECON",      "MEDIUM",   "Environment variable dump"),
    r'\bhistory\b'                 : ("RECON",      "MEDIUM",   "Command history access"),

    # Lateral movement
    r'\bssh\s+\d+'                 : ("LATERAL",    "CRITICAL", "SSH pivot to internal host"),
    r'\bnmap\b'                    : ("LATERAL",    "CRITICAL", "Network scan tool"),
    r'\bping\s+-c'                 : ("LATERAL",    "MEDIUM",   "Host discovery ping"),
    r'\barp\b|-scan\b'             : ("LATERAL",    "HIGH",     "ARP scan — local network enum"),

    # Malware/backdoor
    r'\bchmod\s+\+x\b'            : ("MALWARE",    "HIGH",     "Made file executable"),
    r'\b/tmp/\w+'                  : ("MALWARE",    "HIGH",     "Execution from /tmp"),
    r'\b/dev/shm/\w+'              : ("MALWARE",    "CRITICAL", "Execution from /dev/shm (in-memory)"),
    r'python[23]?\s+-c'            : ("MALWARE",    "HIGH",     "Inline Python execution"),
    r'perl\s+-e'                   : ("MALWARE",    "HIGH",     "Inline Perl execution"),
    r'bash\s+-i\s+>&'              : ("MALWARE",    "CRITICAL", "Reverse shell"),
    r'/bin/bash\s+-i'              : ("MALWARE",    "CRITICAL", "Interactive shell spawned"),
    r'mkfifo\b'                    : ("MALWARE",    "CRITICAL", "Named pipe — possible reverse shell"),

    # Evidence removal (anti-forensics)
    r'history\s+-c'               : ("ANTIFORENSIC","CRITICAL","Command history cleared"),
    r'rm\s+.*\.log'               : ("ANTIFORENSIC","CRITICAL","Log file deletion"),
    r'shred\b'                    : ("ANTIFORENSIC","CRITICAL","Secure file deletion"),
    r'unset\s+HISTFILE'           : ("ANTIFORENSIC","HIGH",    "History file disabled"),
    r'HISTSIZE=0'                 : ("ANTIFORENSIC","HIGH",    "History size set to zero"),
    r'>\s*/var/log/'              : ("ANTIFORENSIC","CRITICAL","Log file truncated"),
}

# ── Sensitive file access patterns ────────────────────────────────────────────
SENSITIVE_FILES = [
    ("/etc/passwd",            "CRITICAL", "System user database"),
    ("/etc/shadow",            "CRITICAL", "Encrypted passwords"),
    ("/etc/sudoers",           "CRITICAL", "Sudo configuration"),
    ("/root/.ssh/",            "CRITICAL", "Root SSH keys"),
    ("/home/.*/.ssh/",         "CRITICAL", "User SSH keys"),
    ("/var/log/auth.log",      "HIGH",     "Auth log — evidence of attacker's tracks"),
    ("/proc/",                 "MEDIUM",   "Process/system information"),
    ("/etc/crontab",           "HIGH",     "Cron jobs"),
    ("/etc/hosts",             "MEDIUM",   "Hosts file — DNS manipulation"),
    ("/etc/resolv.conf",       "MEDIUM",   "DNS configuration"),
    (".aws/credentials",       "CRITICAL", "AWS credentials"),
    (".env",                   "CRITICAL", "Environment file (API keys)"),
    ("id_rsa",                 "CRITICAL", "Private SSH key"),
    ("*.pem",                  "CRITICAL", "Certificate/private key file"),
]


class SessionReconstructor:
    """
    RAKSHAK Attacker Session Reconstructor

    What it answers:
    - Who logged in successfully? When? From where?
    - What commands did they run?
    - What files did they access?
    - Did they escalate privileges?
    - Did they plant a backdoor?
    - Did they exfiltrate data?
    - Did they cover their tracks?

    Input: auth.log + syslog + bash_history + audit.log (any combination)
    Output: Structured session timeline with forensic evidence
    """

    def reconstruct(self, log_text: str,
                    successful_logins: list[dict] = None) -> dict:
        lines    = log_text.splitlines()
        sessions = {}

        # ── Detect successful logins first ────────────────────────────────
        if not successful_logins:
            successful_logins = self._find_successful_logins(lines)

        # ── Parse post-login activity for each session ─────────────────
        for login in successful_logins:
            ip   = login.get("ip", "unknown")
            user = login.get("user", "unknown")
            ts   = login.get("timestamp", "")
            key  = f"{ip}_{user}_{ts}"

            sessions[key] = {
                "session_id"         : key,
                "attacker_ip"        : ip,
                "username"           : user,
                "login_timestamp"    : ts,
                "logout_timestamp"   : "",
                "duration_estimate"  : "",
                "commands_run"       : [],
                "files_accessed"     : [],
                "privilege_escalations": [],
                "persistence_actions": [],
                "data_exfil_indicators": [],
                "lateral_movement"   : [],
                "anti_forensics"     : [],
                "malware_indicators" : [],
                "session_risk_score" : 0,
                "session_verdict"    : "INVESTIGATING",
                "kill_chain_stage"   : [],
                "evidence_for_fir"   : [],
            }

        # ── Parse all lines for post-login activity ────────────────────
        for line in lines:
            for key, session in sessions.items():
                self._parse_session_line(line, session)

        # ── Score and classify each session ───────────────────────────
        result_sessions = []
        for key, session in sessions.items():
            session = self._score_session(session)
            session = self._build_evidence_summary(session)
            result_sessions.append(session)

        result_sessions.sort(
            key=lambda x: x["session_risk_score"], reverse=True
        )

        return {
            "total_sessions_reconstructed": len(result_sessions),
            "compromised_sessions"        : [
                s for s in result_sessions if s["session_risk_score"] >= 40
            ],
            "all_sessions"                : result_sessions,
            "highest_risk_session"        : result_sessions[0] if result_sessions else None,
            "post_compromise_detected"    : any(
                s["session_risk_score"] >= 40 for s in result_sessions
            ),
        }

    def _find_successful_logins(self, lines: list[str]) -> list[dict]:
        logins  = []
        patterns = [
            re.compile(r'(?P<ts>\w+\s+\d+\s+[\d:]+).*Accepted (?:password|publickey) for (?P<user>\S+) from (?P<ip>[\d.]+)'),
            re.compile(r'(?P<ts>\w+\s+\d+\s+[\d:]+).*session opened for user (?P<user>\S+).*by (?P<ip>[\d.]+)?'),
            re.compile(r'(?P<ts>[\d\-]+\s+[\d:]+).*Logon.*Success.*Account Name:\s*(?P<user>\S+).*Source.*:\s*(?P<ip>[\d.]+)'),
        ]
        for line in lines:
            for pat in patterns:
                m = pat.search(line)
                if m:
                    ip = ""
                    try: ip = m.group("ip") or ""
                    except: pass
                    logins.append({
                        "timestamp": m.group("ts"),
                        "user"     : m.group("user"),
                        "ip"       : ip,
                        "raw_line" : line[:120],
                    })
                    break
        return logins

    def _parse_session_line(self, line: str, session: dict):
        """Parse a single log line for post-compromise activity."""

        # Command execution detection (from syslog, audit, bash_history)
        cmd_patterns = [
            re.compile(r'(?:COMMAND|CMD|command)=(.+?)(?:\s*$|\s+USER=)'),
            re.compile(r'type=EXECVE.*?a0="([^"]+)".*?a1="([^"]*)"'),
            re.compile(r'(?:bash|sh|zsh)\[\d+\]:\s+(.+)'),
        ]
        for pat in cmd_patterns:
            m = pat.search(line)
            if m:
                cmd = m.group(1).strip()[:150]
                risk = self._classify_command(cmd)
                if risk:
                    entry = {
                        "command"    : cmd,
                        "category"   : risk[0],
                        "severity"   : risk[1],
                        "description": risk[2],
                        "raw_line"   : line[:150],
                    }
                    session["commands_run"].append(entry)

                    # Categorise into kill chain buckets
                    cat = risk[0]
                    if cat == "PRIV_ESC":
                        session["privilege_escalations"].append(entry)
                        session["kill_chain_stage"].append("ESCALATE")
                    elif cat == "PERSISTENCE":
                        session["persistence_actions"].append(entry)
                        session["kill_chain_stage"].append("PERSIST")
                    elif cat == "EXFIL":
                        session["data_exfil_indicators"].append(entry)
                        session["kill_chain_stage"].append("EXFILTRATE")
                    elif cat == "LATERAL":
                        session["lateral_movement"].append(entry)
                        session["kill_chain_stage"].append("MOVE_LATERALLY")
                    elif cat == "ANTIFORENSIC":
                        session["anti_forensics"].append(entry)
                        session["kill_chain_stage"].append("COVER_TRACKS")
                    elif cat == "MALWARE":
                        session["malware_indicators"].append(entry)
                        session["kill_chain_stage"].append("DEPLOY_MALWARE")
                    elif cat == "RECON":
                        session["kill_chain_stage"].append("RECONNAISSANCE")

        # File access detection
        file_patterns = [
            re.compile(r'type=PATH.*?name="([^"]+)"'),
            re.compile(r'(?:open|read|write|access)\("(/[^"]+)"'),
            re.compile(r'cat\s+(/\S+)|less\s+(/\S+)|vi\s+(/\S+)'),
        ]
        for pat in file_patterns:
            m = pat.search(line)
            if m:
                fpath = next((g for g in m.groups() if g), "")
                for sens_path, sev, desc in SENSITIVE_FILES:
                    if re.search(sens_path, fpath, re.IGNORECASE):
                        session["files_accessed"].append({
                            "path"       : fpath[:100],
                            "severity"   : sev,
                            "description": desc,
                        })
                        break

    def _classify_command(self, cmd: str) -> tuple | None:
        for pattern, (cat, sev, desc) in COMMAND_RISK.items():
            if re.search(pattern, cmd, re.IGNORECASE):
                return cat, sev, desc
        return None

    def _score_session(self, session: dict) -> dict:
        score = 0
        score += len(session["commands_run"]) * 5
        score += len(session["privilege_escalations"]) * 20
        score += len(session["persistence_actions"]) * 25
        score += len(session["data_exfil_indicators"]) * 20
        score += len(session["lateral_movement"]) * 20
        score += len(session["anti_forensics"]) * 30
        score += len(session["malware_indicators"]) * 25
        score += len(session["files_accessed"]) * 10
        session["session_risk_score"] = min(score, 100)

        if score >= 80:
            session["session_verdict"] = "APT — FULL COMPROMISE"
        elif score >= 60:
            session["session_verdict"] = "ACTIVE ATTACKER — IMMEDIATE ACTION"
        elif score >= 40:
            session["session_verdict"] = "COMPROMISED — INVESTIGATION REQUIRED"
        elif score >= 20:
            session["session_verdict"] = "SUSPICIOUS — MONITOR CLOSELY"
        else:
            session["session_verdict"] = "BENIGN OR INCOMPLETE DATA"

        # Deduplicate kill chain stages
        seen = set()
        session["kill_chain_stage"] = [
            s for s in session["kill_chain_stage"]
            if not (s in seen or seen.add(s))
        ]
        return session

    def _build_evidence_summary(self, session: dict) -> dict:
        fir_evidence = []
        ip   = session["attacker_ip"]
        user = session["username"]
        ts   = session["login_timestamp"]

        if ts and ip:
            fir_evidence.append(
                f"Unauthorised access from IP {ip} using account '{user}' at {ts}"
            )
        for priv in session["privilege_escalations"][:3]:
            fir_evidence.append(
                f"Privilege escalation: {priv['command'][:80]}"
            )
        for exfil in session["data_exfil_indicators"][:3]:
            fir_evidence.append(
                f"Data exfiltration indicator: {exfil['command'][:80]}"
            )
        for anti in session["anti_forensics"][:3]:
            fir_evidence.append(
                f"Evidence tampering: {anti['command'][:80]}"
            )
        for persist in session["persistence_actions"][:3]:
            fir_evidence.append(
                f"Persistence mechanism: {persist['command'][:80]}"
            )

        session["evidence_for_fir"] = fir_evidence
        return session
