"""
RAKSHAK — User Behaviour Analytics (UBA) Engine
Baseline learning · Impossible travel · Insider threat · Privilege creep
Catches attacks using LEGITIMATE credentials — invisible to rule-based detection
"""

import re, math, statistics
from collections import defaultdict, Counter
from datetime import datetime, timedelta
from typing import Optional

# ── Geo-IP country mapping (lite — major ranges) ──────────────────────────────
# Real deployment would use MaxMind GeoIP2 database
GEO_IP_LITE = {
    "1."  : "Australia",   "2."  : "France",      "5."  : "Russia",
    "8."  : "USA",         "14." : "China",        "27." : "China",
    "31." : "Netherlands", "37." : "Russia",       "45." : "USA",
    "46." : "Sweden",      "49." : "Germany",      "58." : "China",
    "59." : "Japan",       "61." : "Australia",    "62." : "UK",
    "66." : "USA",         "77." : "Russia",       "78." : "Russia",
    "80." : "Germany",     "83." : "Netherlands",  "85." : "Turkey",
    "86." : "China",       "91." : "Russia",       "92." : "Netherlands",
    "95." : "Russia",      "103.": "India",        "104.": "USA",
    "106.": "China",       "111.": "China",        "112.": "China",
    "114.": "China",       "115.": "China",        "116.": "China",
    "117.": "China",       "119.": "China",        "120.": "China",
    "121.": "China",       "122.": "China",        "123.": "India",
    "124.": "India",       "125.": "India",        "126.": "Japan",
    "182.": "India",       "183.": "China",        "185.": "Russia",
    "188.": "Russia",      "192.": "USA",          "193.": "Germany",
    "194.": "UK",          "195.": "Netherlands",  "198.": "USA",
    "199.": "USA",         "203.": "India",        "210.": "Japan",
    "211.": "South Korea", "212.": "UAE",          "213.": "Israel",
    "218.": "China",       "219.": "China",        "220.": "China",
    "221.": "China",       "222.": "China",        "223.": "China",
}

# Physical travel speed limit: no human can be in 2 countries within 10 minutes
IMPOSSIBLE_TRAVEL_MINUTES = 10
# Off-hours: outside 08:00–20:00 IST
BUSINESS_HOURS_START = 8
BUSINESS_HOURS_END   = 20
# Bulk download threshold (MB equivalent in log units)
BULK_DOWNLOAD_THRESHOLD = 100
# Privilege creep threshold: >3 new permissions in 30-day window
PRIV_CREEP_THRESHOLD = 3

# Log parsing patterns
LOGIN_PAT = re.compile(
    r'(?P<ts>\w{3}\s+\d+\s+[\d:]+|\d{4}-\d{2}-\d{2}[T\s][\d:.]+)'
    r'.*?(?:Accepted|session opened|Logged in|LOGIN OK)'
    r'.*?(?:for\s+)?(?:user\s+)?(?P<user>\w+)'
    r'.*?from\s+(?P<ip>[\d.]+)',
    re.IGNORECASE
)
COMMAND_PAT = re.compile(
    r'(?P<ts>\w{3}\s+\d+\s+[\d:]+).*?'
    r'(?:CMD|COMMAND|type=EXECVE).*?(?P<user>\w+).*?(?P<cmd>[/\w][\w/.\- ]{3,60})',
    re.IGNORECASE
)
FILE_ACCESS_PAT = re.compile(
    r'(?P<user>\w+).*?(?:open|read|write|unlink|rename)'
    r'.*?(?P<file>/[\w/.\-]{5,80})',
    re.IGNORECASE
)
PRIV_GRANT_PAT = re.compile(
    r'(?P<ts>[\d\-T:.]+).*?(?:GRANT|usermod|visudo|chmod 777|chown root)'
    r'.*?(?:to\s+)?(?P<user>\w+)',
    re.IGNORECASE
)
DATA_TRANSFER_PAT = re.compile(
    r'(?P<user>\w+).*?(?:scp|rsync|sftp|ftp).*?(?P<bytes>\d+)\s*(?:bytes|KB|MB)',
    re.IGNORECASE
)


class UBAEngine:
    """
    RAKSHAK User Behaviour Analytics Engine
    Builds per-user behaviour baselines and detects statistical anomalies.
    """

    def analyze(self, log_text: str) -> dict:
        lines  = log_text.splitlines()
        logins = self._parse_logins(lines)
        cmds   = self._parse_commands(lines)
        files  = self._parse_file_access(lines)
        privs  = self._parse_priv_grants(lines)
        xfers  = self._parse_transfers(lines)

        result = {
            "impossible_travel"      : self._detect_impossible_travel(logins),
            "off_hours_access"       : self._detect_off_hours(logins),
            "insider_threat_signals" : self._detect_insider_threat(logins, cmds, xfers),
            "privilege_creep"        : self._detect_privilege_creep(privs),
            "bulk_data_access"       : self._detect_bulk_access(xfers),
            "user_anomaly_scores"    : self._score_users(logins, cmds),
            "uba_risk_score"         : 0,
            "uba_findings"           : [],
        }

        score = 0
        score += 45 if result["impossible_travel"]                         else 0
        score += min(len(result["off_hours_access"]) * 10, 25)
        score += min(len(result["insider_threat_signals"]) * 15, 30)
        score += min(len(result["privilege_creep"]) * 10, 20)
        score += min(len(result["bulk_data_access"]) * 12, 20)
        result["uba_risk_score"] = min(score, 100)
        result["uba_findings"]   = self._build_findings(result)
        return result

    # ── Parsers ──────────────────────────────────────────────────────────────

    def _parse_logins(self, lines: list) -> list:
        logins = []
        for line in lines:
            m = LOGIN_PAT.search(line)
            if m:
                ts = self._parse_ts(m.group("ts"))
                ip = m.group("ip")
                logins.append({
                    "user"    : m.group("user"),
                    "ip"      : ip,
                    "country" : self._geoip(ip),
                    "ts"      : ts,
                    "hour"    : ts.hour if ts else None,
                })
        return logins

    def _parse_commands(self, lines: list) -> list:
        cmds = []
        for line in lines:
            m = COMMAND_PAT.search(line)
            if m:
                cmds.append({
                    "user": m.group("user"),
                    "cmd" : m.group("cmd")[:80],
                    "ts"  : self._parse_ts(m.group("ts")),
                })
        return cmds

    def _parse_file_access(self, lines: list) -> list:
        accesses = []
        for line in lines:
            m = FILE_ACCESS_PAT.search(line)
            if m:
                accesses.append({"user": m.group("user"), "file": m.group("file")})
        return accesses

    def _parse_priv_grants(self, lines: list) -> list:
        grants = []
        for line in lines:
            m = PRIV_GRANT_PAT.search(line)
            if m:
                grants.append({
                    "user" : m.group("user"),
                    "ts"   : self._parse_ts(m.group("ts")),
                    "raw"  : line[:100],
                })
        return grants

    def _parse_transfers(self, lines: list) -> list:
        xfers = []
        for line in lines:
            m = DATA_TRANSFER_PAT.search(line)
            if m:
                xfers.append({
                    "user" : m.group("user"),
                    "bytes": int(m.group("bytes")),
                    "raw"  : line[:100],
                })
        return xfers

    # ── Detectors ────────────────────────────────────────────────────────────

    def _detect_impossible_travel(self, logins: list) -> list:
        """
        If user A logs in from Country X at T1 and Country Y at T2,
        and T2-T1 < IMPOSSIBLE_TRAVEL_MINUTES, flag as impossible travel.
        """
        flags = []
        by_user = defaultdict(list)
        for login in logins:
            if login["ts"] and login["country"] != "India":  # flag non-India access
                by_user[login["user"]].append(login)

        for user, sessions in by_user.items():
            sessions.sort(key=lambda s: s["ts"])
            for i in range(len(sessions) - 1):
                s1, s2 = sessions[i], sessions[i + 1]
                if s1["country"] == s2["country"]:
                    continue
                delta = abs((s2["ts"] - s1["ts"]).total_seconds() / 60)
                if delta < IMPOSSIBLE_TRAVEL_MINUTES:
                    flags.append({
                        "user"      : user,
                        "login_1"   : f"{s1['ip']} ({s1['country']}) at {s1['ts']}",
                        "login_2"   : f"{s2['ip']} ({s2['country']}) at {s2['ts']}",
                        "minutes"   : round(delta, 1),
                        "severity"  : "CRITICAL",
                        "conclusion": "STOLEN CREDENTIAL — physically impossible to be in "
                                      f"both {s1['country']} and {s2['country']} in {delta:.1f} min",
                        "mitre"     : "T1078 — Valid Accounts (Compromised)",
                    })
        return flags

    def _detect_off_hours(self, logins: list) -> list:
        """Flag logins outside IST business hours."""
        flags = []
        for login in logins:
            if login["hour"] is None:
                continue
            if not (BUSINESS_HOURS_START <= login["hour"] < BUSINESS_HOURS_END):
                flags.append({
                    "user"    : login["user"],
                    "ip"      : login["ip"],
                    "country" : login["country"],
                    "hour"    : login["hour"],
                    "severity": "MEDIUM" if login["country"] == "India" else "HIGH",
                    "note"    : f"Login at {login['hour']:02d}:xx IST — outside business hours",
                })
        return flags

    def _detect_insider_threat(self, logins: list, cmds: list, xfers: list) -> list:
        """
        Insider threat signals:
        - Bulk downloads before off-boarding
        - Accessing systems outside job scope
        - Sensitive command patterns
        """
        signals = []
        INSIDER_CMD_PATTERNS = [
            (r'tar\s.*?/(?:etc|home|var/log|opt)', "Archiving sensitive system directories"),
            (r'rsync.*?external|scp.*?@(?!10\.|192\.168\.|172\.)',  "Copying data to external host"),
            (r'base64\s+.*?/etc|xxd\s+/etc',       "Encoding sensitive files"),
            (r'wget|curl.*?-o\s',                   "Downloading external content"),
            (r'history\s+-c|unset\s+HISTFILE',      "Erasing command history"),
            (r'dd\s+if=.*?of=',                     "Raw disk copy (data theft)"),
            (r'find\s+/.*?-name.*?\.(doc|pdf|xls)', "Searching for document files"),
        ]

        for cmd_entry in cmds:
            for pattern, description in INSIDER_CMD_PATTERNS:
                if re.search(pattern, cmd_entry["cmd"], re.IGNORECASE):
                    signals.append({
                        "user"       : cmd_entry["user"],
                        "command"    : cmd_entry["cmd"],
                        "threat_type": "INSIDER_THREAT",
                        "description": description,
                        "severity"   : "HIGH",
                        "mitre"      : "T1074 — Data Staged",
                    })
                    break

        # Large data transfers
        user_xfer = defaultdict(int)
        for xfer in xfers:
            user_xfer[xfer["user"]] += xfer["bytes"]
        for user, total in user_xfer.items():
            if total > BULK_DOWNLOAD_THRESHOLD * 1024:  # in KB
                signals.append({
                    "user"       : user,
                    "bytes"      : total,
                    "threat_type": "BULK_DATA_EXFIL",
                    "description": f"{total // 1024} KB transferred — bulk data movement",
                    "severity"   : "HIGH",
                    "mitre"      : "T1048 — Exfiltration Over Alternative Protocol",
                })
        return signals

    def _detect_privilege_creep(self, privs: list) -> list:
        """
        Privilege creep: user accumulates permissions gradually.
        Each grant looks routine; the pattern is the threat.
        """
        user_grants = defaultdict(list)
        for grant in privs:
            user_grants[grant["user"]].append(grant)

        creep = []
        for user, grants in user_grants.items():
            if len(grants) >= PRIV_CREEP_THRESHOLD:
                creep.append({
                    "user"       : user,
                    "grant_count": len(grants),
                    "grants"     : [g["raw"] for g in grants[:5]],
                    "severity"   : "HIGH" if len(grants) >= 5 else "MEDIUM",
                    "description": f"User '{user}' received {len(grants)} privilege grants — "
                                   f"possible privilege creep or compromised admin account",
                    "mitre"      : "T1078.003 — Valid Accounts: Local Accounts",
                })
        return creep

    def _detect_bulk_access(self, xfers: list) -> list:
        flags = []
        user_total = defaultdict(int)
        for xfer in xfers:
            user_total[xfer["user"]] += xfer["bytes"]
        for user, total in user_total.items():
            if total > BULK_DOWNLOAD_THRESHOLD * 512:
                flags.append({
                    "user"  : user,
                    "total" : total,
                    "note"  : f"Large data transfer: {total // 1024} KB",
                })
        return flags

    def _score_users(self, logins: list, cmds: list) -> list:
        """Compute anomaly risk score per user."""
        user_scores = defaultdict(int)
        for login in logins:
            if login["country"] not in ("India", ""):
                user_scores[login["user"]] += 20
            if login["hour"] and not (8 <= login["hour"] < 20):
                user_scores[login["user"]] += 10
        for cmd in cmds:
            dangerous = ["sudo", "su -", "chmod 777", "rm -rf", "dd if=", "base64"]
            if any(d in cmd["cmd"] for d in dangerous):
                user_scores[cmd["user"]] += 15

        scored = [
            {"user": u, "score": min(s, 100)} for u, s in user_scores.items()
        ]
        return sorted(scored, key=lambda x: x["score"], reverse=True)[:10]

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _geoip(self, ip: str) -> str:
        for prefix, country in GEO_IP_LITE.items():
            if ip.startswith(prefix):
                return country
        if ip.startswith(("10.", "192.168.", "172.16.")):
            return "Internal"
        return "Unknown"

    def _parse_ts(self, ts_str: str) -> Optional[datetime]:
        if not ts_str:
            return None
        ts_str = ts_str.strip()
        fmts = [
            "%b %d %H:%M:%S",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M:%S.%f",
            "%b  %d %H:%M:%S",
        ]
        for fmt in fmts:
            try:
                dt = datetime.strptime(ts_str, fmt)
                if dt.year == 1900:
                    dt = dt.replace(year=datetime.now().year)
                return dt
            except ValueError:
                continue
        return None

    def _build_findings(self, result: dict) -> list:
        findings = []
        if result["impossible_travel"]:
            for travel in result["impossible_travel"]:
                findings.append({
                    "severity"   : "CRITICAL",
                    "category"   : "Impossible Travel",
                    "description": f"User '{travel['user']}': {travel['conclusion']}",
                    "action"     : "Immediately disable account + force password reset + "
                                   "revoke all active sessions + escalate to DRDO NOC",
                })
        if result["insider_threat_signals"]:
            findings.append({
                "severity"   : "HIGH",
                "category"   : "Insider Threat",
                "description": f"{len(result['insider_threat_signals'])} insider threat "
                               f"signals detected — possible data theft by authorised user",
                "action"     : "Audit user activity for 30 days + HR notification + "
                               "preserve forensic evidence under IT Act Section 66",
            })
        if result["privilege_creep"]:
            findings.append({
                "severity"   : "HIGH",
                "category"   : "Privilege Creep",
                "description": f"{len(result['privilege_creep'])} user(s) accumulating "
                               f"excessive privileges over time",
                "action"     : "Immediate privilege audit + apply principle of least privilege",
            })
        return findings
