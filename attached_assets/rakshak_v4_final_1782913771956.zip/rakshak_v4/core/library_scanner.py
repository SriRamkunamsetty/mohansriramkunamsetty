"""
RAKSHAK — Third-Party Library Scanner
Identifies embedded SDKs · Maps versions to CVE database
Detects outdated/vulnerable libraries in APKs
"""

import re, zipfile, hashlib
from pathlib import Path
from core.event_bus import emit, EventType


# ── SDK signature database (bytecode fingerprints) ───────────────────────────
SDK_SIGNATURES = {
    "OkHttp": {
        "patterns"  : [r"okhttp3\.", r"okhttp\.OkHttpClient", r"okhttp3/OkHttpClient"],
        "version_re": r"OkHttp/(\d+\.\d+[\.\d]*)",
        "cves"      : {
            "3.0": [("CVE-2016-2402","HIGH","Certificate pinning bypass")],
            "3.1": [("CVE-2016-2402","HIGH","Certificate pinning bypass")],
            "3.12": [("CVE-2019-9658","MEDIUM","Cleartext header injection")],
        },
        "safe_version": "4.9.0",
        "category"  : "Networking",
    },
    "Retrofit": {
        "patterns"  : [r"retrofit2\.Retrofit", r"retrofit\.Retrofit"],
        "version_re": r"Retrofit/(\d+\.\d+[\.\d]*)",
        "cves"      : {},
        "safe_version": "2.9.0",
        "category"  : "Networking",
    },
    "Glide": {
        "patterns"  : [r"com\.bumptech\.glide", r"GlideApp"],
        "version_re": r"glide[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {},
        "safe_version": "4.12.0",
        "category"  : "Image Loading",
    },
    "Firebase": {
        "patterns"  : [r"com\.google\.firebase", r"firebase\.analytics", r"firebase\.crash"],
        "version_re": r"firebase[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {},
        "safe_version": "30.0.0",
        "category"  : "Backend/Analytics",
    },
    "AdMob": {
        "patterns"  : [r"com\.google\.android\.gms\.ads", r"AdMobSDK", r"admob\.banner"],
        "version_re": r"admob[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {},
        "safe_version": "21.0.0",
        "category"  : "Advertising",
    },
    "Facebook SDK": {
        "patterns"  : [r"com\.facebook\.FacebookSdk", r"com\.facebook\.login"],
        "version_re": r"facebook[:\-]sdk[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {
            "5.0": [("CVE-2019-3572","HIGH","Access token exposure in logs")],
            "5.1": [("CVE-2019-3572","HIGH","Access token exposure in logs")],
        },
        "safe_version": "13.0.0",
        "category"  : "Social Auth",
    },
    "Apache Cordova": {
        "patterns"  : [r"apache\.cordova", r"org\.apache\.cordova"],
        "version_re": r"cordova[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {
            "4.0": [("CVE-2015-5256","HIGH","Intent spoofing"),
                    ("CVE-2015-1835","HIGH","Variable injection")],
            "4.1": [("CVE-2015-5256","HIGH","Intent spoofing")],
        },
        "safe_version": "10.0.0",
        "category"  : "Hybrid Framework",
    },
    "WebRTC": {
        "patterns"  : [r"org\.webrtc", r"WebRTCClient", r"PeerConnectionClient"],
        "version_re": r"webrtc[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {
            "1.0": [("CVE-2018-6048","MEDIUM","IP leak in WebRTC")],
        },
        "safe_version": "1.0.32006",
        "category"  : "Video/Audio",
    },
    "Log4j (Android)": {
        "patterns"  : [r"log4j\.Logger", r"org\.apache\.log4j", r"log4j-core"],
        "version_re": r"log4j[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {
            "2.14": [("CVE-2021-44228","CRITICAL","Log4Shell — Remote Code Execution"),
                     ("CVE-2021-45046","CRITICAL","Log4Shell bypass")],
            "2.13": [("CVE-2021-44228","CRITICAL","Log4Shell — Remote Code Execution")],
        },
        "safe_version": "2.17.1",
        "category"  : "Logging",
    },
    "Bouncy Castle": {
        "patterns"  : [r"bouncycastle", r"org\.bouncycastle", r"bcprov"],
        "version_re": r"bcprov[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {
            "1.56": [("CVE-2017-13098","MEDIUM","Weak DSA/ECDSA random")],
            "1.57": [("CVE-2018-1000613","HIGH","Side channel attack")],
        },
        "safe_version": "1.70",
        "category"  : "Cryptography",
    },
    "ACRA": {
        "patterns"  : [r"org\.acra\.ACRA", r"acra\.annotation"],
        "version_re": r"acra[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {},
        "safe_version": "5.9.0",
        "category"  : "Crash Reporting",
    },
    "Fresco (Facebook)": {
        "patterns"  : [r"com\.facebook\.fresco", r"FrescoModule"],
        "version_re": r"fresco[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {},
        "safe_version": "2.5.0",
        "category"  : "Image Loading",
    },
    "Picasso": {
        "patterns"  : [r"com\.squareup\.picasso", r"Picasso\.with"],
        "version_re": r"picasso[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {},
        "safe_version": "2.8",
        "category"  : "Image Loading",
    },
    "RxJava": {
        "patterns"  : [r"io\.reactivex", r"RxAndroid", r"rx\.Observable"],
        "version_re": r"rxjava[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {},
        "safe_version": "3.1.0",
        "category"  : "Reactive Programming",
    },
    "Crashlytics": {
        "patterns"  : [r"com\.crashlytics\.android", r"fabric\.sdk\.android"],
        "version_re": r"crashlytics[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {},
        "safe_version": "18.0.0",
        "category"  : "Crash Reporting",
    },
    "Dagger": {
        "patterns"  : [r"dagger\.Component", r"dagger\.android", r"dagger\.hilt"],
        "version_re": r"dagger[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {},
        "safe_version": "2.41",
        "category"  : "Dependency Injection",
    },
    "Braintree SDK": {
        "patterns"  : [r"com\.braintreepayments", r"braintree\.android"],
        "version_re": r"braintree[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {
            "3.0": [("CVE-2018-10235","MEDIUM","SSL validation issue")],
        },
        "safe_version": "4.0.0",
        "category"  : "Payment",
    },
    "Razorpay SDK": {
        "patterns"  : [r"com\.razorpay", r"razorpay\.android"],
        "version_re": r"razorpay[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {},
        "safe_version": "1.6.0",
        "category"  : "Payment (India)",
    },
    "Paytm SDK": {
        "patterns"  : [r"com\.paytm\.pgsdk", r"paytm\.payment"],
        "version_re": r"paytm[:\-](\d+\.\d+[\.\d]*)",
        "cves"      : {},
        "safe_version": "5.0.0",
        "category"  : "Payment (India)",
    },
}


class LibraryScanner:
    """
    RAKSHAK Third-Party Library Scanner
    Identifies embedded SDKs and maps detected versions to CVE databases
    """

    def scan(self, apk_path: str, case_id: str = "") -> dict:
        raw_code = self._extract_code(apk_path)
        gradle   = self._extract_gradle_deps(apk_path)

        detected_libs   = []
        vulnerable_libs = []
        total_cves      = 0
        critical_cves   = 0

        for lib_name, lib_info in SDK_SIGNATURES.items():
            # Check if library is present
            found = any(
                re.search(p, raw_code, re.IGNORECASE)
                for p in lib_info["patterns"]
            )
            if not found:
                # Also check gradle deps
                found = lib_name.lower().replace(" ", "") in gradle.lower()

            if found:
                # Try to detect version
                version = ""
                ver_match = re.search(lib_info["version_re"], raw_code, re.IGNORECASE)
                if not ver_match:
                    ver_match = re.search(lib_info["version_re"], gradle, re.IGNORECASE)
                if ver_match:
                    version = ver_match.group(1)

                # Check for CVEs
                lib_cves    = []
                is_vuln     = False
                cve_db      = lib_info.get("cves", {})

                for vuln_ver, cves in cve_db.items():
                    if version and version.startswith(vuln_ver):
                        lib_cves.extend([
                            {"cve_id": c[0], "severity": c[1], "description": c[2]}
                            for c in cves
                        ])
                        is_vuln = True

                # Even without known version, old CVEs are flagged as possible
                if cve_db and not version:
                    all_cves = [c for cves in cve_db.values() for c in cves]
                    critical_ones = [c for c in all_cves if c[1] == "CRITICAL"]
                    if critical_ones:
                        lib_cves.append({
                            "cve_id"     : critical_ones[0][0],
                            "severity"   : "MEDIUM",
                            "description": f"{critical_ones[0][2]} (version undetectable — verify manually)",
                        })

                lib_entry = {
                    "library"          : lib_name,
                    "category"         : lib_info["category"],
                    "detected_version" : version or "unknown",
                    "safe_version"     : lib_info.get("safe_version", ""),
                    "cves"             : lib_cves,
                    "is_vulnerable"    : is_vuln or bool(lib_cves),
                    "cve_count"        : len(lib_cves),
                }
                detected_libs.append(lib_entry)

                if lib_entry["is_vulnerable"]:
                    vulnerable_libs.append(lib_entry)
                    total_cves   += len(lib_cves)
                    critical_cves += sum(1 for c in lib_cves if c["severity"] == "CRITICAL")

                    if case_id:
                        emit(EventType.CRITICAL_VULN, case_id, {
                            "engine"     : "LIBRARY-SCANNER",
                            "title"      : f"Vulnerable SDK: {lib_name}",
                            "description": f"{len(lib_cves)} CVEs — version {version or 'unknown'}",
                            "score"      : 20 if critical_cves else 10,
                        }, severity="CRITICAL" if critical_cves else "HIGH")

        # Sort by risk (vulnerable first)
        detected_libs.sort(key=lambda x: (not x["is_vulnerable"], -x["cve_count"]))

        library_risk_score = min(
            len(vulnerable_libs) * 10 + critical_cves * 15, 100
        )

        return {
            "total_libraries_detected" : len(detected_libs),
            "vulnerable_libraries"     : len(vulnerable_libs),
            "total_cves"               : total_cves,
            "critical_cves"            : critical_cves,
            "library_risk_score"       : library_risk_score,
            "detected_libraries"       : detected_libs,
            "vulnerable_library_names" : [l["library"] for l in vulnerable_libs],
            "library_categories"       : list({l["category"] for l in detected_libs}),
            "payment_sdks"             : [l["library"] for l in detected_libs
                                          if "Payment" in l["category"]],
        }

    def _extract_code(self, apk_path: str) -> str:
        code = ""
        try:
            with zipfile.ZipFile(apk_path) as zf:
                for name in zf.namelist():
                    if name.endswith(".dex") or name.endswith(".xml"):
                        try:
                            data    = zf.read(name)
                            strings = re.findall(b'[\x20-\x7e]{6,}', data)
                            code   += " ".join(s.decode("ascii", errors="ignore") for s in strings)
                        except Exception:
                            pass
        except Exception:
            pass
        return code

    def _extract_gradle_deps(self, apk_path: str) -> str:
        deps = ""
        try:
            with zipfile.ZipFile(apk_path) as zf:
                for name in zf.namelist():
                    if name in ("META-INF/gradle/incremental.taskgraph",
                                "assets/www/cordova.js",
                                "META-INF/MANIFEST.MF"):
                        try:
                            deps += zf.read(name).decode("ascii", errors="ignore")
                        except Exception:
                            pass
        except Exception:
            pass
        return deps
