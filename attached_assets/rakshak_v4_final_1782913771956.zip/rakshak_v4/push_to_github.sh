#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════
# RAKSHAK — GitHub Push Script
# Run this ONCE on your local machine to push to GitHub
# ═══════════════════════════════════════════════════════════
set -e
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RESET='\033[0m'

echo -e "${GREEN}RAKSHAK v3.1 — GitHub Push Setup${RESET}"
echo ""

# ── Step 1: Set your GitHub repo URL ─────────────────────
# Change this to your actual GitHub repo URL
GITHUB_URL="https://github.com/SriRamkunamsetty/RAKSHAK.git"

# ── Step 2: Configure git (already done) ─────────────────
git config user.email "mohansriramkunamsetty@gmail.com"
git config user.name  "Mohan Sriram Kunamsetty"

# ── Step 3: Set remote ────────────────────────────────────
git remote remove origin 2>/dev/null || true
git remote add origin "$GITHUB_URL"
echo -e "${GREEN}✓${RESET} Remote set: $GITHUB_URL"

# ── Step 4: Push ──────────────────────────────────────────
echo ""
echo -e "${YELLOW}Pushing to GitHub...${RESET}"
git branch -M main
git push -u origin main --force

echo ""
echo -e "${GREEN}✓ RAKSHAK pushed to GitHub successfully!${RESET}"
echo "  View at: https://github.com/SriRamkunamsetty/RAKSHAK"
